--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1 (Debian 14.1-1.pgdg110+1)
-- Dumped by pg_dump version 14.1 (Debian 14.1-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_emailaddress; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.account_emailaddress (
    id integer NOT NULL,
    email character varying(254) NOT NULL,
    verified boolean NOT NULL,
    "primary" boolean NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.account_emailaddress OWNER TO "pro-nsw-admin";

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.account_emailaddress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailaddress_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.account_emailaddress_id_seq OWNED BY public.account_emailaddress.id;


--
-- Name: account_emailconfirmation; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.account_emailconfirmation (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    sent timestamp with time zone,
    key character varying(64) NOT NULL,
    email_address_id integer NOT NULL
);


ALTER TABLE public.account_emailconfirmation OWNER TO "pro-nsw-admin";

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.account_emailconfirmation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailconfirmation_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.account_emailconfirmation_id_seq OWNED BY public.account_emailconfirmation.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO "pro-nsw-admin";

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO "pro-nsw-admin";

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO "pro-nsw-admin";

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.authtoken_token OWNER TO "pro-nsw-admin";

--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id bigint NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO "pro-nsw-admin";

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_celery_beat_clockedschedule; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.django_celery_beat_clockedschedule (
    id integer NOT NULL,
    clocked_time timestamp with time zone NOT NULL
);


ALTER TABLE public.django_celery_beat_clockedschedule OWNER TO "pro-nsw-admin";

--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.django_celery_beat_clockedschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_clockedschedule_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.django_celery_beat_clockedschedule_id_seq OWNED BY public.django_celery_beat_clockedschedule.id;


--
-- Name: django_celery_beat_crontabschedule; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.django_celery_beat_crontabschedule (
    id integer NOT NULL,
    minute character varying(240) NOT NULL,
    hour character varying(96) NOT NULL,
    day_of_week character varying(64) NOT NULL,
    day_of_month character varying(124) NOT NULL,
    month_of_year character varying(64) NOT NULL,
    timezone character varying(63) NOT NULL
);


ALTER TABLE public.django_celery_beat_crontabschedule OWNER TO "pro-nsw-admin";

--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.django_celery_beat_crontabschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_crontabschedule_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.django_celery_beat_crontabschedule_id_seq OWNED BY public.django_celery_beat_crontabschedule.id;


--
-- Name: django_celery_beat_intervalschedule; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.django_celery_beat_intervalschedule (
    id integer NOT NULL,
    every integer NOT NULL,
    period character varying(24) NOT NULL
);


ALTER TABLE public.django_celery_beat_intervalschedule OWNER TO "pro-nsw-admin";

--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.django_celery_beat_intervalschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_intervalschedule_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.django_celery_beat_intervalschedule_id_seq OWNED BY public.django_celery_beat_intervalschedule.id;


--
-- Name: django_celery_beat_periodictask; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.django_celery_beat_periodictask (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    task character varying(200) NOT NULL,
    args text NOT NULL,
    kwargs text NOT NULL,
    queue character varying(200),
    exchange character varying(200),
    routing_key character varying(200),
    expires timestamp with time zone,
    enabled boolean NOT NULL,
    last_run_at timestamp with time zone,
    total_run_count integer NOT NULL,
    date_changed timestamp with time zone NOT NULL,
    description text NOT NULL,
    crontab_id integer,
    interval_id integer,
    solar_id integer,
    one_off boolean NOT NULL,
    start_time timestamp with time zone,
    priority integer,
    headers text NOT NULL,
    clocked_id integer,
    expire_seconds integer,
    CONSTRAINT django_celery_beat_periodictask_expire_seconds_check CHECK ((expire_seconds >= 0)),
    CONSTRAINT django_celery_beat_periodictask_priority_check CHECK ((priority >= 0)),
    CONSTRAINT django_celery_beat_periodictask_total_run_count_check CHECK ((total_run_count >= 0))
);


ALTER TABLE public.django_celery_beat_periodictask OWNER TO "pro-nsw-admin";

--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.django_celery_beat_periodictask_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_periodictask_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.django_celery_beat_periodictask_id_seq OWNED BY public.django_celery_beat_periodictask.id;


--
-- Name: django_celery_beat_periodictasks; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.django_celery_beat_periodictasks (
    ident smallint NOT NULL,
    last_update timestamp with time zone NOT NULL
);


ALTER TABLE public.django_celery_beat_periodictasks OWNER TO "pro-nsw-admin";

--
-- Name: django_celery_beat_solarschedule; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.django_celery_beat_solarschedule (
    id integer NOT NULL,
    event character varying(24) NOT NULL,
    latitude numeric(9,6) NOT NULL,
    longitude numeric(9,6) NOT NULL
);


ALTER TABLE public.django_celery_beat_solarschedule OWNER TO "pro-nsw-admin";

--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.django_celery_beat_solarschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_solarschedule_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.django_celery_beat_solarschedule_id_seq OWNED BY public.django_celery_beat_solarschedule.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO "pro-nsw-admin";

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO "pro-nsw-admin";

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO "pro-nsw-admin";

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO "pro-nsw-admin";

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.django_site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: easy_thumbnails_source; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.easy_thumbnails_source (
    id integer NOT NULL,
    storage_hash character varying(40) NOT NULL,
    name character varying(255) NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE public.easy_thumbnails_source OWNER TO "pro-nsw-admin";

--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.easy_thumbnails_source_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.easy_thumbnails_source_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.easy_thumbnails_source_id_seq OWNED BY public.easy_thumbnails_source.id;


--
-- Name: easy_thumbnails_thumbnail; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.easy_thumbnails_thumbnail (
    id integer NOT NULL,
    storage_hash character varying(40) NOT NULL,
    name character varying(255) NOT NULL,
    modified timestamp with time zone NOT NULL,
    source_id integer NOT NULL
);


ALTER TABLE public.easy_thumbnails_thumbnail OWNER TO "pro-nsw-admin";

--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.easy_thumbnails_thumbnail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.easy_thumbnails_thumbnail_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.easy_thumbnails_thumbnail_id_seq OWNED BY public.easy_thumbnails_thumbnail.id;


--
-- Name: easy_thumbnails_thumbnaildimensions; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.easy_thumbnails_thumbnaildimensions (
    id integer NOT NULL,
    thumbnail_id integer NOT NULL,
    width integer,
    height integer,
    CONSTRAINT easy_thumbnails_thumbnaildimensions_height_check CHECK ((height >= 0)),
    CONSTRAINT easy_thumbnails_thumbnaildimensions_width_check CHECK ((width >= 0))
);


ALTER TABLE public.easy_thumbnails_thumbnaildimensions OWNER TO "pro-nsw-admin";

--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.easy_thumbnails_thumbnaildimensions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.easy_thumbnails_thumbnaildimensions_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.easy_thumbnails_thumbnaildimensions_id_seq OWNED BY public.easy_thumbnails_thumbnaildimensions.id;


--
-- Name: products_brand; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.products_brand (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(50) NOT NULL,
    the_order integer NOT NULL,
    CONSTRAINT products_brand_the_order_check CHECK ((the_order >= 0))
);


ALTER TABLE public.products_brand OWNER TO "pro-nsw-admin";

--
-- Name: products_brand_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.products_brand_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_brand_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: products_brand_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.products_brand_id_seq OWNED BY public.products_brand.id;


--
-- Name: products_category; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.products_category (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    title_en character varying(255) NOT NULL,
    subtitle character varying(255),
    description text,
    hero character varying(100) NOT NULL,
    photo character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    level integer NOT NULL,
    parent_id bigint,
    the_order integer NOT NULL,
    CONSTRAINT products_category_level_check CHECK ((level >= 0)),
    CONSTRAINT products_category_lft_check CHECK ((lft >= 0)),
    CONSTRAINT products_category_rght_check CHECK ((rght >= 0)),
    CONSTRAINT products_category_the_order_check CHECK ((the_order >= 0)),
    CONSTRAINT products_category_tree_id_check CHECK ((tree_id >= 0))
);


ALTER TABLE public.products_category OWNER TO "pro-nsw-admin";

--
-- Name: products_category_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.products_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_category_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: products_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.products_category_id_seq OWNED BY public.products_category.id;


--
-- Name: products_facility; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.products_facility (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(100) NOT NULL,
    the_order integer NOT NULL,
    CONSTRAINT products_facility_the_order_check CHECK ((the_order >= 0))
);


ALTER TABLE public.products_facility OWNER TO "pro-nsw-admin";

--
-- Name: products_facility_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.products_facility_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_facility_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: products_facility_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.products_facility_id_seq OWNED BY public.products_facility.id;


--
-- Name: products_industry; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.products_industry (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    hero character varying(100) NOT NULL,
    photo character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    the_order integer NOT NULL,
    CONSTRAINT products_industry_the_order_check CHECK ((the_order >= 0))
);


ALTER TABLE public.products_industry OWNER TO "pro-nsw-admin";

--
-- Name: products_industry_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.products_industry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_industry_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: products_industry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.products_industry_id_seq OWNED BY public.products_industry.id;


--
-- Name: products_photo; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.products_photo (
    id bigint NOT NULL,
    photo character varying(100) NOT NULL,
    label character varying(100) NOT NULL,
    product_id bigint NOT NULL
);


ALTER TABLE public.products_photo OWNER TO "pro-nsw-admin";

--
-- Name: products_photo_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.products_photo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_photo_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: products_photo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.products_photo_id_seq OWNED BY public.products_photo.id;


--
-- Name: products_product; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.products_product (
    id bigint NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    title character varying(255) NOT NULL,
    subtitle character varying(255),
    markcode integer NOT NULL,
    slug character varying(50) NOT NULL,
    price integer,
    description text,
    is_published boolean NOT NULL,
    is_new boolean NOT NULL,
    shipping_date timestamp with time zone,
    hero character varying(100),
    handling_water text,
    handling_time text,
    handling_temp text,
    handling_recipe text,
    brand_id bigint,
    series_id bigint,
    packing character varying(255),
    additive text,
    caution text,
    country character varying(255),
    expiration_date character varying(255),
    gtin bigint,
    pos bigint,
    freespace_a text,
    freespace_b text,
    freespace_c text,
    handling_extra text,
    handling_link character varying(255),
    carton_depth character varying(100),
    carton_height character varying(100),
    carton_weight character varying(100),
    carton_width character varying(100),
    packing_depth character varying(100),
    packing_height character varying(100),
    packing_weight character varying(100),
    packing_width character varying(100),
    the_order integer NOT NULL,
    CONSTRAINT products_product_markcode_check CHECK ((markcode >= 0)),
    CONSTRAINT products_product_price_check CHECK ((price >= 0)),
    CONSTRAINT products_product_the_order_check CHECK ((the_order >= 0))
);


ALTER TABLE public.products_product OWNER TO "pro-nsw-admin";

--
-- Name: products_product_category; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.products_product_category (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    category_id bigint NOT NULL
);


ALTER TABLE public.products_product_category OWNER TO "pro-nsw-admin";

--
-- Name: products_product_category_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.products_product_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_product_category_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: products_product_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.products_product_category_id_seq OWNED BY public.products_product_category.id;


--
-- Name: products_product_facility; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.products_product_facility (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    facility_id bigint NOT NULL
);


ALTER TABLE public.products_product_facility OWNER TO "pro-nsw-admin";

--
-- Name: products_product_facility_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.products_product_facility_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_product_facility_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: products_product_facility_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.products_product_facility_id_seq OWNED BY public.products_product_facility.id;


--
-- Name: products_product_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.products_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_product_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: products_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.products_product_id_seq OWNED BY public.products_product.id;


--
-- Name: products_product_industry; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.products_product_industry (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    industry_id bigint NOT NULL
);


ALTER TABLE public.products_product_industry OWNER TO "pro-nsw-admin";

--
-- Name: products_product_industry_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.products_product_industry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_product_industry_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: products_product_industry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.products_product_industry_id_seq OWNED BY public.products_product_industry.id;


--
-- Name: products_product_related; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.products_product_related (
    id bigint NOT NULL,
    from_product_id bigint NOT NULL,
    to_product_id bigint NOT NULL
);


ALTER TABLE public.products_product_related OWNER TO "pro-nsw-admin";

--
-- Name: products_product_related_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.products_product_related_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_product_related_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: products_product_related_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.products_product_related_id_seq OWNED BY public.products_product_related.id;


--
-- Name: products_product_tag; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.products_product_tag (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    tag_id bigint NOT NULL
);


ALTER TABLE public.products_product_tag OWNER TO "pro-nsw-admin";

--
-- Name: products_product_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.products_product_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_product_tag_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: products_product_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.products_product_tag_id_seq OWNED BY public.products_product_tag.id;


--
-- Name: products_series; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.products_series (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(50) NOT NULL,
    brand_id bigint,
    the_order integer NOT NULL,
    CONSTRAINT products_series_the_order_check CHECK ((the_order >= 0))
);


ALTER TABLE public.products_series OWNER TO "pro-nsw-admin";

--
-- Name: products_series_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.products_series_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_series_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: products_series_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.products_series_id_seq OWNED BY public.products_series.id;


--
-- Name: products_tag; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.products_tag (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(100) NOT NULL,
    the_order integer NOT NULL,
    CONSTRAINT products_tag_the_order_check CHECK ((the_order >= 0))
);


ALTER TABLE public.products_tag OWNER TO "pro-nsw-admin";

--
-- Name: products_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.products_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_tag_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: products_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.products_tag_id_seq OWNED BY public.products_tag.id;


--
-- Name: socialaccount_socialaccount; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.socialaccount_socialaccount (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    uid character varying(191) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    extra_data text NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.socialaccount_socialaccount OWNER TO "pro-nsw-admin";

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.socialaccount_socialaccount_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialaccount_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.socialaccount_socialaccount_id_seq OWNED BY public.socialaccount_socialaccount.id;


--
-- Name: socialaccount_socialapp; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.socialaccount_socialapp (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    name character varying(40) NOT NULL,
    client_id character varying(191) NOT NULL,
    secret character varying(191) NOT NULL,
    key character varying(191) NOT NULL
);


ALTER TABLE public.socialaccount_socialapp OWNER TO "pro-nsw-admin";

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.socialaccount_socialapp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.socialaccount_socialapp_id_seq OWNED BY public.socialaccount_socialapp.id;


--
-- Name: socialaccount_socialapp_sites; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.socialaccount_socialapp_sites (
    id bigint NOT NULL,
    socialapp_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialapp_sites OWNER TO "pro-nsw-admin";

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.socialaccount_socialapp_sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_sites_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.socialaccount_socialapp_sites_id_seq OWNED BY public.socialaccount_socialapp_sites.id;


--
-- Name: socialaccount_socialtoken; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.socialaccount_socialtoken (
    id integer NOT NULL,
    token text NOT NULL,
    token_secret text NOT NULL,
    expires_at timestamp with time zone,
    account_id integer NOT NULL,
    app_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialtoken OWNER TO "pro-nsw-admin";

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.socialaccount_socialtoken_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialtoken_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.socialaccount_socialtoken_id_seq OWNED BY public.socialaccount_socialtoken.id;


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.users_user (
    id bigint NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.users_user OWNER TO "pro-nsw-admin";

--
-- Name: users_user_groups; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.users_user_groups (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.users_user_groups OWNER TO "pro-nsw-admin";

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.users_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_groups_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.users_user_groups_id_seq OWNED BY public.users_user_groups.id;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users_user.id;


--
-- Name: users_user_user_permissions; Type: TABLE; Schema: public; Owner: pro-nsw-admin
--

CREATE TABLE public.users_user_user_permissions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.users_user_user_permissions OWNER TO "pro-nsw-admin";

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: pro-nsw-admin
--

CREATE SEQUENCE public.users_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_user_permissions_id_seq OWNER TO "pro-nsw-admin";

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pro-nsw-admin
--

ALTER SEQUENCE public.users_user_user_permissions_id_seq OWNED BY public.users_user_user_permissions.id;


--
-- Name: account_emailaddress id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.account_emailaddress ALTER COLUMN id SET DEFAULT nextval('public.account_emailaddress_id_seq'::regclass);


--
-- Name: account_emailconfirmation id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.account_emailconfirmation ALTER COLUMN id SET DEFAULT nextval('public.account_emailconfirmation_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_celery_beat_clockedschedule id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_celery_beat_clockedschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_clockedschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_crontabschedule id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_celery_beat_crontabschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_crontabschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_intervalschedule id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_celery_beat_intervalschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_intervalschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_periodictask id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_celery_beat_periodictask ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_periodictask_id_seq'::regclass);


--
-- Name: django_celery_beat_solarschedule id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_solarschedule_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: easy_thumbnails_source id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.easy_thumbnails_source ALTER COLUMN id SET DEFAULT nextval('public.easy_thumbnails_source_id_seq'::regclass);


--
-- Name: easy_thumbnails_thumbnail id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnail ALTER COLUMN id SET DEFAULT nextval('public.easy_thumbnails_thumbnail_id_seq'::regclass);


--
-- Name: easy_thumbnails_thumbnaildimensions id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions ALTER COLUMN id SET DEFAULT nextval('public.easy_thumbnails_thumbnaildimensions_id_seq'::regclass);


--
-- Name: products_brand id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_brand ALTER COLUMN id SET DEFAULT nextval('public.products_brand_id_seq'::regclass);


--
-- Name: products_category id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_category ALTER COLUMN id SET DEFAULT nextval('public.products_category_id_seq'::regclass);


--
-- Name: products_facility id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_facility ALTER COLUMN id SET DEFAULT nextval('public.products_facility_id_seq'::regclass);


--
-- Name: products_industry id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_industry ALTER COLUMN id SET DEFAULT nextval('public.products_industry_id_seq'::regclass);


--
-- Name: products_photo id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_photo ALTER COLUMN id SET DEFAULT nextval('public.products_photo_id_seq'::regclass);


--
-- Name: products_product id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product ALTER COLUMN id SET DEFAULT nextval('public.products_product_id_seq'::regclass);


--
-- Name: products_product_category id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_category ALTER COLUMN id SET DEFAULT nextval('public.products_product_category_id_seq'::regclass);


--
-- Name: products_product_facility id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_facility ALTER COLUMN id SET DEFAULT nextval('public.products_product_facility_id_seq'::regclass);


--
-- Name: products_product_industry id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_industry ALTER COLUMN id SET DEFAULT nextval('public.products_product_industry_id_seq'::regclass);


--
-- Name: products_product_related id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_related ALTER COLUMN id SET DEFAULT nextval('public.products_product_related_id_seq'::regclass);


--
-- Name: products_product_tag id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_tag ALTER COLUMN id SET DEFAULT nextval('public.products_product_tag_id_seq'::regclass);


--
-- Name: products_series id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_series ALTER COLUMN id SET DEFAULT nextval('public.products_series_id_seq'::regclass);


--
-- Name: products_tag id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_tag ALTER COLUMN id SET DEFAULT nextval('public.products_tag_id_seq'::regclass);


--
-- Name: socialaccount_socialaccount id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.socialaccount_socialaccount ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialaccount_id_seq'::regclass);


--
-- Name: socialaccount_socialapp id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.socialaccount_socialapp ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_id_seq'::regclass);


--
-- Name: socialaccount_socialapp_sites id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_sites_id_seq'::regclass);


--
-- Name: socialaccount_socialtoken id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.socialaccount_socialtoken ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialtoken_id_seq'::regclass);


--
-- Name: users_user id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.users_user ALTER COLUMN id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: users_user_groups id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.users_user_groups ALTER COLUMN id SET DEFAULT nextval('public.users_user_groups_id_seq'::regclass);


--
-- Name: users_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.users_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.users_user_user_permissions_id_seq'::regclass);


--
-- Data for Name: account_emailaddress; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.account_emailaddress (id, email, verified, "primary", user_id) FROM stdin;
\.


--
-- Data for Name: account_emailconfirmation; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.account_emailconfirmation (id, created, sent, key, email_address_id) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can view permission	1	view_permission
5	Can add group	2	add_group
6	Can change group	2	change_group
7	Can delete group	2	delete_group
8	Can view group	2	view_group
9	Can add content type	3	add_contenttype
10	Can change content type	3	change_contenttype
11	Can delete content type	3	delete_contenttype
12	Can view content type	3	view_contenttype
13	Can add session	4	add_session
14	Can change session	4	change_session
15	Can delete session	4	delete_session
16	Can view session	4	view_session
17	Can add site	5	add_site
18	Can change site	5	change_site
19	Can delete site	5	delete_site
20	Can view site	5	view_site
21	Can add log entry	6	add_logentry
22	Can change log entry	6	change_logentry
23	Can delete log entry	6	delete_logentry
24	Can view log entry	6	view_logentry
25	Can add email address	7	add_emailaddress
26	Can change email address	7	change_emailaddress
27	Can delete email address	7	delete_emailaddress
28	Can view email address	7	view_emailaddress
29	Can add email confirmation	8	add_emailconfirmation
30	Can change email confirmation	8	change_emailconfirmation
31	Can delete email confirmation	8	delete_emailconfirmation
32	Can view email confirmation	8	view_emailconfirmation
33	Can add social account	9	add_socialaccount
34	Can change social account	9	change_socialaccount
35	Can delete social account	9	delete_socialaccount
36	Can view social account	9	view_socialaccount
37	Can add social application	10	add_socialapp
38	Can change social application	10	change_socialapp
39	Can delete social application	10	delete_socialapp
40	Can view social application	10	view_socialapp
41	Can add social application token	11	add_socialtoken
42	Can change social application token	11	change_socialtoken
43	Can delete social application token	11	delete_socialtoken
44	Can view social application token	11	view_socialtoken
45	Can add crontab	12	add_crontabschedule
46	Can change crontab	12	change_crontabschedule
47	Can delete crontab	12	delete_crontabschedule
48	Can view crontab	12	view_crontabschedule
49	Can add interval	13	add_intervalschedule
50	Can change interval	13	change_intervalschedule
51	Can delete interval	13	delete_intervalschedule
52	Can view interval	13	view_intervalschedule
53	Can add periodic task	14	add_periodictask
54	Can change periodic task	14	change_periodictask
55	Can delete periodic task	14	delete_periodictask
56	Can view periodic task	14	view_periodictask
57	Can add periodic tasks	15	add_periodictasks
58	Can change periodic tasks	15	change_periodictasks
59	Can delete periodic tasks	15	delete_periodictasks
60	Can view periodic tasks	15	view_periodictasks
61	Can add solar event	16	add_solarschedule
62	Can change solar event	16	change_solarschedule
63	Can delete solar event	16	delete_solarschedule
64	Can view solar event	16	view_solarschedule
65	Can add clocked	17	add_clockedschedule
66	Can change clocked	17	change_clockedschedule
67	Can delete clocked	17	delete_clockedschedule
68	Can view clocked	17	view_clockedschedule
69	Can add Token	18	add_token
70	Can change Token	18	change_token
71	Can delete Token	18	delete_token
72	Can view Token	18	view_token
73	Can add token	19	add_tokenproxy
74	Can change token	19	change_tokenproxy
75	Can delete token	19	delete_tokenproxy
76	Can view token	19	view_tokenproxy
77	Can add user	20	add_user
78	Can change user	20	change_user
79	Can delete user	20	delete_user
80	Can view user	20	view_user
81	Can add source	21	add_source
82	Can change source	21	change_source
83	Can delete source	21	delete_source
84	Can view source	21	view_source
85	Can add thumbnail	22	add_thumbnail
86	Can change thumbnail	22	change_thumbnail
87	Can delete thumbnail	22	delete_thumbnail
88	Can view thumbnail	22	view_thumbnail
89	Can add thumbnail dimensions	23	add_thumbnaildimensions
90	Can change thumbnail dimensions	23	change_thumbnaildimensions
91	Can delete thumbnail dimensions	23	delete_thumbnaildimensions
92	Can view thumbnail dimensions	23	view_thumbnaildimensions
93	Can add category	24	add_category
94	Can change category	24	change_category
95	Can delete category	24	delete_category
96	Can view category	24	view_category
97	Can add product	25	add_product
98	Can change product	25	change_product
99	Can delete product	25	delete_product
100	Can view product	25	view_product
101	Can add facility	26	add_facility
102	Can change facility	26	change_facility
103	Can delete facility	26	delete_facility
104	Can view facility	26	view_facility
105	Can add industry	27	add_industry
106	Can change industry	27	change_industry
107	Can delete industry	27	delete_industry
108	Can view industry	27	view_industry
109	Can add tag	28	add_tag
110	Can change tag	28	change_tag
111	Can delete tag	28	delete_tag
112	Can view tag	28	view_tag
113	Can add series	29	add_series
114	Can change series	29	change_series
115	Can delete series	29	delete_series
116	Can view series	29	view_series
117	Can add photo	30	add_photo
118	Can change photo	30	change_photo
119	Can delete photo	30	delete_photo
120	Can view photo	30	view_photo
121	Can add handling	31	add_handling
122	Can change handling	31	change_handling
123	Can delete handling	31	delete_handling
124	Can view handling	31	view_handling
125	Can add brand	32	add_brand
126	Can change brand	32	change_brand
127	Can delete brand	32	delete_brand
128	Can view brand	32	view_brand
\.


--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.authtoken_token (key, created, user_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2022-03-16 16:37:04.310578+00	1	フライ	1	[{"added": {}}]	26	1
2	2022-03-16 16:37:15.046821+00	2	ボイル	1	[{"added": {}}]	26	1
3	2022-03-16 16:37:21.100937+00	3	ベイク	1	[{"added": {}}]	26	1
4	2022-03-16 16:37:31.633568+00	4	スチーム	1	[{"added": {}}]	26	1
5	2022-03-16 16:37:40.068893+00	5	レンジ	1	[{"added": {}}]	26	1
6	2022-03-16 16:38:53.674929+00	1	Industry object (1)	1	[{"added": {}}]	27	1
7	2022-03-16 16:39:43.986265+00	2	Industry object (2)	1	[{"added": {}}]	27	1
8	2022-03-16 16:40:15.958955+00	3	Industry object (3)	1	[{"added": {}}]	27	1
9	2022-03-16 16:41:14.873745+00	4	Industry object (4)	1	[{"added": {}}]	27	1
10	2022-03-16 16:41:35.263661+00	5	Industry object (5)	1	[{"added": {}}]	27	1
11	2022-03-16 16:41:47.701909+00	5	Industry object (5)	2	[{"changed": {"fields": ["Slug"]}}]	27	1
12	2022-03-16 16:42:06.782095+00	6	Industry object (6)	1	[{"added": {}}]	27	1
13	2022-03-16 16:43:05.72383+00	7	Industry object (7)	1	[{"added": {}}]	27	1
14	2022-03-16 16:45:20.684163+00	1	Tag object (1)	1	[{"added": {}}]	28	1
15	2022-03-16 16:45:55.756923+00	2	Tag object (2)	1	[{"added": {}}]	28	1
16	2022-03-16 16:46:09.507448+00	3	Tag object (3)	1	[{"added": {}}]	28	1
17	2022-03-16 22:25:26.204892+00	1	天ぷら粉	1	[{"added": {}}]	24	1
18	2022-03-16 22:25:44.508767+00	2	から揚げ粉	1	[{"added": {}}]	24	1
19	2022-03-16 22:26:00.503909+00	3	バッター・打ち粉	1	[{"added": {}}]	24	1
20	2022-03-16 22:26:18.264468+00	4	和風メニュー(お好み焼・たこ焼他)	1	[{"added": {}}]	24	1
21	2022-03-16 22:26:29.605656+00	5	洋風メニュー(スイーツ他)	1	[{"added": {}}]	24	1
22	2022-03-16 22:26:47.194221+00	6	ロングパスタ	1	[{"added": {}}]	24	1
23	2022-03-16 22:27:00.34162+00	6	ロングパスタ	2	[{"changed": {"fields": ["Slug"]}}]	24	1
24	2022-03-16 22:27:17.723534+00	6	ロングパスタ	2	[{"changed": {"fields": ["Slug"]}}]	24	1
25	2022-03-16 22:27:35.405441+00	7	ショートパスタ	1	[{"added": {}}]	24	1
26	2022-03-16 22:28:21.988658+00	8	調理済みパスタ	1	[{"added": {}}]	24	1
27	2022-03-16 22:29:49.155407+00	9	パスタソース	1	[{"added": {}}]	24	1
28	2022-03-16 22:33:47.362556+00	10	かるサクシリーズ	1	[{"added": {}}]	24	1
29	2022-03-16 22:34:07.128636+00	11	揚げ上手シリーズ	1	[{"added": {}}]	24	1
30	2022-03-16 22:34:29.168371+00	12	調理行程削減	1	[{"added": {}}]	24	1
31	2022-03-16 22:34:46.677785+00	13	水溶き	1	[{"added": {}}]	24	1
32	2022-03-16 22:35:07.989083+00	14	漬け込みまぶしタイプ	1	[{"added": {}}]	24	1
33	2022-03-16 22:35:39.286071+00	15	水溶きまぶし	1	[{"added": {}}]	24	1
34	2022-03-16 22:35:51.885096+00	16	まぶしタイプ	1	[{"added": {}}]	24	1
35	2022-03-16 22:36:08.569938+00	17	味つき	1	[{"added": {}}]	24	1
36	2022-03-16 22:36:23.381128+00	18	味なし	1	[{"added": {}}]	24	1
37	2022-03-16 22:37:22.854336+00	3	バッター・打ち粉	2	[{"changed": {"fields": ["Slug"]}}]	24	1
38	2022-03-16 22:37:37.476089+00	19	打ち粉	1	[{"added": {}}]	24	1
39	2022-03-16 22:37:50.723427+00	20	バッター	1	[{"added": {}}]	24	1
40	2022-03-16 22:38:14.230305+00	21	畜肉用	1	[{"added": {}}]	24	1
41	2022-03-16 22:38:31.960561+00	22	魚介用	1	[{"added": {}}]	24	1
42	2022-03-16 22:38:48.889763+00	23	たこ焼	1	[{"added": {}}]	24	1
43	2022-03-16 22:39:41.618419+00	24	お好み焼	1	[{"added": {}}]	24	1
44	2022-03-16 22:39:56.015408+00	25	鯛焼き	1	[{"added": {}}]	24	1
45	2022-03-16 22:40:10.071507+00	26	大判焼き	1	[{"added": {}}]	24	1
46	2022-03-16 22:40:36.725241+00	27	冷麺	1	[{"added": {}}]	24	1
47	2022-03-16 22:40:53.015774+00	28	パンケーキ	1	[{"added": {}}]	24	1
48	2022-03-16 22:41:55.527437+00	29	クレープ	1	[{"added": {}}]	24	1
49	2022-03-16 22:42:15.162005+00	30	ホットケーキ	1	[{"added": {}}]	24	1
50	2022-03-16 22:42:32.055103+00	31	蒸しパン	1	[{"added": {}}]	24	1
51	2022-03-16 22:42:49.521892+00	32	ワッフル	1	[{"added": {}}]	24	1
52	2022-03-16 22:43:12.566808+00	33	ピザ	1	[{"added": {}}]	24	1
53	2022-03-16 22:44:11.560764+00	34	チュロス	1	[{"added": {}}]	24	1
54	2022-03-16 22:44:41.076913+00	35	ホワイトソース	1	[{"added": {}}]	24	1
55	2022-03-16 22:45:47.260737+00	36	～1.5㎜	1	[{"added": {}}]	24	1
56	2022-03-16 22:46:13.860504+00	37	1.6～1.7㎜	1	[{"added": {}}]	24	1
57	2022-03-16 22:46:34.748149+00	38	1.8㎜～	1	[{"added": {}}]	24	1
58	2022-03-16 22:46:51.460229+00	39	ハーフ	1	[{"added": {}}]	24	1
59	2022-03-16 22:47:09.010334+00	40	乾麺	1	[{"added": {}}]	24	1
60	2022-03-16 22:47:29.039531+00	41	生麺	1	[{"added": {}}]	24	1
61	2022-03-16 22:47:49.97693+00	42	ゆで時間短縮	1	[{"added": {}}]	24	1
62	2022-03-16 22:48:47.548311+00	43	ディチェコ	1	[{"added": {}}]	24	1
63	2022-03-16 22:50:14.63273+00	44	ストレートマカロニ	1	[{"added": {}}]	24	1
64	2022-03-16 22:51:35.398483+00	45	フィジリ	1	[{"added": {}}]	24	1
65	2022-03-16 22:52:57.649484+00	46	ペンネ	1	[{"added": {}}]	24	1
66	2022-03-16 22:53:11.265721+00	47	シェル	1	[{"added": {}}]	24	1
67	2022-03-16 22:53:36.112306+00	48	その他	1	[{"added": {}}]	24	1
68	2022-03-16 22:54:42.508174+00	49	ディチェコ	1	[{"added": {}}]	24	1
69	2022-03-16 22:55:23.120165+00	50	ワンディッシュ	1	[{"added": {}}]	24	1
70	2022-03-16 22:55:44.98027+00	51	付け合わせ	1	[{"added": {}}]	24	1
71	2022-03-16 22:56:16.838947+00	52	パウチ	1	[{"added": {}}]	24	1
72	2022-03-16 22:56:54.640728+00	53	缶	1	[{"added": {}}]	24	1
73	2022-03-16 22:57:14.665255+00	54	チューブ	1	[{"added": {}}]	24	1
74	2022-03-17 01:05:08.01731+00	4	その他	1	[{"added": {}}]	28	1
75	2022-03-17 01:05:16.966209+00	4	その他	3		28	1
76	2022-03-17 01:19:49.09893+00	22	天ぷら粉かるサク衣	1	[{"added": {}}]	25	1
77	2022-03-17 01:27:23.687+00	22	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Slug"]}}]	25	1
78	2022-03-17 01:27:43.754066+00	22	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
79	2022-03-17 02:10:26.186449+00	22	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Is new"]}}]	25	1
80	2022-03-19 09:59:20.995967+00	22	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Tag"]}}]	25	1
81	2022-03-19 10:20:54.608389+00	22	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Tag"]}}]	25	1
82	2022-03-19 10:21:08.498969+00	22	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Facility"]}}]	25	1
83	2022-03-19 10:28:19.594134+00	22	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Facility"]}}]	25	1
84	2022-03-19 13:45:25.907783+00	22	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Facility"]}}]	25	1
85	2022-03-19 13:54:14.874048+00	22	天ぷら粉かるサク衣	2	[]	25	1
86	2022-03-19 13:54:33.411458+00	22	天ぷら粉かるサク衣	2	[{"added": {"name": "photo", "object": "Photo object (1)"}}]	25	1
87	2022-03-19 13:54:55.148145+00	22	天ぷら粉かるサク衣	2	[{"changed": {"name": "photo", "object": "Photo object (1)", "fields": ["Label"]}}]	25	1
88	2022-03-20 02:47:41.620041+00	1	天ぷら粉ー	1	[{"added": {}}]	25	1
89	2022-03-20 03:32:59.393871+00	1	Handling object (1)	1	[{"added": {}}]	31	1
90	2022-03-20 03:34:04.744179+00	1	hanachan	1	[{"added": {}}]	25	1
91	2022-03-20 05:04:04.870217+00	2	ｆｄさ	1	[{"added": {}}]	24	1
92	2022-03-20 05:04:11.359569+00	2	ｆｄさ	3		24	1
93	2022-03-20 05:10:18.894824+00	1	天ぷら粉かるサク衣	1	[{"added": {}}]	25	1
94	2022-03-20 05:13:23.798728+00	1	天ぷら粉	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
95	2022-03-20 05:29:47.448395+00	1	天ぷら粉	2	[]	24	1
96	2022-03-20 05:30:16.558707+00	10	かるサクシリーズ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
97	2022-03-20 05:30:27.710907+00	11	揚げ上手シリーズ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
98	2022-03-20 05:30:36.91712+00	12	調理行程削減	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
99	2022-03-20 05:30:43.486888+00	2	から揚げ粉	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
100	2022-03-20 05:30:52.38943+00	13	水溶き	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
101	2022-03-20 05:31:00.400952+00	14	漬け込みまぶしタイプ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
102	2022-03-20 05:31:11.494682+00	15	水溶きまぶし	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
103	2022-03-20 05:31:23.69881+00	16	まぶしタイプ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
104	2022-03-20 05:31:35.997789+00	17	味つき	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
105	2022-03-20 05:31:43.530979+00	18	味なし	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
106	2022-03-20 05:31:53.562697+00	3	バッター・打ち粉	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
107	2022-03-20 05:31:53.744742+00	3	バッター・打ち粉	2	[]	24	1
108	2022-03-20 05:32:00.520281+00	19	打ち粉	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
109	2022-03-20 05:32:07.844191+00	20	バッター	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
110	2022-03-20 05:32:16.663157+00	21	畜肉用	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
111	2022-03-20 05:32:25.303485+00	22	魚介用	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
112	2022-03-20 05:32:38.613907+00	4	和風メニュー	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\u540d\\uff08\\u65e5\\u672c\\u8a9e\\uff09", "\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Subtitle"]}}]	24	1
113	2022-03-20 05:32:48.04928+00	23	たこ焼	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
114	2022-03-20 05:32:56.641971+00	24	お好み焼	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
115	2022-03-20 05:33:05.225128+00	25	鯛焼き	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
116	2022-03-20 05:33:20.341721+00	26	大判焼き	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
117	2022-03-20 05:33:29.591031+00	27	冷麺	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
118	2022-03-20 05:33:40.353945+00	5	洋風メニュー	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\u540d\\uff08\\u65e5\\u672c\\u8a9e\\uff09", "\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Subtitle"]}}]	24	1
119	2022-03-20 05:33:50.573112+00	28	パンケーキ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
120	2022-03-20 05:33:58.896049+00	29	クレープ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
121	2022-03-20 05:34:06.785246+00	30	ホットケーキ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
122	2022-03-20 05:34:14.639271+00	31	蒸しパン	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
123	2022-03-20 05:34:23.542553+00	32	ワッフル	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
124	2022-03-20 05:34:31.457463+00	33	ピザ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
125	2022-03-20 05:34:39.636433+00	34	チュロス	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
126	2022-03-20 05:34:50.759246+00	35	ホワイトソース	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
127	2022-03-20 05:35:00.712215+00	6	ロングパスタ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
128	2022-03-20 05:35:13.005533+00	36	～1.5㎜	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
129	2022-03-20 05:35:23.821298+00	37	1.6～1.7㎜	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
130	2022-03-20 05:35:34.60889+00	38	1.8㎜～	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
131	2022-03-20 05:35:43.85964+00	39	ハーフ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
132	2022-03-20 05:35:51.153248+00	40	乾麺	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
133	2022-03-20 05:35:58.479731+00	41	生麺	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
663	2022-03-23 08:51:47.653775+00	6	ロングパスタ	2	[{"changed": {"fields": ["Hero"]}}]	24	1
134	2022-03-20 05:36:08.539953+00	42	ゆで時間短縮	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
135	2022-03-20 05:36:17.060778+00	43	ディチェコ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
136	2022-03-20 05:36:26.673684+00	7	ショートパスタ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
137	2022-03-20 05:36:36.257872+00	44	ストレートマカロニ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
138	2022-03-20 05:36:43.949415+00	45	フィジリ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
139	2022-03-20 05:36:53.54535+00	46	ペンネ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
140	2022-03-20 05:37:02.480747+00	47	シェル	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
141	2022-03-20 05:37:12.781827+00	48	その他	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
142	2022-03-20 05:37:26.398809+00	49	ディチェコ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
143	2022-03-20 05:37:35.973699+00	8	調理済みパスタ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
144	2022-03-20 05:37:45.554132+00	50	ワンディッシュ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
145	2022-03-20 05:37:55.626896+00	51	付け合わせ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
146	2022-03-20 05:38:05.70104+00	9	パスタソース	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
147	2022-03-20 05:38:18.344779+00	52	パウチ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
148	2022-03-20 05:38:27.972865+00	53	缶	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
149	2022-03-20 05:38:35.966495+00	54	チューブ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
150	2022-03-20 05:46:42.471415+00	1	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Description"]}}]	25	1
151	2022-03-20 05:48:11.814491+00	1	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Packing"]}}]	25	1
152	2022-03-20 06:06:48.603452+00	1	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Preservation"]}}]	25	1
153	2022-03-20 06:07:06.170329+00	1	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Subtitle"]}}]	25	1
154	2022-03-20 06:41:37.027206+00	1	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Industry"]}}]	25	1
155	2022-03-20 06:41:48.010977+00	1	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Tag", "Facility"]}}]	25	1
156	2022-03-20 06:42:53.710425+00	1	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Is new"]}}]	25	1
157	2022-03-20 06:46:32.325331+00	1	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Is new"]}}]	25	1
158	2022-03-20 06:47:54.084057+00	1	マ・マーTHE PROブランド	1	[{"added": {}}]	32	1
159	2022-03-20 06:49:52.573448+00	1	PASTA  STELLAシリーズ	1	[{"added": {}}]	29	1
160	2022-03-20 06:50:56.05255+00	1	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Brand", "Series"]}}]	25	1
161	2022-03-20 07:01:00.980659+00	1	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Facility"]}}]	25	1
162	2022-03-21 00:16:13.699931+00	1	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Handling water"]}}]	25	1
163	2022-03-21 01:48:25.424692+00	1	pro.nisshin-seifun-welna.com	2	[{"changed": {"fields": ["Domain name"]}}]	5	1
164	2022-03-21 02:22:03.215305+00	1	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Related"]}}]	25	1
165	2022-03-21 05:29:16.720841+00	55	その他	1	[{"added": {}}]	24	1
166	2022-03-21 05:30:41.289424+00	4	冷凍	1	[{"added": {}}]	28	1
167	2022-03-21 05:31:05.576106+00	5	常温	1	[{"added": {}}]	28	1
168	2022-03-21 13:00:57.325253+00	1	天ぷら粉	2	[{"changed": {"fields": ["Photo"]}}]	24	1
169	2022-03-21 13:08:01.886771+00	10	かるサクシリーズ	2	[{"changed": {"fields": ["Photo"]}}]	24	1
170	2022-03-21 13:09:59.613302+00	10	かるサクシリーズ	2	[{"changed": {"fields": ["Photo"]}}]	24	1
171	2022-03-21 13:10:20.646841+00	2	から揚げ粉	2	[]	24	1
172	2022-03-21 13:11:04.344662+00	4	和風メニュー	2	[{"changed": {"fields": ["Photo"]}}]	24	1
173	2022-03-21 13:11:22.57459+00	9	パスタソース	2	[{"changed": {"fields": ["Photo"]}}]	24	1
174	2022-03-21 13:11:59.717759+00	6	ロングパスタ	2	[{"changed": {"fields": ["Photo"]}}]	24	1
175	2022-03-21 13:12:12.595088+00	7	ショートパスタ	2	[{"changed": {"fields": ["Photo"]}}]	24	1
176	2022-03-21 13:12:36.557669+00	2	から揚げ粉	2	[{"changed": {"fields": ["Photo"]}}]	24	1
177	2022-03-21 13:13:16.291029+00	55	その他	2	[{"changed": {"fields": ["Photo"]}}]	24	1
178	2022-03-21 13:17:39.548292+00	3	バッター・打ち粉	2	[{"changed": {"fields": ["Photo"]}}]	24	1
179	2022-03-21 13:18:47.51085+00	3	バッター・打ち粉	2	[{"changed": {"fields": ["Photo"]}}]	24	1
180	2022-03-21 13:18:56.257785+00	3	バッター・打ち粉	2	[{"changed": {"fields": ["Photo"]}}]	24	1
181	2022-03-21 13:19:33.227476+00	8	調理済みパスタ	2	[{"changed": {"fields": ["Photo"]}}]	24	1
182	2022-03-21 13:20:50.724933+00	2	から揚げ粉	2	[{"changed": {"fields": ["Photo"]}}]	24	1
183	2022-03-21 13:21:01.657709+00	2	から揚げ粉	2	[{"changed": {"fields": ["Photo"]}}]	24	1
184	2022-03-21 13:22:25.976982+00	5	洋風メニュー	2	[{"changed": {"fields": ["Photo"]}}]	24	1
185	2022-03-21 13:29:13.369079+00	55	その他	2	[{"changed": {"fields": ["Photo"]}}]	24	1
186	2022-03-21 13:29:25.902066+00	55	その他	2	[{"changed": {"fields": ["Photo"]}}]	24	1
187	2022-03-21 13:33:53.323804+00	7	ショートパスタ	2	[{"changed": {"fields": ["Photo"]}}]	24	1
188	2022-03-21 13:34:06.936609+00	7	ショートパスタ	2	[{"changed": {"fields": ["Photo"]}}]	24	1
189	2022-03-22 06:06:19.61937+00	1	天ぷら粉かるサク衣	2	[{"added": {"name": "photo", "object": "Photo object (1)"}}, {"added": {"name": "photo", "object": "Photo object (2)"}}]	25	1
190	2022-03-22 06:06:20.214488+00	1	天ぷら粉かるサク衣	2	[{"added": {"name": "photo", "object": "Photo object (3)"}}, {"added": {"name": "photo", "object": "Photo object (4)"}}]	25	1
191	2022-03-22 06:27:52.795832+00	1	天ぷら粉かるサク衣	2	[]	25	1
192	2022-03-22 08:26:39.451786+00	1	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Tag"]}}]	25	1
193	2022-03-22 12:39:29.548486+00	1	天ぷら粉かるサク衣	3		25	1
194	2022-03-22 12:41:23.916661+00	50	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
195	2022-03-22 12:42:41.167561+00	51	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
196	2022-03-22 12:43:36.032961+00	51	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Tag"]}}]	25	1
197	2022-03-22 12:44:54.579684+00	52	天ぷら粉打ち粉いらずのかるサク衣	2	[{"changed": {"fields": ["Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
198	2022-03-22 12:46:38.101052+00	53	天ぷら粉追い種いらずの揚げ上手	2	[{"changed": {"fields": ["Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
199	2022-03-22 12:57:01.073413+00	54	天ぷら粉打ち粉いらずの揚げ上手	2	[{"changed": {"fields": ["Description", "Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
200	2022-03-22 12:58:22.564632+00	55	天ぷら粉かる～い揚げ上手	2	[{"changed": {"fields": ["Description", "Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
201	2022-03-22 12:59:53.242392+00	56	天ぷら粉 かる～い揚げ上手Bタイプ	2	[{"changed": {"fields": ["Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
202	2022-03-22 13:01:02.514463+00	57	天ぷら粉レンジでサクサク揚げ上手	2	[{"changed": {"fields": ["Description", "Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
203	2022-03-22 13:02:26.623847+00	58	天ぷら粉揚げ上手	2	[{"changed": {"fields": ["Description", "Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
204	2022-03-22 13:03:34.26565+00	59	天ぷら粉揚げ上手	2	[{"changed": {"fields": ["Description", "Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
205	2022-03-22 13:05:00.004389+00	60	天ぷら粉揚げ上手Jタイプ	2	[{"changed": {"fields": ["Description", "Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
206	2022-03-22 13:06:06.647181+00	61	天ぷら粉揚げ上手Jタイプ	2	[{"changed": {"fields": ["Description", "Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
207	2022-03-22 13:07:16.998349+00	62	天ぷら粉揚げ上手Cタイプ	2	[{"changed": {"fields": ["Description", "Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
208	2022-03-22 13:08:31.678554+00	63	天ぷら粉揚げ上手Cタイプ	2	[{"changed": {"fields": ["Description", "Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
209	2022-03-22 13:09:33.678122+00	64	天ぷら粉軽やか衣	2	[{"changed": {"fields": ["Description", "Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
210	2022-03-22 13:10:51.022637+00	65	おいしい天ぷら粉	2	[{"changed": {"fields": ["Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
211	2022-03-22 13:11:43.422377+00	66	国内麦小麦粉使用おいしい天ぷら粉	2	[{"changed": {"fields": ["Description", "Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
212	2022-03-22 13:12:42.354714+00	67	天ぷら粉Aタイプ	2	[{"changed": {"fields": ["Packing", "Description", "Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
213	2022-03-22 13:14:03.753696+00	68	天ぷら粉Aタイプ	2	[{"changed": {"fields": ["Description", "Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
214	2022-03-22 13:14:56.509476+00	69	天ぷら粉A2タイプ	2	[{"changed": {"fields": ["Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
215	2022-03-22 13:15:52.400567+00	70	天ぷら粉Bタイプ	2	[{"changed": {"fields": ["Description", "Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
216	2022-03-22 13:16:51.04024+00	71	おそば屋さん・うどん屋さんの天ぷら粉 つゆにのせてもしっかり衣	2	[{"changed": {"fields": ["Description", "Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
217	2022-03-22 13:17:45.577085+00	72	おそば屋さん・うどん屋さんの天ぷら粉 つゆ溶け衣	2	[{"changed": {"fields": ["Description", "Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
218	2022-03-22 13:18:42.247491+00	73	天ぷら粉デラックス	2	[{"changed": {"fields": ["Description", "Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
219	2022-03-22 13:19:46.262082+00	74	天ぷら粉　味わい衣	2	[{"changed": {"fields": ["Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
220	2022-03-22 13:20:51.662998+00	75	天ぷら粉　パックに入れてもかるサク衣	2	[{"changed": {"fields": ["Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
221	2022-03-22 13:22:03.448423+00	76	THE KARAAGE から揚げ粉	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
222	2022-03-22 13:23:21.579824+00	77	聖地中津からあげセット しょうゆだれ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
223	2022-03-22 13:24:24.624052+00	78	聖地中津からあげセット 塩だれ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
224	2022-03-22 13:26:03.333689+00	79	から揚げ粉 #11-68	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
225	2022-03-22 13:27:09.112904+00	80	たつた揚げ粉 #13-35	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
226	2022-03-22 13:28:41.268769+00	81	から揚げ粉 唐揚王	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
227	2022-03-22 13:30:08.503526+00	82	から揚げ粉 唐揚王	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
228	2022-03-22 13:31:19.189132+00	83	から揚げ粉	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
229	2022-03-22 13:32:59.954692+00	84	から揚げミックス	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
230	2022-03-22 13:34:12.50738+00	85	から揚げ粉 にんにく・しょうゆ風味	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
231	2022-03-22 13:35:47.105224+00	86	から揚げ粉味付け自由な水溶きタイプ　中華街仕立て	2	[{"changed": {"fields": ["Title", "Category", "Tag", "Industry", "Facility"]}}]	25	1
232	2022-03-22 13:37:35.570312+00	87	薄衣サクサクから揚げ粉	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
233	2022-03-22 13:38:39.200179+00	88	ゴツゴツから揚げ粉	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
234	2022-03-22 13:39:46.60178+00	89	タレかけカリサクから揚げ粉	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
235	2022-03-22 13:40:48.446339+00	90	ザクザクから揚げ粉	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
236	2022-03-22 13:49:52.597738+00	91	THE TONKATSU	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
237	2022-03-22 13:52:25.711424+00	92	バッターミックス　これで結着！	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
238	2022-03-22 13:54:46.636538+00	93	バッターミックス サクミ長持ち上手！	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
239	2022-03-22 13:55:41.890006+00	94	コロッケ用ミックス　#23-58	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
240	2022-03-22 13:56:48.95824+00	95	コロッケ用ミックス　#63-01	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
241	2022-03-22 13:57:50.588568+00	96	パン粉が良くつく粉	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
242	2022-03-22 13:58:59.634263+00	97	打ち粉ミックス これで結着！	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
243	2022-03-22 13:59:58.872337+00	98	トンカツ用ミックス #24-25	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
244	2022-03-22 14:02:28.68197+00	99	海老フライ用ミックス #22-43	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
245	2022-03-22 14:04:52.324892+00	100	魚フライ用ミックス #62-60	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
246	2022-03-22 14:06:03.983458+00	101	メンチカツ用ミックス #24-HU	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
247	2022-03-22 14:07:06.105546+00	102	打ち粉ミックス（魚介用） #22-02	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
248	2022-03-22 14:08:04.878479+00	103	打ち粉ミックス（畜肉用） #24-93	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
249	2022-03-22 14:09:21.873449+00	104	たこ焼粉	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
250	2022-03-22 14:10:16.383037+00	105	お好み焼粉 山いも入り	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
251	2022-03-22 14:11:09.164492+00	106	達人厨房 ふんわりお好み焼粉	2	[{"changed": {"fields": ["Handling temp", "Handling recipe", "Category", "Tag", "Industry", "Facility"]}}]	25	1
252	2022-03-22 14:12:11.427314+00	107	しっとり食感！鯛焼きミックス	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
253	2022-03-22 14:13:10.95073+00	108	たい焼きミックス #916	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
254	2022-03-22 14:14:13.864649+00	109	大判焼きミックス #913	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
255	2022-03-22 14:15:38.727049+00	110	お好み焼きミックス #912	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
256	2022-03-22 14:16:43.674871+00	111	たこ焼きミックス #9CD	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
257	2022-03-22 14:17:59.979864+00	112	たこ焼横丁 関西丸たこ焼	2	[{"changed": {"fields": ["Handling time", "Handling temp", "Category", "Tag", "Industry", "Facility"]}}]	25	1
258	2022-03-22 14:19:14.284766+00	113	たこ焼横丁 Nたこ焼	2	[{"changed": {"fields": ["Handling time", "Handling temp", "Category", "Tag", "Industry", "Facility"]}}]	25	1
259	2022-03-22 14:20:16.952789+00	114	たこ焼横丁 大玉たこ焼	2	[{"changed": {"fields": ["Handling time", "Handling temp", "Category", "Tag", "Industry", "Facility"]}}]	25	1
260	2022-03-22 14:22:10.681362+00	115	Rお好み横丁 ふんわりお好み焼（豚玉）	2	[{"changed": {"fields": ["Handling time", "Handling temp", "Category", "Tag", "Industry", "Facility"]}}]	25	1
261	2022-03-22 14:23:26.65139+00	116	ふんわりお好み焼（豚天）	2	[{"changed": {"fields": ["Handling time", "Handling temp", "Category", "Tag", "Industry", "Facility"]}}]	25	1
262	2022-03-22 14:25:04.91132+00	117	冷凍のどごし冷麺	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
263	2022-03-22 14:25:52.978902+00	118	型のいらないホットケーキミックス 厚焼き上手	2	[{"changed": {"fields": ["Tag", "Industry", "Facility"]}}]	25	1
264	2022-03-22 14:27:19.560024+00	119	達人厨房 しっとりパンケーキMIX	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
265	2022-03-22 14:27:47.407363+00	118	型のいらないホットケーキミックス 厚焼き上手	2	[{"changed": {"fields": ["Category"]}}]	25	1
266	2022-03-22 14:29:16.845327+00	120	達人厨房 クレープMIX	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
267	2022-03-22 14:30:38.058509+00	121	ホットケーキミックス #503	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
268	2022-03-22 14:32:06.125469+00	122	パンケーキミックス #505	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
269	2022-03-22 14:33:05.099246+00	123	クレープミックス #707	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
270	2022-03-22 14:34:17.023656+00	124	水1リットルでできる蒸しパンミックス（白）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
271	2022-03-22 14:35:30.174623+00	125	水1リットルでできる蒸しパンミックス（黒）黒糖風味	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
272	2022-03-22 14:36:31.494842+00	126	サクサク食感！クリスピーワッフルミックス	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
273	2022-03-22 14:37:41.337036+00	127	ふわふわ食感！ソフトワッフルミックス	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
274	2022-03-22 14:38:29.932458+00	128	イースト不要！ベルギーワッフルミックス	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
275	2022-03-22 14:39:21.122123+00	129	ミシェーラ ナポリ風ピッツァミックス	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
276	2022-03-22 14:40:32.837202+00	130	ナポリ風ピッツァミックス	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
277	2022-03-22 14:41:37.773398+00	131	達人厨房 クリーミーホワイトソースMIX	2	[{"changed": {"fields": ["Handling recipe", "Category", "Tag", "Industry"]}}]	25	1
278	2022-03-22 14:42:47.622475+00	132	自然解凍ミニパンケーキ	2	[{"changed": {"fields": ["Handling time", "Handling temp", "Category", "Tag", "Industry", "Facility"]}}]	25	1
279	2022-03-22 14:43:59.14271+00	133	チュロス®（ハーフサイズ）フライ＆ベイク	2	[{"changed": {"fields": ["Handling time", "Handling temp", "Category", "Tag", "Industry", "Facility"]}}]	25	1
280	2022-03-22 14:45:01.7358+00	134	チュロス®	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
281	2022-03-22 14:46:24.977088+00	135	チュロス®（ミルク味）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
282	2022-03-22 14:47:29.300418+00	136	チュロス®（チョコ味）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
283	2022-03-22 14:49:13.31207+00	137	ミニチュロス	2	[{"changed": {"fields": ["Description", "Handling time", "Handling temp", "Category", "Tag", "Industry", "Facility"]}}]	25	1
284	2022-03-22 14:50:19.261531+00	138	ミニチュロス(チョコ味)	2	[{"changed": {"fields": ["Description", "Handling time", "Handling temp", "Category", "Tag", "Industry", "Facility"]}}]	25	1
285	2022-03-22 14:52:26.94448+00	139	マ・マー スパゲティ　1.4	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
286	2022-03-22 15:00:44.875422+00	140	マ・マー スパゲティ　1.6	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
287	2022-03-22 15:01:52.215098+00	141	マ・マー スパゲティ　1.7	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
288	2022-03-22 15:03:15.360424+00	142	マ・マー スパゲティ　1.9	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
289	2022-03-22 15:04:44.304235+00	143	マ・マー スパゲティ　2.2	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
290	2022-03-22 15:06:08.986741+00	144	早ゆでスパゲティプロント 1.6mm	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
291	2022-03-22 15:07:15.052722+00	145	早ゆでスパゲティプロント 1.6mm	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
292	2022-03-22 15:08:22.862785+00	146	マ・マー 早ゆでスパゲティ プロント 2.2mm	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
293	2022-03-22 15:09:48.327211+00	147	マ・マーTHE　PRO早ゆでスパゲティ1.6mm	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
294	2022-03-22 15:11:14.949556+00	148	マ・マー ミニスパゲティ　ミニ1.6	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
295	2022-03-22 15:12:30.042494+00	149	マ・マー ミニスパゲティ　ミニ1.7	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
296	2022-03-22 15:14:08.759466+00	150	マッシモ プレミオ #201　1.5	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
297	2022-03-22 15:15:32.323334+00	151	マッシモ プレミオ #201　1.5	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
298	2022-03-22 15:16:50.565995+00	152	マッシモ プレミオ #201　1.7	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
299	2022-03-22 15:18:08.787946+00	153	マッシモ プレミオ #201　1.7	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
300	2022-03-22 15:19:20.871429+00	154	スパゲッティーニ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
301	2022-03-22 15:20:20.382827+00	155	リングイネ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
302	2022-03-22 15:21:22.385711+00	156	フェットチーネ（卵入り）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
303	2022-03-22 15:23:02.000123+00	157	フェットチーネ（ほうれん草入り）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
304	2022-03-22 15:32:27.878004+00	158	タリオリーニ（卵入り）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
305	2022-03-22 15:33:46.319546+00	159	ラウンドアップスパゲティ Super Hardタイプ 1.6mm《塩ゆで》　180g	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
306	2022-03-22 15:34:55.293556+00	160	ラウンドアップスパゲティ Super Hardタイプ 1.6mm《塩ゆで》　220g	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
307	2022-03-22 15:36:09.568641+00	161	ラウンドアップスパゲティ Super Hardタイプ 1.6mm《塩ゆで》　250g	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
308	2022-03-22 15:37:18.529457+00	162	ラウンドアップスパゲティ 1.4mm《塩ゆで》	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
309	2022-03-22 15:38:35.51231+00	163	ラウンドアップスパゲティ 太麺タイプ 2.2mm《塩ゆで》	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
310	2022-03-22 15:39:52.446269+00	164	ラウンドアップスパゲティ 1.7mm PREMIUM《塩ゆで》	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
311	2022-03-22 15:40:52.716759+00	165	マッシモプレミオ 冷凍スパゲティ《塩ゆで》	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
312	2022-03-22 15:41:49.243318+00	166	Rスパゲティ 1.7mm【湯せんタイプ】	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
313	2022-03-22 15:42:45.373078+00	167	Rスパゲティ 1.7mm【湯せんタイプ】	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
314	2022-03-22 15:43:45.826377+00	168	Cool’s 冷製スパゲティR 1.4mm《塩ゆで》	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
315	2022-03-22 15:48:21.698692+00	169	MACARONI ブラウン 4-40	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
316	2022-03-22 15:49:37.56625+00	170	MACARONI マカロニ 4.7-30	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
317	2022-03-22 15:50:38.21544+00	171	MACARONI ペンネリガーテ 7-25	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
318	2022-03-22 15:51:38.742344+00	172	MACARONI サラダマカロニ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
319	2022-03-22 15:52:35.654112+00	173	MACARONI クルル	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
320	2022-03-22 15:53:44.26953+00	174	MACARONI デリカ201 クルル 9-15	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
321	2022-03-22 15:55:37.00426+00	175	MACARONI 野菜入りクルル	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
322	2022-03-22 15:56:41.934002+00	176	MACARONI シェル	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
323	2022-03-22 15:57:49.19389+00	177	MACARONI シェルスモール	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
324	2022-03-22 15:59:05.187768+00	178	MACARONI ツイスト	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
325	2022-03-22 16:00:34.016309+00	179	IQF（バラ凍結）ペンネリガーテ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
326	2022-03-22 20:10:23.656647+00	180	IQF（バラ凍結）フィジリ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
327	2022-03-22 20:11:46.152894+00	181	IQF（バラ凍結）リガトーニ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
328	2022-03-22 20:12:47.761623+00	182	IQF（バラ凍結）カサレッチャ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
329	2022-03-22 20:13:42.10467+00	183	IQF（バラ凍結）パッケリ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
330	2022-03-22 20:14:44.98855+00	184	マ・マー THE PRO IQF（バラ凍結）MINI フィジリ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
331	2022-03-22 20:15:40.940744+00	185	マ・マー THE PRO IQF（バラ凍結）MINI ストレートマカロニ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
332	2022-03-22 20:16:37.773223+00	186	マ・マー THE PRO IQF（バラ凍結）MINI シェル	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
333	2022-03-22 20:17:53.192204+00	187	PASTA STELLA ソテーナポリタン	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
334	2022-03-22 20:18:43.843746+00	188	PASTA STELLA 和風たらこ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
335	2022-03-22 20:19:26.683575+00	189	PASTA STELLA クリーミーカルボナーラ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
336	2022-03-22 20:20:07.792796+00	190	PASTA STELLA クリーミーボロネーゼ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
337	2022-03-22 20:20:50.124192+00	191	PASTA STELLA 濃厚海老トマトクリーム	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
338	2022-03-22 20:21:37.068214+00	192	PASTA STELLA ポルチーニクリーム	2	[{"changed": {"fields": ["Title", "Subtitle", "Category", "Tag", "Industry", "Facility"]}}]	25	1
339	2022-03-22 20:22:33.14804+00	193	レンジ用ソテースパゲティ ナポリタン	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
340	2022-03-22 20:23:30.351778+00	194	レンジ用スパゲティ カルボナーラ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
341	2022-03-22 20:24:17.573184+00	195	レンジ用スパゲティ ミートソース	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
342	2022-03-22 20:24:57.793304+00	196	レンジ用スパゲティ たらこと舞茸	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
343	2022-03-22 20:24:58.0674+00	196	レンジ用スパゲティ たらこと舞茸	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
344	2022-03-22 20:25:46.229124+00	197	レンジ用スパゲティ プレーン	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
345	2022-03-22 20:26:42.419774+00	198	N惣菜用 焼きスパゲティ ナポリタン《2.2mm》	2	[{"changed": {"fields": ["Handling time", "Handling temp", "Category", "Tag", "Industry", "Facility"]}}]	25	1
346	2022-03-22 20:27:34.717819+00	199	N惣菜用 焼きスパゲティ ナポリタン	2	[{"changed": {"fields": ["Handling time", "Handling temp", "Category", "Tag", "Industry", "Facility"]}}]	25	1
347	2022-03-22 20:28:21.018795+00	200	N付け合せ用 ナポリタン	2	[{"changed": {"fields": ["Handling time", "Handling temp", "Category", "Tag", "Industry", "Facility"]}}]	25	1
348	2022-03-22 20:29:13.044451+00	201	N付け合せ用 塩バター	2	[{"changed": {"fields": ["Handling time", "Handling temp", "Category", "Tag", "Industry", "Facility"]}}]	25	1
349	2022-03-22 20:30:06.165021+00	202	ナポリタン	2	[{"changed": {"fields": ["Description", "Category", "Tag", "Industry", "Facility"]}}]	25	1
350	2022-03-22 20:30:56.103051+00	203	和風きのこ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
351	2022-03-22 20:31:40.390702+00	204	たらこ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
352	2022-03-22 20:32:24.99726+00	205	ペペロンチーニ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
353	2022-03-22 20:33:18.807019+00	206	マ・マーTHE PRO Smile Meal やさしい味わい ナポリタン	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
354	2022-03-22 20:34:13.92778+00	207	マ・マーTHE PRO Smile Meal やさしい味わい 和風パスタ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
355	2022-03-22 20:35:16.493896+00	208	テイクアウト用生パスタスパゲティ	2	[{"changed": {"fields": ["Description", "Category", "Tag", "Industry", "Facility"]}}]	25	1
356	2022-03-22 20:36:09.238538+00	209	ボロネーゼ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
357	2022-03-22 20:36:57.495749+00	210	完熟トマトのソース	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
358	2022-03-22 20:37:49.375164+00	211	ミートソース	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
359	2022-03-22 20:38:34.809846+00	212	ミートソース	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
360	2022-03-22 20:39:29.710695+00	213	サルサポモドーロ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
361	2022-03-22 20:39:30.159399+00	213	サルサポモドーロ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
362	2022-03-22 20:40:24.551264+00	214	N HQポモドーロソース（1kg）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
363	2022-03-22 20:41:17.945449+00	215	HQクリームソース（1kg）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
364	2022-03-22 20:42:05.897898+00	216	ボロネーゼ	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
365	2022-03-22 20:42:52.681694+00	217	ナポリタンソース	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
366	2022-03-22 20:43:31.509505+00	218	完熟トマトソース	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
367	2022-03-22 20:44:14.566457+00	219	ポルチーニクリームソース	2	[{"changed": {"fields": ["Packing", "Category", "Tag", "Industry", "Facility"]}}]	25	1
368	2022-03-22 20:44:14.887348+00	219	ポルチーニクリームソース	2	[{"changed": {"fields": ["Packing", "Category", "Tag", "Industry", "Facility"]}}]	25	1
369	2022-03-22 20:44:55.521839+00	220	なめらかカルボナーラソース　（1kg）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
370	2022-03-22 20:45:41.371693+00	221	なめらかカルボナーラソース（個食用）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
371	2022-03-22 20:46:26.132576+00	222	たらこソース　（チューブ入・パスタ用）	2	[{"changed": {"fields": ["Category", "Tag", "Industry"]}}]	25	1
372	2022-03-22 20:46:26.584091+00	222	たらこソース　（チューブ入・パスタ用）	2	[{"changed": {"fields": ["Category", "Tag", "Industry"]}}]	25	1
373	2022-03-22 20:47:15.713264+00	223	明太子ソース　（チューブ入・パスタ用）	2	[{"changed": {"fields": ["Category", "Tag", "Industry"]}}]	25	1
374	2022-03-22 20:49:46.141597+00	224	No.1 Lasagna（ラザーニャ）	2	[{"changed": {"fields": ["Handling time", "Category", "Tag", "Industry", "Facility"]}}]	25	1
375	2022-03-22 20:50:48.010928+00	225	No.7 Linguine（リングイーネ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
376	2022-03-22 20:51:41.294462+00	226	No.7 Linguine（リングイーネ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
377	2022-03-22 20:53:01.45583+00	227	No.8 Linguine piccole（リングイーネ ピッコレ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
378	2022-03-22 20:53:51.762617+00	228	No.9 Capellini（カッペリーニ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
379	2022-03-22 20:54:39.276649+00	229	No.10 Fedelini（フェデリーニ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
380	2022-03-22 20:55:33.985166+00	230	No.10 Fedelini（フェデリーニ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
381	2022-03-22 20:56:21.390939+00	231	No.10 Fedelini（フェデリーニ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
382	2022-03-22 20:57:17.996847+00	232	No.11 Spaghettini（スパゲッティーニ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
383	2022-03-22 20:58:39.760035+00	233	No.11 Spaghettini（スパゲッティーニ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
384	2022-03-22 20:59:32.400263+00	234	No.11 Spaghettini（スパゲッティーニ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
385	2022-03-22 21:00:21.523731+00	235	No.12 Spaghetti（スパゲッティ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
386	2022-03-22 21:01:14.817896+00	236	No.12 Spaghetti（スパゲッティ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
387	2022-03-22 21:02:09.181842+00	237	No.13 Maccheroni alla Chitarra（マッケローニ・アッラ・キタッラ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
388	2022-03-22 21:02:50.043486+00	238	No.14 Bucatini Piccoli（ブカティーニ・ピッコリ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
389	2022-03-22 21:03:40.197904+00	239	No.170 Vermicelli（ヴェルミチェッリ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
390	2022-03-22 21:04:32.380098+00	240	No.25 Mille righe（ミッレ リーゲ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
391	2022-03-22 21:05:17.37331+00	241	No.34 Fusilli（フスィリ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
392	2022-03-22 21:05:53.599994+00	242	No.41 Penne Rigate（ペンネ リガーテ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
393	2022-03-22 21:06:33.109731+00	243	No.50 Conchiglie Rigate（コンキリエ リガーテ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
394	2022-03-22 21:07:20.156841+00	244	No.88 Casareccia（カサレッチャ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
395	2022-03-22 21:07:58.471223+00	245	No.91 Orecchiette（オレキエッテ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
396	2022-03-22 21:08:34.428748+00	246	No.93 Farfalle（ファルファーレ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
397	2022-03-22 21:09:20.332357+00	247	No.118 Zita Tagliata（ジータ・タリアータ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
398	2022-03-22 21:09:20.85844+00	247	No.118 Zita Tagliata（ジータ・タリアータ）	2	[]	25	1
399	2022-03-22 21:10:00.695181+00	248	No.125 Paccheri（パッケリ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
400	2022-03-22 21:10:55.45921+00	249	No.303 Fettuccine（フェットゥチーネ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
401	2022-03-22 21:11:38.972046+00	250	No.310 Fettuccine con spinaci（フェットゥチーネ コン スピナーチ）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
402	2022-03-22 21:12:23.618178+00	251	No.11 Spaghettini Organic（スパゲッティーニ オーガニック）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
403	2022-03-22 21:13:10.572795+00	252	No.12 Spaghetti Organic（スパゲッティ オーガニック）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
404	2022-03-22 21:14:01.990823+00	253	No.34 Fusilli Organic（フスィリ オーガニック）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
405	2022-03-22 21:14:39.766589+00	254	No.41 Penne Rigate Organic（ペンネ リガーテ オーガニック）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
406	2022-03-22 21:14:40.204632+00	254	No.41 Penne Rigate Organic（ペンネ リガーテ オーガニック）	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
407	2022-03-22 21:15:24.88111+00	255	冷凍パスタ No.11 Spaghettini（スパゲッティーニ）	2	[{"changed": {"fields": ["Handling time", "Handling temp", "Category", "Tag", "Industry", "Facility"]}}]	25	1
408	2022-03-22 21:17:40.50732+00	256	ラウンドアップパスタスチーマー PSW-777	2	[{"changed": {"fields": ["Industry"]}}]	25	1
409	2022-03-22 21:17:50.527826+00	257	ラウンドアップパスタスチーマー      軟水器	2	[{"changed": {"fields": ["Industry"]}}]	25	1
410	2022-03-22 21:19:51.742699+00	74	天ぷら粉　味わい衣	2	[{"changed": {"fields": ["Shipping date"]}}]	25	1
411	2022-03-22 21:20:16.904719+00	75	天ぷら粉　パックに入れてもかるサク衣	2	[{"changed": {"fields": ["Shipping date"]}}]	25	1
412	2022-03-22 21:21:00.488421+00	87	薄衣サクサクから揚げ粉	2	[{"changed": {"fields": ["Shipping date"]}}]	25	1
413	2022-03-22 21:21:22.833294+00	88	ゴツゴツから揚げ粉	2	[{"changed": {"fields": ["Shipping date"]}}]	25	1
414	2022-03-22 21:21:52.581944+00	89	タレかけカリサクから揚げ粉	2	[{"changed": {"fields": ["Shipping date"]}}]	25	1
415	2022-03-22 21:22:17.612596+00	90	ザクザクから揚げ粉	2	[{"changed": {"fields": ["Shipping date"]}}]	25	1
416	2022-03-22 21:22:57.737596+00	147	マ・マーTHE　PRO早ゆでスパゲティ1.6mm	2	[{"changed": {"fields": ["Shipping date"]}}]	25	1
417	2022-03-22 21:23:45.174383+00	184	マ・マー THE PRO IQF（バラ凍結）MINI フィジリ	2	[{"changed": {"fields": ["Shipping date"]}}]	25	1
418	2022-03-22 21:24:11.461345+00	185	マ・マー THE PRO IQF（バラ凍結）MINI ストレートマカロニ	2	[{"changed": {"fields": ["Shipping date"]}}]	25	1
419	2022-03-22 21:24:43.293995+00	186	マ・マー THE PRO IQF（バラ凍結）MINI シェル	2	[{"changed": {"fields": ["Shipping date"]}}]	25	1
420	2022-03-22 21:25:15.450229+00	205	ペペロンチーニ	2	[{"changed": {"fields": ["Shipping date"]}}]	25	1
421	2022-03-22 21:25:37.873552+00	206	マ・マーTHE PRO Smile Meal やさしい味わい ナポリタン	2	[{"changed": {"fields": ["Shipping date"]}}]	25	1
422	2022-03-22 21:26:05.814071+00	207	マ・マーTHE PRO Smile Meal やさしい味わい 和風パスタ	2	[{"changed": {"fields": ["Shipping date"]}}]	25	1
423	2022-03-22 21:29:58.0414+00	3	バッター・打ち粉	2	[{"changed": {"fields": ["Slug"]}}]	24	1
424	2022-03-22 21:30:20.560286+00	5	洋風メニュー	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
425	2022-03-22 21:30:39.736909+00	5	洋風メニュー	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
426	2022-03-22 21:30:55.274186+00	6	ロングパスタ	2	[{"changed": {"fields": ["Slug"]}}]	24	1
427	2022-03-22 21:31:14.281252+00	7	ショートパスタ	2	[{"changed": {"fields": ["Slug"]}}]	24	1
428	2022-03-22 21:31:39.866862+00	8	調理済みパスタ	2	[{"changed": {"fields": ["Slug"]}}]	24	1
429	2022-03-22 21:31:55.835276+00	9	パスタソース	2	[{"changed": {"fields": ["Slug"]}}]	24	1
430	2022-03-22 21:32:50.359955+00	256	ラウンドアップパスタスチーマー PSW-777	2	[{"changed": {"fields": ["Category"]}}]	25	1
431	2022-03-22 21:33:02.261334+00	257	ラウンドアップパスタスチーマー      軟水器	2	[{"changed": {"fields": ["Category"]}}]	25	1
432	2022-03-22 21:36:43.044121+00	5	常温	2	[{"changed": {"fields": ["Slug"]}}]	28	1
433	2022-03-22 21:37:06.22664+00	10	かるサクシリーズ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
434	2022-03-22 21:37:18.456492+00	11	揚げ上手シリーズ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
435	2022-03-22 21:37:33.073638+00	12	調理行程削減	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
436	2022-03-22 21:38:00.457409+00	2	おいしさ長持ち	2	[{"changed": {"fields": ["Slug"]}}]	28	1
437	2022-03-22 21:38:08.847076+00	3	大容量	2	[{"changed": {"fields": ["Slug"]}}]	28	1
438	2022-03-22 21:38:39.938543+00	13	水溶き	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
439	2022-03-22 21:38:52.627228+00	14	漬け込みまぶしタイプ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
440	2022-03-22 21:39:18.632204+00	15	水溶きまぶし	2	[{"changed": {"fields": ["Slug"]}}]	24	1
441	2022-03-22 21:39:26.649983+00	14	漬け込みまぶしタイプ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
442	2022-03-22 21:39:36.883452+00	16	まぶしタイプ	2	[]	24	1
443	2022-03-22 21:39:47.412629+00	17	味つき	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
444	2022-03-22 21:39:57.341261+00	18	味なし	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
445	2022-03-22 21:40:20.593266+00	19	打ち粉	2	[]	24	1
446	2022-03-22 21:40:29.769909+00	20	バッター	2	[]	24	1
447	2022-03-22 21:40:38.556983+00	21	畜肉用	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
448	2022-03-22 21:40:51.679906+00	22	魚介用	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
449	2022-03-22 21:41:14.102988+00	24	お好み焼	2	[]	24	1
450	2022-03-22 21:41:36.032623+00	25	鯛焼き	2	[]	24	1
451	2022-03-22 21:41:46.297809+00	26	大判焼き	2	[]	24	1
452	2022-03-22 21:41:56.537531+00	27	冷麺	2	[]	24	1
453	2022-03-22 21:42:13.561009+00	28	パンケーキ	2	[]	24	1
454	2022-03-22 21:42:32.221811+00	30	ホットケーキ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
455	2022-03-22 21:42:47.535808+00	31	蒸しパン	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
456	2022-03-22 21:43:03.569359+00	34	チュロス	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
457	2022-03-22 21:43:16.803904+00	35	ホワイトソース	2	[{"changed": {"fields": ["Slug"]}}]	24	1
458	2022-03-22 21:43:32.290741+00	50	ワンディッシュ	2	[]	24	1
459	2022-03-22 21:43:44.667519+00	51	付け合わせ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
460	2022-03-22 21:44:04.442139+00	44	ストレートマカロニ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
461	2022-03-22 21:44:17.238455+00	45	フィジリ	2	[]	24	1
462	2022-03-22 21:45:28.761181+00	48	その他	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
463	2022-03-22 21:46:19.959352+00	36	～1.5㎜	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
464	2022-03-22 21:46:40.919777+00	37	1.6～1.7㎜	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
465	2022-03-22 21:47:10.631734+00	38	1.8㎜～	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
466	2022-03-22 21:47:22.582247+00	36	～1.5㎜	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
467	2022-03-22 21:47:31.668436+00	37	1.6～1.7㎜	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09"]}}]	24	1
468	2022-03-22 21:47:54.735813+00	40	乾麺	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
469	2022-03-22 21:48:35.239957+00	41	生麺	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
470	2022-03-22 21:48:49.163858+00	42	ゆで時間短縮	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
664	2022-03-23 08:52:00.00625+00	7	ショートパスタ	2	[{"changed": {"fields": ["Hero"]}}]	24	1
471	2022-03-22 21:49:01.256903+00	43	ディチェコ	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
472	2022-03-22 21:51:58.393835+00	4	和風メニュー	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
473	2022-03-23 03:06:57.019044+00	257	ラウンドアップパスタスチーマー      軟水器	2	[{"changed": {"fields": ["Hero"]}}]	25	1
474	2022-03-23 05:11:28.604606+00	257	ラウンドアップパスタスチーマー      軟水器	2	[{"added": {"name": "photo", "object": "Photo object (5)"}}]	25	1
475	2022-03-23 05:11:40.545364+00	256	ラウンドアップパスタスチーマー PSW-777	2	[{"added": {"name": "photo", "object": "Photo object (6)"}}]	25	1
476	2022-03-23 05:12:35.403883+00	255	冷凍パスタ No.11 Spaghettini（スパゲッティーニ）	2	[{"added": {"name": "photo", "object": "Photo object (7)"}}]	25	1
477	2022-03-23 05:14:05.939258+00	254	No.41 Penne Rigate Organic（ペンネ リガーテ オーガニック）	2	[{"added": {"name": "photo", "object": "Photo object (8)"}}]	25	1
478	2022-03-23 05:14:24.885994+00	253	No.34 Fusilli Organic（フスィリ オーガニック）	2	[{"added": {"name": "photo", "object": "Photo object (9)"}}]	25	1
479	2022-03-23 05:14:42.050297+00	252	No.12 Spaghetti Organic（スパゲッティ オーガニック）	2	[{"added": {"name": "photo", "object": "Photo object (10)"}}]	25	1
480	2022-03-23 05:15:01.339857+00	251	No.11 Spaghettini Organic（スパゲッティーニ オーガニック）	2	[{"added": {"name": "photo", "object": "Photo object (11)"}}]	25	1
481	2022-03-23 05:15:29.947711+00	250	No.310 Fettuccine con spinaci（フェットゥチーネ コン スピナーチ）	2	[{"added": {"name": "photo", "object": "Photo object (12)"}}]	25	1
482	2022-03-23 05:15:59.396452+00	249	No.303 Fettuccine（フェットゥチーネ）	2	[{"added": {"name": "photo", "object": "Photo object (13)"}}]	25	1
483	2022-03-23 05:16:18.814131+00	248	No.125 Paccheri（パッケリ）	2	[{"added": {"name": "photo", "object": "Photo object (14)"}}]	25	1
484	2022-03-23 05:16:39.727508+00	247	No.118 Zita Tagliata（ジータ・タリアータ）	2	[{"added": {"name": "photo", "object": "Photo object (15)"}}]	25	1
485	2022-03-23 05:17:08.675253+00	246	No.93 Farfalle（ファルファーレ）	2	[{"added": {"name": "photo", "object": "Photo object (16)"}}]	25	1
486	2022-03-23 05:17:23.011819+00	245	No.91 Orecchiette（オレキエッテ）	2	[{"added": {"name": "photo", "object": "Photo object (17)"}}]	25	1
487	2022-03-23 05:17:40.090004+00	244	No.88 Casareccia（カサレッチャ）	2	[{"added": {"name": "photo", "object": "Photo object (18)"}}]	25	1
488	2022-03-23 05:18:00.68802+00	243	No.50 Conchiglie Rigate（コンキリエ リガーテ）	2	[{"added": {"name": "photo", "object": "Photo object (19)"}}]	25	1
489	2022-03-23 05:18:20.470075+00	242	No.41 Penne Rigate（ペンネ リガーテ）	2	[{"added": {"name": "photo", "object": "Photo object (20)"}}]	25	1
490	2022-03-23 05:18:37.203013+00	241	No.34 Fusilli（フスィリ）	2	[{"added": {"name": "photo", "object": "Photo object (21)"}}]	25	1
491	2022-03-23 05:19:01.077204+00	240	No.25 Mille righe（ミッレ リーゲ）	2	[{"added": {"name": "photo", "object": "Photo object (22)"}}]	25	1
492	2022-03-23 05:19:16.92747+00	239	No.170 Vermicelli（ヴェルミチェッリ）	2	[{"added": {"name": "photo", "object": "Photo object (23)"}}]	25	1
493	2022-03-23 05:19:38.432173+00	238	No.14 Bucatini Piccoli（ブカティーニ・ピッコリ）	2	[{"added": {"name": "photo", "object": "Photo object (24)"}}]	25	1
494	2022-03-23 05:19:51.423746+00	237	No.13 Maccheroni alla Chitarra（マッケローニ・アッラ・キタッラ）	2	[{"added": {"name": "photo", "object": "Photo object (25)"}}]	25	1
495	2022-03-23 05:20:04.458241+00	236	No.12 Spaghetti（スパゲッティ）	2	[{"added": {"name": "photo", "object": "Photo object (26)"}}]	25	1
496	2022-03-23 05:20:18.205379+00	234	No.11 Spaghettini（スパゲッティーニ）	2	[{"added": {"name": "photo", "object": "Photo object (27)"}}]	25	1
497	2022-03-23 05:20:33.137955+00	231	No.10 Fedelini（フェデリーニ）	2	[{"added": {"name": "photo", "object": "Photo object (28)"}}]	25	1
498	2022-03-23 05:20:48.512256+00	230	No.10 Fedelini（フェデリーニ）	2	[{"added": {"name": "photo", "object": "Photo object (29)"}}]	25	1
499	2022-03-23 05:21:04.752393+00	229	No.10 Fedelini（フェデリーニ）	2	[{"added": {"name": "photo", "object": "Photo object (30)"}}]	25	1
500	2022-03-23 05:21:19.030051+00	228	No.9 Capellini（カッペリーニ）	2	[{"added": {"name": "photo", "object": "Photo object (31)"}}]	25	1
501	2022-03-23 05:21:34.561494+00	227	No.8 Linguine piccole（リングイーネ ピッコレ）	2	[{"added": {"name": "photo", "object": "Photo object (32)"}}]	25	1
502	2022-03-23 05:21:55.926892+00	226	No.7 Linguine（リングイーネ）	2	[{"added": {"name": "photo", "object": "Photo object (33)"}}]	25	1
503	2022-03-23 05:22:10.479282+00	225	No.7 Linguine（リングイーネ）	2	[{"added": {"name": "photo", "object": "Photo object (34)"}}]	25	1
504	2022-03-23 05:22:26.993364+00	224	No.1 Lasagna（ラザーニャ）	2	[{"added": {"name": "photo", "object": "Photo object (35)"}}]	25	1
505	2022-03-23 05:22:46.663009+00	223	明太子ソース　（チューブ入・パスタ用）	2	[{"added": {"name": "photo", "object": "Photo object (36)"}}]	25	1
506	2022-03-23 05:23:00.794792+00	222	たらこソース　（チューブ入・パスタ用）	2	[{"added": {"name": "photo", "object": "Photo object (37)"}}]	25	1
507	2022-03-23 05:23:15.328237+00	221	なめらかカルボナーラソース（個食用）	2	[{"added": {"name": "photo", "object": "Photo object (38)"}}]	25	1
508	2022-03-23 05:23:30.339336+00	220	なめらかカルボナーラソース　（1kg）	2	[{"added": {"name": "photo", "object": "Photo object (39)"}}]	25	1
509	2022-03-23 05:23:47.34347+00	219	ポルチーニクリームソース	2	[{"added": {"name": "photo", "object": "Photo object (40)"}}]	25	1
510	2022-03-23 05:24:01.590321+00	218	完熟トマトソース	2	[{"added": {"name": "photo", "object": "Photo object (41)"}}]	25	1
511	2022-03-23 05:24:17.443623+00	217	ナポリタンソース	2	[{"added": {"name": "photo", "object": "Photo object (42)"}}]	25	1
512	2022-03-23 05:24:34.95544+00	216	ボロネーゼ	2	[{"added": {"name": "photo", "object": "Photo object (43)"}}]	25	1
513	2022-03-23 05:24:51.020345+00	215	HQクリームソース（1kg）	2	[{"added": {"name": "photo", "object": "Photo object (44)"}}]	25	1
514	2022-03-23 05:25:06.356659+00	214	N HQポモドーロソース（1kg）	2	[{"added": {"name": "photo", "object": "Photo object (45)"}}]	25	1
515	2022-03-23 05:25:24.015225+00	213	サルサポモドーロ	2	[{"added": {"name": "photo", "object": "Photo object (46)"}}]	25	1
516	2022-03-23 05:25:37.683153+00	212	ミートソース	2	[{"added": {"name": "photo", "object": "Photo object (47)"}}]	25	1
665	2022-03-23 08:52:24.428222+00	8	調理済みパスタ	2	[{"changed": {"fields": ["Hero"]}}]	24	1
517	2022-03-23 05:25:51.577727+00	211	ミートソース	2	[{"added": {"name": "photo", "object": "Photo object (48)"}}]	25	1
518	2022-03-23 05:26:04.59277+00	210	完熟トマトのソース	2	[{"added": {"name": "photo", "object": "Photo object (49)"}}]	25	1
519	2022-03-23 05:26:51.211797+00	209	ボロネーゼ	2	[{"added": {"name": "photo", "object": "Photo object (50)"}}]	25	1
520	2022-03-23 05:27:09.288882+00	208	テイクアウト用生パスタスパゲティ	2	[{"added": {"name": "photo", "object": "Photo object (51)"}}]	25	1
521	2022-03-23 05:27:51.237472+00	207	マ・マーTHE PRO Smile Meal やさしい味わい 和風パスタ	2	[{"added": {"name": "photo", "object": "Photo object (52)"}}]	25	1
522	2022-03-23 05:28:12.951483+00	206	マ・マーTHE PRO Smile Meal やさしい味わい ナポリタン	2	[{"added": {"name": "photo", "object": "Photo object (53)"}}]	25	1
523	2022-03-23 05:28:46.095726+00	205	ペペロンチーニ	2	[{"added": {"name": "photo", "object": "Photo object (54)"}}]	25	1
524	2022-03-23 05:29:24.8557+00	204	たらこ	2	[{"added": {"name": "photo", "object": "Photo object (55)"}}]	25	1
525	2022-03-23 05:29:51.385733+00	203	和風きのこ	2	[{"added": {"name": "photo", "object": "Photo object (56)"}}]	25	1
526	2022-03-23 05:30:18.303232+00	202	ナポリタン	2	[{"added": {"name": "photo", "object": "Photo object (57)"}}]	25	1
527	2022-03-23 05:30:35.04432+00	201	N付け合せ用 塩バター	2	[{"added": {"name": "photo", "object": "Photo object (58)"}}]	25	1
528	2022-03-23 05:30:49.119705+00	200	N付け合せ用 ナポリタン	2	[{"added": {"name": "photo", "object": "Photo object (59)"}}]	25	1
529	2022-03-23 05:31:02.185551+00	199	N惣菜用 焼きスパゲティ ナポリタン	2	[{"added": {"name": "photo", "object": "Photo object (60)"}}]	25	1
530	2022-03-23 05:31:18.41725+00	198	N惣菜用 焼きスパゲティ ナポリタン《2.2mm》	2	[{"added": {"name": "photo", "object": "Photo object (61)"}}]	25	1
531	2022-03-23 05:31:33.768938+00	197	レンジ用スパゲティ プレーン	2	[{"added": {"name": "photo", "object": "Photo object (62)"}}]	25	1
532	2022-03-23 05:31:59.15914+00	196	レンジ用スパゲティ たらこと舞茸	2	[{"added": {"name": "photo", "object": "Photo object (63)"}}]	25	1
533	2022-03-23 05:32:23.199433+00	195	レンジ用スパゲティ ミートソース	2	[{"added": {"name": "photo", "object": "Photo object (64)"}}]	25	1
534	2022-03-23 05:32:50.806849+00	194	レンジ用スパゲティ カルボナーラ	2	[{"added": {"name": "photo", "object": "Photo object (65)"}}]	25	1
535	2022-03-23 05:33:07.55874+00	193	レンジ用ソテースパゲティ ナポリタン	2	[{"added": {"name": "photo", "object": "Photo object (66)"}}]	25	1
536	2022-03-23 05:35:44.415114+00	186	マ・マー THE PRO IQF（バラ凍結）MINI シェル	2	[{"added": {"name": "photo", "object": "Photo object (67)"}}]	25	1
537	2022-03-23 05:36:14.654902+00	185	マ・マー THE PRO IQF（バラ凍結）MINI ストレートマカロニ	2	[{"added": {"name": "photo", "object": "Photo object (68)"}}]	25	1
538	2022-03-23 05:36:32.594055+00	184	マ・マー THE PRO IQF（バラ凍結）MINI フィジリ	2	[{"added": {"name": "photo", "object": "Photo object (69)"}}]	25	1
539	2022-03-23 05:36:48.723313+00	183	IQF（バラ凍結）パッケリ	2	[{"added": {"name": "photo", "object": "Photo object (70)"}}]	25	1
540	2022-03-23 05:37:07.991106+00	182	IQF（バラ凍結）カサレッチャ	2	[{"added": {"name": "photo", "object": "Photo object (71)"}}]	25	1
541	2022-03-23 05:37:23.988034+00	181	IQF（バラ凍結）リガトーニ	2	[{"added": {"name": "photo", "object": "Photo object (72)"}}]	25	1
542	2022-03-23 05:37:42.710434+00	180	IQF（バラ凍結）フィジリ	2	[{"added": {"name": "photo", "object": "Photo object (73)"}}]	25	1
543	2022-03-23 05:37:57.732771+00	179	IQF（バラ凍結）ペンネリガーテ	2	[{"added": {"name": "photo", "object": "Photo object (74)"}}]	25	1
544	2022-03-23 05:38:34.715087+00	178	MACARONI ツイスト	2	[{"added": {"name": "photo", "object": "Photo object (75)"}}]	25	1
545	2022-03-23 05:39:16.478139+00	177	MACARONI シェルスモール	2	[{"added": {"name": "photo", "object": "Photo object (76)"}}]	25	1
546	2022-03-23 05:39:37.328861+00	176	MACARONI シェル	2	[]	25	1
547	2022-03-23 05:39:55.624451+00	176	MACARONI シェル	2	[{"added": {"name": "photo", "object": "Photo object (77)"}}]	25	1
548	2022-03-23 05:40:28.838938+00	175	MACARONI 野菜入りクルル	2	[{"added": {"name": "photo", "object": "Photo object (78)"}}]	25	1
549	2022-03-23 05:40:48.893286+00	174	MACARONI デリカ201 クルル 9-15	2	[{"added": {"name": "photo", "object": "Photo object (79)"}}]	25	1
550	2022-03-23 05:41:17.241602+00	173	MACARONI クルル	2	[{"added": {"name": "photo", "object": "Photo object (80)"}}]	25	1
551	2022-03-23 05:41:29.680891+00	172	MACARONI サラダマカロニ	2	[{"added": {"name": "photo", "object": "Photo object (81)"}}]	25	1
552	2022-03-23 05:41:41.489121+00	169	MACARONI ブラウン 4-40	2	[{"added": {"name": "photo", "object": "Photo object (82)"}}]	25	1
553	2022-03-23 05:41:56.770052+00	168	Cool’s 冷製スパゲティR 1.4mm《塩ゆで》	2	[{"added": {"name": "photo", "object": "Photo object (83)"}}]	25	1
554	2022-03-23 05:42:12.924867+00	167	Rスパゲティ 1.7mm【湯せんタイプ】	2	[{"added": {"name": "photo", "object": "Photo object (84)"}}]	25	1
555	2022-03-23 05:42:31.167621+00	166	Rスパゲティ 1.7mm【湯せんタイプ】	2	[{"added": {"name": "photo", "object": "Photo object (85)"}}]	25	1
556	2022-03-23 05:42:50.006609+00	165	マッシモプレミオ 冷凍スパゲティ《塩ゆで》	2	[{"added": {"name": "photo", "object": "Photo object (86)"}}]	25	1
557	2022-03-23 05:43:05.677285+00	164	ラウンドアップスパゲティ 1.7mm PREMIUM《塩ゆで》	2	[{"added": {"name": "photo", "object": "Photo object (87)"}}]	25	1
558	2022-03-23 05:43:17.04062+00	163	ラウンドアップスパゲティ 太麺タイプ 2.2mm《塩ゆで》	2	[{"added": {"name": "photo", "object": "Photo object (88)"}}]	25	1
559	2022-03-23 05:43:28.277376+00	162	ラウンドアップスパゲティ 1.4mm《塩ゆで》	2	[{"added": {"name": "photo", "object": "Photo object (89)"}}]	25	1
560	2022-03-23 05:43:43.178319+00	161	ラウンドアップスパゲティ Super Hardタイプ 1.6mm《塩ゆで》　250g	2	[{"added": {"name": "photo", "object": "Photo object (90)"}}]	25	1
561	2022-03-23 05:43:57.929356+00	160	ラウンドアップスパゲティ Super Hardタイプ 1.6mm《塩ゆで》　220g	2	[{"added": {"name": "photo", "object": "Photo object (91)"}}]	25	1
562	2022-03-23 05:44:07.802901+00	159	ラウンドアップスパゲティ Super Hardタイプ 1.6mm《塩ゆで》　180g	2	[{"added": {"name": "photo", "object": "Photo object (92)"}}]	25	1
563	2022-03-23 05:44:22.240983+00	158	タリオリーニ（卵入り）	2	[{"added": {"name": "photo", "object": "Photo object (93)"}}]	25	1
564	2022-03-23 05:44:35.957003+00	157	フェットチーネ（ほうれん草入り）	2	[{"added": {"name": "photo", "object": "Photo object (94)"}}]	25	1
565	2022-03-23 05:44:49.555177+00	156	フェットチーネ（卵入り）	2	[{"added": {"name": "photo", "object": "Photo object (95)"}}]	25	1
566	2022-03-23 05:45:02.836952+00	155	リングイネ	2	[{"added": {"name": "photo", "object": "Photo object (96)"}}]	25	1
567	2022-03-23 05:45:17.928991+00	154	スパゲッティーニ	2	[{"added": {"name": "photo", "object": "Photo object (97)"}}]	25	1
568	2022-03-23 05:45:30.67765+00	153	マッシモ プレミオ #201　1.7	2	[{"added": {"name": "photo", "object": "Photo object (98)"}}]	25	1
569	2022-03-23 05:45:46.624324+00	152	マッシモ プレミオ #201　1.7	2	[{"added": {"name": "photo", "object": "Photo object (99)"}}]	25	1
570	2022-03-23 05:46:00.525585+00	151	マッシモ プレミオ #201　1.5	2	[{"added": {"name": "photo", "object": "Photo object (100)"}}]	25	1
571	2022-03-23 05:46:10.661547+00	150	マッシモ プレミオ #201　1.5	2	[{"added": {"name": "photo", "object": "Photo object (101)"}}]	25	1
572	2022-03-23 05:46:27.290538+00	149	マ・マー ミニスパゲティ　ミニ1.7	2	[{"added": {"name": "photo", "object": "Photo object (102)"}}]	25	1
573	2022-03-23 05:46:47.597777+00	148	マ・マー ミニスパゲティ　ミニ1.6	2	[{"added": {"name": "photo", "object": "Photo object (103)"}}]	25	1
574	2022-03-23 05:47:06.646608+00	147	マ・マーTHE　PRO早ゆでスパゲティ1.6mm	2	[{"added": {"name": "photo", "object": "Photo object (104)"}}]	25	1
575	2022-03-23 05:47:28.649018+00	146	マ・マー 早ゆでスパゲティ プロント 2.2mm	2	[{"added": {"name": "photo", "object": "Photo object (105)"}}]	25	1
576	2022-03-23 05:47:43.048936+00	145	早ゆでスパゲティプロント 1.6mm	2	[{"added": {"name": "photo", "object": "Photo object (106)"}}]	25	1
577	2022-03-23 05:48:00.069977+00	144	早ゆでスパゲティプロント 1.6mm	2	[{"added": {"name": "photo", "object": "Photo object (107)"}}]	25	1
578	2022-03-23 05:48:18.706182+00	143	マ・マー スパゲティ　2.2	2	[{"added": {"name": "photo", "object": "Photo object (108)"}}]	25	1
579	2022-03-23 05:48:29.337504+00	142	マ・マー スパゲティ　1.9	2	[{"added": {"name": "photo", "object": "Photo object (109)"}}]	25	1
580	2022-03-23 05:48:41.955287+00	141	マ・マー スパゲティ　1.7	2	[{"added": {"name": "photo", "object": "Photo object (110)"}}]	25	1
581	2022-03-23 05:48:57.378481+00	140	マ・マー スパゲティ　1.6	2	[{"added": {"name": "photo", "object": "Photo object (111)"}}]	25	1
582	2022-03-23 05:49:10.424628+00	139	マ・マー スパゲティ　1.4	2	[{"added": {"name": "photo", "object": "Photo object (112)"}}]	25	1
583	2022-03-23 05:49:22.93987+00	138	ミニチュロス(チョコ味)	2	[{"added": {"name": "photo", "object": "Photo object (113)"}}]	25	1
584	2022-03-23 05:49:41.460178+00	137	ミニチュロス	2	[{"added": {"name": "photo", "object": "Photo object (114)"}}]	25	1
585	2022-03-23 05:49:58.964487+00	136	チュロス®（チョコ味）	2	[{"added": {"name": "photo", "object": "Photo object (115)"}}]	25	1
586	2022-03-23 05:50:22.119091+00	135	チュロス®（ミルク味）	2	[{"added": {"name": "photo", "object": "Photo object (116)"}}]	25	1
587	2022-03-23 05:50:38.799786+00	134	チュロス®	2	[{"added": {"name": "photo", "object": "Photo object (117)"}}]	25	1
588	2022-03-23 05:50:56.969967+00	133	チュロス®（ハーフサイズ）フライ＆ベイク	2	[{"added": {"name": "photo", "object": "Photo object (118)"}}]	25	1
589	2022-03-23 05:51:13.438703+00	132	自然解凍ミニパンケーキ	2	[{"added": {"name": "photo", "object": "Photo object (119)"}}]	25	1
590	2022-03-23 05:51:30.394592+00	131	達人厨房 クリーミーホワイトソースMIX	2	[{"added": {"name": "photo", "object": "Photo object (120)"}}]	25	1
591	2022-03-23 05:51:53.145999+00	130	ナポリ風ピッツァミックス	2	[{"added": {"name": "photo", "object": "Photo object (121)"}}]	25	1
592	2022-03-23 05:52:10.633122+00	129	ミシェーラ ナポリ風ピッツァミックス	2	[{"added": {"name": "photo", "object": "Photo object (122)"}}]	25	1
593	2022-03-23 05:52:21.999947+00	128	イースト不要！ベルギーワッフルミックス	2	[{"added": {"name": "photo", "object": "Photo object (123)"}}]	25	1
594	2022-03-23 05:52:35.844814+00	127	ふわふわ食感！ソフトワッフルミックス	2	[{"added": {"name": "photo", "object": "Photo object (124)"}}]	25	1
595	2022-03-23 05:52:54.993206+00	126	サクサク食感！クリスピーワッフルミックス	2	[{"added": {"name": "photo", "object": "Photo object (125)"}}]	25	1
596	2022-03-23 05:53:07.850668+00	125	水1リットルでできる蒸しパンミックス（黒）黒糖風味	2	[{"added": {"name": "photo", "object": "Photo object (126)"}}]	25	1
597	2022-03-23 05:53:21.934651+00	124	水1リットルでできる蒸しパンミックス（白）	2	[{"added": {"name": "photo", "object": "Photo object (127)"}}]	25	1
598	2022-03-23 05:53:32.779692+00	123	クレープミックス #707	2	[{"added": {"name": "photo", "object": "Photo object (128)"}}]	25	1
599	2022-03-23 05:54:35.72142+00	123	クレープミックス #707	2	[{"deleted": {"name": "photo", "object": "Photo object (None)"}}]	25	1
600	2022-03-23 05:55:09.503971+00	120	達人厨房 クレープMIX	2	[{"added": {"name": "photo", "object": "Photo object (129)"}}]	25	1
601	2022-03-23 05:55:25.78666+00	119	達人厨房 しっとりパンケーキMIX	2	[{"added": {"name": "photo", "object": "Photo object (130)"}}]	25	1
602	2022-03-23 05:55:41.00526+00	118	型のいらないホットケーキミックス 厚焼き上手	2	[{"added": {"name": "photo", "object": "Photo object (131)"}}]	25	1
603	2022-03-23 06:06:44.771967+00	117	冷凍のどごし冷麺	2	[{"added": {"name": "photo", "object": "Photo object (132)"}}]	25	1
604	2022-03-23 06:07:05.806153+00	116	ふんわりお好み焼（豚天）	2	[{"added": {"name": "photo", "object": "Photo object (133)"}}]	25	1
605	2022-03-23 06:07:24.639302+00	115	Rお好み横丁 ふんわりお好み焼（豚玉）	2	[{"added": {"name": "photo", "object": "Photo object (134)"}}]	25	1
606	2022-03-23 06:08:03.936355+00	114	たこ焼横丁 大玉たこ焼	2	[{"added": {"name": "photo", "object": "Photo object (135)"}}]	25	1
607	2022-03-23 06:08:23.951471+00	113	たこ焼横丁 Nたこ焼	2	[{"added": {"name": "photo", "object": "Photo object (136)"}}]	25	1
608	2022-03-23 06:08:44.60576+00	112	たこ焼横丁 関西丸たこ焼	2	[{"added": {"name": "photo", "object": "Photo object (137)"}}]	25	1
609	2022-03-23 06:10:17.787625+00	107	しっとり食感！鯛焼きミックス	2	[{"added": {"name": "photo", "object": "Photo object (138)"}}]	25	1
610	2022-03-23 06:11:09.034623+00	106	達人厨房 ふんわりお好み焼粉	2	[{"added": {"name": "photo", "object": "Photo object (139)"}}]	25	1
611	2022-03-23 06:11:34.41101+00	105	お好み焼粉 山いも入り	2	[{"added": {"name": "photo", "object": "Photo object (140)"}}]	25	1
612	2022-03-23 06:12:16.591437+00	104	たこ焼粉	2	[{"added": {"name": "photo", "object": "Photo object (141)"}}]	25	1
613	2022-03-23 06:13:51.807+00	97	打ち粉ミックス これで結着！	2	[{"added": {"name": "photo", "object": "Photo object (142)"}}]	25	1
614	2022-03-23 06:14:08.84445+00	96	パン粉が良くつく粉	2	[{"added": {"name": "photo", "object": "Photo object (143)"}}]	25	1
615	2022-03-23 06:14:51.610123+00	93	バッターミックス サクミ長持ち上手！	2	[{"added": {"name": "photo", "object": "Photo object (144)"}}]	25	1
616	2022-03-23 06:15:07.456+00	92	バッターミックス　これで結着！	2	[{"added": {"name": "photo", "object": "Photo object (145)"}}]	25	1
617	2022-03-23 06:15:22.670475+00	91	THE TONKATSU	2	[{"added": {"name": "photo", "object": "Photo object (146)"}}]	25	1
618	2022-03-23 06:15:38.878777+00	90	ザクザクから揚げ粉	2	[{"added": {"name": "photo", "object": "Photo object (147)"}}]	25	1
619	2022-03-23 06:15:59.807031+00	89	タレかけカリサクから揚げ粉	2	[{"added": {"name": "photo", "object": "Photo object (148)"}}]	25	1
620	2022-03-23 06:16:23.739028+00	88	ゴツゴツから揚げ粉	2	[{"added": {"name": "photo", "object": "Photo object (149)"}}]	25	1
621	2022-03-23 06:16:51.810356+00	87	薄衣サクサクから揚げ粉	2	[{"added": {"name": "photo", "object": "Photo object (150)"}}]	25	1
622	2022-03-23 06:17:07.464733+00	86	から揚げ粉味付け自由な水溶きタイプ　中華街仕立て	2	[{"added": {"name": "photo", "object": "Photo object (151)"}}]	25	1
623	2022-03-23 06:17:21.74389+00	85	から揚げ粉 にんにく・しょうゆ風味	2	[{"added": {"name": "photo", "object": "Photo object (152)"}}]	25	1
624	2022-03-23 06:17:34.064196+00	84	から揚げミックス	2	[{"added": {"name": "photo", "object": "Photo object (153)"}}]	25	1
625	2022-03-23 06:17:50.71425+00	83	から揚げ粉	2	[{"added": {"name": "photo", "object": "Photo object (154)"}}]	25	1
626	2022-03-23 06:18:14.939536+00	82	から揚げ粉 唐揚王	2	[{"added": {"name": "photo", "object": "Photo object (155)"}}]	25	1
627	2022-03-23 06:19:11.109218+00	81	から揚げ粉 唐揚王	2	[{"added": {"name": "photo", "object": "Photo object (156)"}}]	25	1
628	2022-03-23 06:20:29.712036+00	78	聖地中津からあげセット 塩だれ	2	[{"added": {"name": "photo", "object": "Photo object (157)"}}]	25	1
629	2022-03-23 06:21:29.025093+00	77	聖地中津からあげセット しょうゆだれ	2	[{"added": {"name": "photo", "object": "Photo object (158)"}}]	25	1
630	2022-03-23 06:22:02.57785+00	74	天ぷら粉　味わい衣	2	[{"added": {"name": "photo", "object": "Photo object (159)"}}]	25	1
631	2022-03-23 06:22:45.442906+00	76	THE KARAAGE から揚げ粉	2	[{"added": {"name": "photo", "object": "Photo object (160)"}}]	25	1
632	2022-03-23 06:23:46.004699+00	73	天ぷら粉デラックス	2	[{"added": {"name": "photo", "object": "Photo object (161)"}}]	25	1
633	2022-03-23 06:23:57.872509+00	72	おそば屋さん・うどん屋さんの天ぷら粉 つゆ溶け衣	2	[{"added": {"name": "photo", "object": "Photo object (162)"}}]	25	1
634	2022-03-23 06:24:24.723277+00	71	おそば屋さん・うどん屋さんの天ぷら粉 つゆにのせてもしっかり衣	2	[{"added": {"name": "photo", "object": "Photo object (163)"}}]	25	1
635	2022-03-23 06:24:36.925529+00	70	天ぷら粉Bタイプ	2	[{"added": {"name": "photo", "object": "Photo object (164)"}}]	25	1
636	2022-03-23 06:24:53.573374+00	69	天ぷら粉A2タイプ	2	[{"added": {"name": "photo", "object": "Photo object (165)"}}]	25	1
637	2022-03-23 06:25:05.054025+00	68	天ぷら粉Aタイプ	2	[{"added": {"name": "photo", "object": "Photo object (166)"}}]	25	1
638	2022-03-23 06:26:06.617097+00	67	天ぷら粉Aタイプ	2	[{"added": {"name": "photo", "object": "Photo object (167)"}}]	25	1
639	2022-03-23 06:26:21.864112+00	66	国内麦小麦粉使用おいしい天ぷら粉	2	[{"added": {"name": "photo", "object": "Photo object (168)"}}]	25	1
640	2022-03-23 06:26:43.268662+00	65	おいしい天ぷら粉	2	[{"added": {"name": "photo", "object": "Photo object (169)"}}]	25	1
641	2022-03-23 06:27:06.481037+00	64	天ぷら粉軽やか衣	2	[{"added": {"name": "photo", "object": "Photo object (170)"}}]	25	1
642	2022-03-23 06:27:30.409502+00	63	天ぷら粉揚げ上手Cタイプ	2	[{"added": {"name": "photo", "object": "Photo object (171)"}}]	25	1
643	2022-03-23 06:27:46.037811+00	62	天ぷら粉揚げ上手Cタイプ	2	[{"added": {"name": "photo", "object": "Photo object (172)"}}]	25	1
644	2022-03-23 06:28:11.023164+00	61	天ぷら粉揚げ上手Jタイプ	2	[{"added": {"name": "photo", "object": "Photo object (173)"}}]	25	1
645	2022-03-23 06:28:26.064159+00	60	天ぷら粉揚げ上手Jタイプ	2	[{"added": {"name": "photo", "object": "Photo object (174)"}}]	25	1
646	2022-03-23 06:28:45.667607+00	59	天ぷら粉揚げ上手	2	[{"added": {"name": "photo", "object": "Photo object (175)"}}]	25	1
647	2022-03-23 06:28:57.526913+00	58	天ぷら粉揚げ上手	2	[{"added": {"name": "photo", "object": "Photo object (176)"}}]	25	1
648	2022-03-23 06:29:12.421254+00	57	天ぷら粉レンジでサクサク揚げ上手	2	[{"added": {"name": "photo", "object": "Photo object (177)"}}]	25	1
649	2022-03-23 06:29:25.406587+00	56	天ぷら粉 かる～い揚げ上手Bタイプ	2	[{"added": {"name": "photo", "object": "Photo object (178)"}}]	25	1
650	2022-03-23 06:29:37.886741+00	55	天ぷら粉かる～い揚げ上手	2	[{"added": {"name": "photo", "object": "Photo object (179)"}}]	25	1
651	2022-03-23 06:29:48.838485+00	54	天ぷら粉打ち粉いらずの揚げ上手	2	[{"added": {"name": "photo", "object": "Photo object (180)"}}]	25	1
652	2022-03-23 06:30:01.587227+00	53	天ぷら粉追い種いらずの揚げ上手	2	[{"added": {"name": "photo", "object": "Photo object (181)"}}]	25	1
653	2022-03-23 06:30:18.822698+00	52	天ぷら粉打ち粉いらずのかるサク衣	2	[{"added": {"name": "photo", "object": "Photo object (182)"}}]	25	1
654	2022-03-23 06:30:30.404383+00	51	天ぷら粉かるサク衣	2	[{"added": {"name": "photo", "object": "Photo object (183)"}}]	25	1
655	2022-03-23 06:30:47.714583+00	50	天ぷら粉かるサク衣	2	[{"added": {"name": "photo", "object": "Photo object (184)"}}]	25	1
656	2022-03-23 06:31:38.17548+00	75	天ぷら粉　パックに入れてもかるサク衣	2	[{"added": {"name": "photo", "object": "Photo object (185)"}}]	25	1
657	2022-03-23 07:20:33.610175+00	1	天ぷら粉	2	[{"changed": {"fields": ["\\u30ab\\u30c6\\u30b4\\u30ea\\u30fc\\uff08\\u82f1\\u8a9e\\uff09", "Slug"]}}]	24	1
658	2022-03-23 08:50:08.493837+00	1	天ぷら粉	2	[{"changed": {"fields": ["Hero"]}}]	24	1
659	2022-03-23 08:50:24.740363+00	2	から揚げ粉	2	[{"changed": {"fields": ["Hero"]}}]	24	1
660	2022-03-23 08:50:36.89834+00	3	バッター・打ち粉	2	[{"changed": {"fields": ["Hero"]}}]	24	1
661	2022-03-23 08:51:16.587865+00	4	和風メニュー	2	[{"changed": {"fields": ["Hero"]}}]	24	1
662	2022-03-23 08:51:29.800818+00	5	洋風メニュー	2	[{"changed": {"fields": ["Hero"]}}]	24	1
666	2022-03-23 08:52:39.999073+00	55	その他	2	[{"changed": {"fields": ["Hero"]}}]	24	1
667	2022-03-23 08:54:38.872929+00	9	パスタソース	2	[{"changed": {"fields": ["Hero"]}}]	24	1
668	2022-03-23 09:01:20.533968+00	7	EC（リンク）	3		27	1
669	2022-03-24 21:42:41.306308+00	50	天ぷら粉かるサク衣(332440)	2	[{"changed": {"fields": ["Related"]}}]	25	1
670	2022-03-24 21:46:08.153837+00	50	天ぷら粉かるサク衣(332440)	2	[{"changed": {"fields": ["Related"]}}]	25	1
671	2022-03-24 21:47:40.265316+00	51	天ぷら粉かるサク衣(395320)	2	[{"changed": {"fields": ["Related"]}}]	25	1
672	2022-03-24 21:48:19.796918+00	52	天ぷら粉打ち粉いらずのかるサク衣(394810)	2	[{"changed": {"fields": ["Related"]}}]	25	1
673	2022-03-24 21:53:53.639649+00	53	天ぷら粉追い種いらずの揚げ上手(381680)	2	[{"changed": {"fields": ["Related"]}}]	25	1
674	2022-03-24 21:57:43.149422+00	54	天ぷら粉打ち粉いらずの揚げ上手(395080)	2	[{"changed": {"fields": ["Related"]}}]	25	1
675	2022-03-24 21:58:40.340182+00	55	天ぷら粉かる～い揚げ上手(305630)	2	[{"changed": {"fields": ["Related"]}}]	25	1
676	2022-03-24 21:59:31.726846+00	56	天ぷら粉 かる～い揚げ上手Bタイプ(305760)	2	[{"changed": {"fields": ["Related"]}}]	25	1
677	2022-03-24 22:00:34.071818+00	57	天ぷら粉レンジでサクサク揚げ上手(334870)	2	[{"changed": {"fields": ["Related"]}}]	25	1
678	2022-03-24 22:01:33.96996+00	58	天ぷら粉揚げ上手(334510)	2	[{"changed": {"fields": ["Related"]}}]	25	1
679	2022-03-24 22:01:57.135653+00	59	天ぷら粉揚げ上手(334570)	2	[{"changed": {"fields": ["Related"]}}]	25	1
680	2022-03-24 22:15:02.130447+00	60	天ぷら粉揚げ上手Jタイプ(334730)	2	[{"changed": {"fields": ["Related"]}}]	25	1
681	2022-03-24 22:15:25.27953+00	61	天ぷら粉揚げ上手Jタイプ(334620)	2	[{"changed": {"fields": ["Related"]}}]	25	1
682	2022-03-24 22:16:15.903952+00	62	天ぷら粉揚げ上手Cタイプ(334690)	2	[{"changed": {"fields": ["Related"]}}]	25	1
683	2022-03-24 22:16:38.641764+00	63	天ぷら粉揚げ上手Cタイプ(334610)	2	[{"changed": {"fields": ["Related"]}}]	25	1
684	2022-03-24 22:17:05.657163+00	64	天ぷら粉軽やか衣(305950)	2	[{"changed": {"fields": ["Related"]}}]	25	1
685	2022-03-24 22:17:35.548087+00	65	おいしい天ぷら粉(340480)	2	[{"changed": {"fields": ["Related"]}}]	25	1
686	2022-03-24 22:18:07.631235+00	66	国内麦小麦粉使用おいしい天ぷら粉(334860)	2	[{"changed": {"fields": ["Related"]}}]	25	1
687	2022-03-24 22:18:53.060413+00	67	天ぷら粉Aタイプ(340020)	2	[{"changed": {"fields": ["Related"]}}]	25	1
688	2022-03-24 22:19:28.98769+00	68	天ぷら粉Aタイプ(340430)	2	[{"changed": {"fields": ["Related"]}}]	25	1
689	2022-03-24 22:20:10.818412+00	69	天ぷら粉A2タイプ(340490)	2	[{"changed": {"fields": ["Related"]}}]	25	1
690	2022-03-24 22:20:52.121952+00	70	天ぷら粉Bタイプ(334640)	2	[{"changed": {"fields": ["Related"]}}]	25	1
691	2022-03-24 22:21:56.972639+00	71	おそば屋さん・うどん屋さんの天ぷら粉 つゆにのせてもしっかり衣(394990)	2	[{"changed": {"fields": ["Related"]}}]	25	1
692	2022-03-24 22:25:06.455249+00	72	おそば屋さん・うどん屋さんの天ぷら粉 つゆ溶け衣(394980)	2	[{"changed": {"fields": ["Related"]}}]	25	1
693	2022-03-24 22:25:46.634747+00	73	天ぷら粉デラックス(334590)	2	[{"changed": {"fields": ["Related"]}}]	25	1
694	2022-03-24 22:26:14.151627+00	74	天ぷら粉　味わい衣(271390)	2	[{"changed": {"fields": ["Related"]}}]	25	1
695	2022-03-24 22:26:49.839131+00	75	天ぷら粉　パックに入れてもかるサク衣(271380)	2	[{"changed": {"fields": ["Related"]}}]	25	1
696	2022-03-24 22:27:33.733338+00	76	THE KARAAGE から揚げ粉(337590)	2	[{"changed": {"fields": ["Related"]}}]	25	1
697	2022-03-24 22:27:56.358266+00	77	聖地中津からあげセット しょうゆだれ(335160)	2	[{"changed": {"fields": ["Related"]}}]	25	1
698	2022-03-24 22:28:07.370973+00	78	聖地中津からあげセット 塩だれ(335170)	2	[{"changed": {"fields": ["Related"]}}]	25	1
699	2022-03-24 22:28:32.504228+00	79	から揚げ粉 #11-68(470430)	2	[{"changed": {"fields": ["Related"]}}]	25	1
700	2022-03-24 22:28:51.8174+00	80	たつた揚げ粉 #13-35(471350)	2	[{"changed": {"fields": ["Related"]}}]	25	1
701	2022-03-24 22:29:13.366707+00	81	から揚げ粉 唐揚王(335140)	2	[{"changed": {"fields": ["Related"]}}]	25	1
702	2022-03-24 22:29:35.917891+00	82	から揚げ粉 唐揚王(335150)	2	[{"changed": {"fields": ["Related"]}}]	25	1
703	2022-03-24 22:29:46.973731+00	83	から揚げ粉(337690)	2	[{"changed": {"fields": ["Related"]}}]	25	1
704	2022-03-24 22:30:27.974458+00	85	から揚げ粉 にんにく・しょうゆ風味(335010)	2	[{"changed": {"fields": ["Related"]}}]	25	1
705	2022-03-24 22:31:48.683301+00	86	から揚げ粉味付け自由な水溶きタイプ　中華街仕立て(270590)	2	[{"changed": {"fields": ["Related"]}}]	25	1
706	2022-03-24 22:32:22.212619+00	87	薄衣サクサクから揚げ粉(271300)	2	[{"changed": {"fields": ["Related"]}}]	25	1
707	2022-03-24 22:32:53.964528+00	88	ゴツゴツから揚げ粉(271310)	2	[{"changed": {"fields": ["Related"]}}]	25	1
708	2022-03-24 22:33:26.105036+00	89	タレかけカリサクから揚げ粉(271320)	2	[{"changed": {"fields": ["Related"]}}]	25	1
709	2022-03-24 22:34:08.64824+00	90	ザクザクから揚げ粉(271330)	2	[{"changed": {"fields": ["Related"]}}]	25	1
710	2022-03-24 22:35:18.252715+00	91	THE TONKATSU(337610)	2	[{"changed": {"fields": ["Related"]}}]	25	1
711	2022-03-24 22:36:42.667981+00	92	バッターミックス　これで結着！(410480)	2	[{"changed": {"fields": ["Related"]}}]	25	1
712	2022-03-24 22:39:42.895678+00	93	バッターミックス サクミ長持ち上手！(410490)	2	[{"changed": {"fields": ["Related"]}}]	25	1
713	2022-03-24 22:40:58.994779+00	94	コロッケ用ミックス　#23-58(472310)	2	[{"changed": {"fields": ["Related"]}}]	25	1
714	2022-03-24 22:42:14.356733+00	95	コロッケ用ミックス　#63-01(453010)	2	[{"changed": {"fields": ["Related"]}}]	25	1
715	2022-03-24 22:43:25.435104+00	96	パン粉が良くつく粉(337700)	2	[{"changed": {"fields": ["Related"]}}]	25	1
716	2022-03-24 22:44:31.437532+00	97	打ち粉ミックス これで結着！(335050)	2	[{"changed": {"fields": ["Related"]}}]	25	1
717	2022-03-24 22:45:55.16098+00	98	トンカツ用ミックス #24-25(474250)	2	[{"changed": {"fields": ["Related"]}}]	25	1
718	2022-03-24 22:47:11.454653+00	99	海老フライ用ミックス #22-43(472090)	2	[{"changed": {"fields": ["Related"]}}]	25	1
719	2022-03-24 22:48:35.80817+00	100	魚フライ用ミックス #62-60(452600)	2	[{"changed": {"fields": ["Related"]}}]	25	1
720	2022-03-24 22:49:52.193914+00	101	メンチカツ用ミックス #24-HU(470850)	2	[{"changed": {"fields": ["Related"]}}]	25	1
721	2022-03-24 22:51:08.996726+00	102	打ち粉ミックス（魚介用） #22-02(471520)	2	[{"changed": {"fields": ["Related"]}}]	25	1
722	2022-03-24 22:52:46.774789+00	103	打ち粉ミックス（畜肉用） #24-93(474930)	2	[{"changed": {"fields": ["Related"]}}]	25	1
723	2022-03-24 22:54:10.231617+00	104	たこ焼粉(313790)	2	[{"changed": {"fields": ["Related"]}}]	25	1
724	2022-03-24 23:03:48.005988+00	105	お好み焼粉 山いも入り(313780)	2	[{"changed": {"fields": ["Related"]}}]	25	1
725	2022-03-24 23:05:21.575566+00	107	しっとり食感！鯛焼きミックス(348390)	2	[{"changed": {"fields": ["Related"]}}]	25	1
726	2022-03-24 23:06:36.00483+00	108	たい焼きミックス #916(469160)	2	[{"changed": {"fields": ["Related"]}}]	25	1
727	2022-03-24 23:07:46.890435+00	109	大判焼きミックス #913(469130)	2	[{"changed": {"fields": ["Related"]}}]	25	1
728	2022-03-24 23:08:50.92975+00	110	お好み焼きミックス #912(469120)	2	[{"changed": {"fields": ["Related"]}}]	25	1
729	2022-03-24 23:09:55.960745+00	111	たこ焼きミックス #9CD(460270)	2	[{"changed": {"fields": ["Related"]}}]	25	1
730	2022-03-24 23:11:24.925182+00	112	たこ焼横丁 関西丸たこ焼(385020)	2	[{"changed": {"fields": ["Related"]}}]	25	1
731	2022-03-24 23:12:37.318217+00	113	たこ焼横丁 Nたこ焼(387740)	2	[{"changed": {"fields": ["Related"]}}]	25	1
732	2022-03-24 23:13:48.336753+00	122	パンケーキミックス #505(465050)	2	[{"changed": {"fields": ["Related"]}}]	25	1
733	2022-03-24 23:14:52.742037+00	115	Rお好み横丁 ふんわりお好み焼（豚玉）(309430)	2	[{"changed": {"fields": ["Related"]}}]	25	1
734	2022-03-24 23:17:58.156872+00	116	ふんわりお好み焼（豚天）(383060)	2	[{"changed": {"fields": ["Related"]}}]	25	1
735	2022-03-24 23:19:04.936616+00	117	冷凍のどごし冷麺(386860)	2	[{"changed": {"fields": ["Related"]}}]	25	1
736	2022-03-24 23:20:09.219009+00	118	型のいらないホットケーキミックス 厚焼き上手(348240)	2	[{"changed": {"fields": ["Related"]}}]	25	1
737	2022-03-24 23:20:36.126754+00	119	達人厨房 しっとりパンケーキMIX(351050)	2	[{"changed": {"fields": ["Related"]}}]	25	1
738	2022-03-24 23:20:55.543538+00	120	達人厨房 クレープMIX(350410)	2	[{"changed": {"fields": ["Related"]}}]	25	1
739	2022-03-24 23:21:56.000004+00	121	ホットケーキミックス #503(465030)	2	[{"changed": {"fields": ["Related"]}}]	25	1
740	2022-03-24 23:24:07.622125+00	122	パンケーキミックス #505(465050)	2	[{"changed": {"fields": ["Related"]}}]	25	1
741	2022-03-24 23:25:17.302446+00	123	クレープミックス #707(467070)	2	[{"changed": {"fields": ["Related"]}}]	25	1
742	2022-03-24 23:26:20.461424+00	124	水1リットルでできる蒸しパンミックス（白）(348250)	2	[{"changed": {"fields": ["Related"]}}]	25	1
743	2022-03-24 23:27:33.165594+00	125	水1リットルでできる蒸しパンミックス（黒）黒糖風味(348300)	2	[{"changed": {"fields": ["Related"]}}]	25	1
744	2022-03-24 23:28:35.920076+00	126	サクサク食感！クリスピーワッフルミックス(348180)	2	[{"changed": {"fields": ["Related"]}}]	25	1
745	2022-03-24 23:29:33.574707+00	127	ふわふわ食感！ソフトワッフルミックス(348190)	2	[{"changed": {"fields": ["Related"]}}]	25	1
746	2022-03-24 23:31:32.323354+00	128	イースト不要！ベルギーワッフルミックス(348200)	2	[{"changed": {"fields": ["Related"]}}]	25	1
747	2022-03-24 23:32:29.796595+00	129	ミシェーラ ナポリ風ピッツァミックス(348270)	2	[{"changed": {"fields": ["Related"]}}]	25	1
748	2022-03-24 23:33:33.294234+00	130	ナポリ風ピッツァミックス(348010)	2	[{"changed": {"fields": ["Related"]}}]	25	1
749	2022-03-24 23:33:52.437959+00	131	達人厨房 クリーミーホワイトソースMIX(350380)	2	[{"changed": {"fields": ["Related"]}}]	25	1
750	2022-03-24 23:34:49.010247+00	132	自然解凍ミニパンケーキ(386780)	2	[{"changed": {"fields": ["Related"]}}]	25	1
751	2022-03-24 23:35:32.708616+00	133	チュロス®（ハーフサイズ）フライ＆ベイク(383990)	2	[{"changed": {"fields": ["Related"]}}]	25	1
752	2022-03-24 23:36:10.472113+00	134	チュロス®(381330)	2	[{"changed": {"fields": ["Related"]}}]	25	1
753	2022-03-24 23:36:50.646072+00	135	チュロス®（ミルク味）(339360)	2	[{"changed": {"fields": ["Related"]}}]	25	1
754	2022-03-24 23:37:24.501237+00	136	チュロス®（チョコ味）(308760)	2	[{"changed": {"fields": ["Related"]}}]	25	1
755	2022-03-24 23:37:59.936785+00	137	ミニチュロス(388890)	2	[{"changed": {"fields": ["Related"]}}]	25	1
756	2022-03-24 23:38:28.839495+00	138	ミニチュロス(チョコ味)(388920)	2	[{"changed": {"fields": ["Related"]}}]	25	1
757	2022-03-24 23:41:52.336844+00	139	マ・マー スパゲティ　1.4(395880)	2	[{"changed": {"fields": ["Related"]}}]	25	1
758	2022-03-24 23:44:50.38283+00	140	マ・マー スパゲティ　1.6(395890)	2	[{"changed": {"fields": ["Related"]}}]	25	1
759	2022-03-24 23:47:47.14034+00	141	マ・マー スパゲティ　1.7(395900)	2	[{"changed": {"fields": ["Related"]}}]	25	1
760	2022-03-24 23:50:35.90443+00	142	マ・マー スパゲティ　1.9(395950)	2	[{"changed": {"fields": ["Related"]}}]	25	1
761	2022-03-24 23:53:16.032218+00	143	マ・マー スパゲティ　2.2(368840)	2	[{"changed": {"fields": ["Related"]}}]	25	1
762	2022-03-24 23:59:28.575228+00	144	早ゆでスパゲティプロント 1.6mm(361960)	2	[{"changed": {"fields": ["Related"]}}]	25	1
763	2022-03-25 00:06:50.488661+00	145	早ゆでスパゲティプロント 1.6mm(368850)	2	[{"changed": {"fields": ["Related"]}}]	25	1
764	2022-03-25 00:09:47.209881+00	146	マ・マー 早ゆでスパゲティ プロント 2.2mm(343980)	2	[{"changed": {"fields": ["Related"]}}]	25	1
765	2022-03-25 00:22:09.958475+00	147	マ・マーTHE　PRO早ゆでスパゲティ1.6mm(271440)	2	[{"changed": {"fields": ["Related"]}}]	25	1
766	2022-03-25 00:25:53.252951+00	148	マ・マー ミニスパゲティ　ミニ1.6(395910)	2	[{"changed": {"fields": ["Related"]}}]	25	1
767	2022-03-25 00:29:08.982104+00	149	マ・マー ミニスパゲティ　ミニ1.7(395920)	2	[{"changed": {"fields": ["Related"]}}]	25	1
768	2022-03-25 00:31:52.876748+00	150	マッシモ プレミオ #201　1.5(364740)	2	[{"changed": {"fields": ["Related"]}}]	25	1
769	2022-03-25 00:32:21.557433+00	151	マッシモ プレミオ #201　1.5(364730)	2	[{"changed": {"fields": ["Related"]}}]	25	1
770	2022-03-25 00:32:50.334993+00	152	マッシモ プレミオ #201　1.7(364720)	2	[{"changed": {"fields": ["Related"]}}]	25	1
771	2022-03-25 00:33:17.023833+00	153	マッシモ プレミオ #201　1.7(364750)	2	[{"changed": {"fields": ["Related"]}}]	25	1
772	2022-03-25 00:33:55.391107+00	154	スパゲッティーニ(353210)	2	[{"changed": {"fields": ["Related"]}}]	25	1
773	2022-03-25 00:34:32.661433+00	155	リングイネ(353220)	2	[{"changed": {"fields": ["Related"]}}]	25	1
774	2022-03-25 00:34:57.637617+00	156	フェットチーネ（卵入り）(353230)	2	[{"changed": {"fields": ["Related"]}}]	25	1
775	2022-03-25 00:35:21.332039+00	157	フェットチーネ（ほうれん草入り）(353240)	2	[{"changed": {"fields": ["Related"]}}]	25	1
776	2022-03-25 00:36:22.854521+00	158	タリオリーニ（卵入り）(353250)	2	[{"changed": {"fields": ["Related"]}}]	25	1
777	2022-03-25 00:36:57.804355+00	159	ラウンドアップスパゲティ Super Hardタイプ 1.6mm《塩ゆで》　180g(353040)	2	[{"changed": {"fields": ["Related"]}}]	25	1
778	2022-03-25 00:38:04.832396+00	160	ラウンドアップスパゲティ Super Hardタイプ 1.6mm《塩ゆで》　220g(353050)	2	[{"changed": {"fields": ["Related"]}}]	25	1
779	2022-03-25 00:38:34.77537+00	161	ラウンドアップスパゲティ Super Hardタイプ 1.6mm《塩ゆで》　250g(353060)	2	[{"changed": {"fields": ["Related"]}}]	25	1
780	2022-03-25 00:39:03.513598+00	162	ラウンドアップスパゲティ 1.4mm《塩ゆで》(353140)	2	[{"changed": {"fields": ["Related"]}}]	25	1
781	2022-03-25 00:39:33.231564+00	163	ラウンドアップスパゲティ 太麺タイプ 2.2mm《塩ゆで》(353180)	2	[{"changed": {"fields": ["Related"]}}]	25	1
782	2022-03-25 00:40:06.852259+00	164	ラウンドアップスパゲティ 1.7mm PREMIUM《塩ゆで》(387690)	2	[{"changed": {"fields": ["Related"]}}]	25	1
783	2022-03-25 00:40:31.692387+00	165	マッシモプレミオ 冷凍スパゲティ《塩ゆで》(353100)	2	[{"changed": {"fields": ["Related"]}}]	25	1
784	2022-03-25 00:43:38.701604+00	256	ラウンドアップパスタスチーマー PSW-777(309310)	2	[{"changed": {"fields": ["Related"]}}]	25	1
785	2022-03-25 00:43:49.714144+00	257	ラウンドアップパスタスチーマー      軟水器(309490)	2	[{"changed": {"fields": ["Related"]}}]	25	1
786	2022-03-25 00:47:19.697748+00	255	冷凍パスタ No.11 Spaghettini（スパゲッティーニ）(321120)	2	[{"changed": {"fields": ["Related"]}}]	25	1
787	2022-03-25 00:47:56.403985+00	254	No.41 Penne Rigate Organic（ペンネ リガーテ オーガニック）(368830)	2	[{"changed": {"fields": ["Related"]}}]	25	1
788	2022-03-25 00:48:46.632167+00	253	No.34 Fusilli Organic（フスィリ オーガニック）(368820)	2	[{"changed": {"fields": ["Related"]}}]	25	1
789	2022-03-25 00:49:00.162183+00	252	No.12 Spaghetti Organic（スパゲッティ オーガニック）(368810)	2	[{"changed": {"fields": ["Related"]}}]	25	1
790	2022-03-25 00:49:09.50809+00	251	No.11 Spaghettini Organic（スパゲッティーニ オーガニック）(368800)	2	[{"changed": {"fields": ["Related"]}}]	25	1
791	2022-03-25 00:51:03.960372+00	223	明太子ソース　（チューブ入・パスタ用）(333690)	2	[{"changed": {"fields": ["Related"]}}]	25	1
792	2022-03-25 00:51:58.829122+00	222	たらこソース　（チューブ入・パスタ用）(333680)	2	[{"changed": {"fields": ["Related"]}}]	25	1
793	2022-03-25 00:52:52.859635+00	221	なめらかカルボナーラソース（個食用）(327750)	2	[{"changed": {"fields": ["Related"]}}]	25	1
794	2022-03-25 00:53:52.53471+00	220	なめらかカルボナーラソース　（1kg）(327820)	2	[{"changed": {"fields": ["Related"]}}]	25	1
795	2022-03-25 00:54:53.161393+00	219	ポルチーニクリームソース(385730)	2	[{"changed": {"fields": ["Related"]}}]	25	1
796	2022-03-25 00:55:52.120468+00	218	完熟トマトソース(386600)	2	[{"changed": {"fields": ["Related"]}}]	25	1
797	2022-03-25 00:56:50.069399+00	217	ナポリタンソース(386580)	2	[{"changed": {"fields": ["Related"]}}]	25	1
798	2022-03-25 00:57:38.286547+00	216	ボロネーゼ(386610)	2	[{"changed": {"fields": ["Related"]}}]	25	1
799	2022-03-25 00:58:29.678555+00	215	HQクリームソース（1kg）(378750)	2	[{"changed": {"fields": ["Related"]}}]	25	1
800	2022-03-25 00:59:18.280463+00	214	N HQポモドーロソース（1kg）(386590)	2	[{"changed": {"fields": ["Related"]}}]	25	1
801	2022-03-25 00:59:57.094747+00	213	サルサポモドーロ(395600)	2	[{"changed": {"fields": ["Related"]}}]	25	1
802	2022-03-25 01:00:26.281413+00	212	ミートソース(395560)	2	[{"changed": {"fields": ["Related"]}}]	25	1
803	2022-03-25 01:00:51.547635+00	211	ミートソース(395680)	2	[{"changed": {"fields": ["Related"]}}]	25	1
804	2022-03-25 01:01:20.882124+00	210	完熟トマトのソース(375600)	2	[{"changed": {"fields": ["Related"]}}]	25	1
805	2022-03-25 01:02:15.000468+00	209	ボロネーゼ(331750)	2	[{"changed": {"fields": ["Related"]}}]	25	1
806	2022-03-25 01:04:52.449571+00	208	テイクアウト用生パスタスパゲティ(388930)	2	[{"changed": {"fields": ["Related"]}}]	25	1
807	2022-03-25 01:05:10.242714+00	207	マ・マーTHE PRO Smile Meal やさしい味わい 和風パスタ(290480)	2	[{"changed": {"fields": ["Related"]}}]	25	1
808	2022-03-25 01:05:21.794989+00	206	マ・マーTHE PRO Smile Meal やさしい味わい ナポリタン(290470)	2	[{"changed": {"fields": ["Related"]}}]	25	1
809	2022-03-25 01:06:20.906893+00	205	ペペロンチーニ(290460)	2	[{"changed": {"fields": ["Related"]}}]	25	1
810	2022-03-25 01:06:45.083698+00	204	たらこ(290190)	2	[{"changed": {"fields": ["Related"]}}]	25	1
811	2022-03-25 01:07:06.537256+00	203	和風きのこ(290170)	2	[{"changed": {"fields": ["Related"]}}]	25	1
812	2022-03-25 01:07:30.395649+00	202	ナポリタン(290110)	2	[{"changed": {"fields": ["Related"]}}]	25	1
813	2022-03-25 01:07:54.252548+00	201	N付け合せ用 塩バター(333780)	2	[{"changed": {"fields": ["Related"]}}]	25	1
814	2022-03-25 01:08:20.190731+00	200	N付け合せ用 ナポリタン(333770)	2	[{"changed": {"fields": ["Related"]}}]	25	1
815	2022-03-25 01:08:45.927761+00	199	N惣菜用 焼きスパゲティ ナポリタン(333750)	2	[{"changed": {"fields": ["Related"]}}]	25	1
816	2022-03-25 01:09:23.284818+00	198	N惣菜用 焼きスパゲティ ナポリタン《2.2mm》(333740)	2	[{"changed": {"fields": ["Related"]}}]	25	1
817	2022-03-25 01:09:51.451619+00	197	レンジ用スパゲティ プレーン(382390)	2	[{"changed": {"fields": ["Related"]}}]	25	1
818	2022-03-25 01:10:18.248982+00	196	レンジ用スパゲティ たらこと舞茸(321420)	2	[{"changed": {"fields": ["Related"]}}]	25	1
819	2022-03-25 01:10:47.351713+00	195	レンジ用スパゲティ ミートソース(387710)	2	[{"changed": {"fields": ["Related"]}}]	25	1
820	2022-03-25 01:11:14.079897+00	194	レンジ用スパゲティ カルボナーラ(321390)	2	[{"changed": {"fields": ["Related"]}}]	25	1
821	2022-03-25 01:11:38.47145+00	193	レンジ用ソテースパゲティ ナポリタン(321400)	2	[{"changed": {"fields": ["Related"]}}]	25	1
822	2022-03-25 01:12:12.795506+00	192	PASTA STELLA ポルチーニクリーム(290050)	2	[{"changed": {"fields": ["Related"]}}]	25	1
823	2022-03-25 01:12:44.647851+00	191	PASTA STELLA 濃厚海老トマトクリーム(290060)	2	[{"changed": {"fields": ["Related"]}}]	25	1
824	2022-03-25 01:13:21.93156+00	190	PASTA STELLA クリーミーボロネーゼ(290040)	2	[{"changed": {"fields": ["Related"]}}]	25	1
825	2022-03-25 01:14:00.311736+00	189	PASTA STELLA クリーミーカルボナーラ(290070)	2	[{"changed": {"fields": ["Related"]}}]	25	1
826	2022-03-25 01:15:02.017315+00	188	PASTA STELLA 和風たらこ(290080)	2	[{"changed": {"fields": ["Related"]}}]	25	1
827	2022-03-25 01:15:33.887456+00	187	PASTA STELLA ソテーナポリタン(290030)	2	[{"changed": {"fields": ["Related"]}}]	25	1
828	2022-03-25 01:16:17.755989+00	186	マ・マー THE PRO IQF（バラ凍結）MINI シェル(290430)	2	[{"changed": {"fields": ["Related"]}}]	25	1
829	2022-03-25 01:17:00.665594+00	185	マ・マー THE PRO IQF（バラ凍結）MINI ストレートマカロニ(290440)	2	[{"changed": {"fields": ["Related"]}}]	25	1
830	2022-03-25 01:18:27.706054+00	184	マ・マー THE PRO IQF（バラ凍結）MINI フィジリ(290420)	2	[{"changed": {"fields": ["Related"]}}]	25	1
831	2022-03-25 01:19:07.599179+00	183	IQF（バラ凍結）パッケリ(290290)	2	[{"changed": {"fields": ["Related"]}}]	25	1
832	2022-03-25 01:19:59.665804+00	182	IQF（バラ凍結）カサレッチャ(290280)	2	[{"changed": {"fields": ["Related"]}}]	25	1
833	2022-03-25 01:20:40.687685+00	181	IQF（バラ凍結）リガトーニ(290230)	2	[{"changed": {"fields": ["Related"]}}]	25	1
834	2022-03-25 01:21:19.611386+00	180	IQF（バラ凍結）フィジリ(290220)	2	[{"changed": {"fields": ["Related"]}}]	25	1
835	2022-03-25 01:22:09.712323+00	179	IQF（バラ凍結）ペンネリガーテ(290210)	2	[{"changed": {"fields": ["Related"]}}]	25	1
\.


--
-- Data for Name: django_celery_beat_clockedschedule; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.django_celery_beat_clockedschedule (id, clocked_time) FROM stdin;
\.


--
-- Data for Name: django_celery_beat_crontabschedule; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.django_celery_beat_crontabschedule (id, minute, hour, day_of_week, day_of_month, month_of_year, timezone) FROM stdin;
1	0	4	*	*	*	Asia/Tokyo
\.


--
-- Data for Name: django_celery_beat_intervalschedule; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.django_celery_beat_intervalschedule (id, every, period) FROM stdin;
\.


--
-- Data for Name: django_celery_beat_periodictask; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.django_celery_beat_periodictask (id, name, task, args, kwargs, queue, exchange, routing_key, expires, enabled, last_run_at, total_run_count, date_changed, description, crontab_id, interval_id, solar_id, one_off, start_time, priority, headers, clocked_id, expire_seconds) FROM stdin;
1	celery.backend_cleanup	celery.backend_cleanup	[]	{}	\N	\N	\N	\N	t	2022-03-24 19:00:00.000717+00	16	2022-03-24 21:40:06.095269+00		1	\N	\N	f	\N	\N	{}	\N	43200
\.


--
-- Data for Name: django_celery_beat_periodictasks; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.django_celery_beat_periodictasks (ident, last_update) FROM stdin;
1	2022-03-24 21:40:06.093023+00
\.


--
-- Data for Name: django_celery_beat_solarschedule; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.django_celery_beat_solarschedule (id, event, latitude, longitude) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	auth	permission
2	auth	group
3	contenttypes	contenttype
4	sessions	session
5	sites	site
6	admin	logentry
7	account	emailaddress
8	account	emailconfirmation
9	socialaccount	socialaccount
10	socialaccount	socialapp
11	socialaccount	socialtoken
12	django_celery_beat	crontabschedule
13	django_celery_beat	intervalschedule
14	django_celery_beat	periodictask
15	django_celery_beat	periodictasks
16	django_celery_beat	solarschedule
17	django_celery_beat	clockedschedule
18	authtoken	token
19	authtoken	tokenproxy
20	users	user
21	easy_thumbnails	source
22	easy_thumbnails	thumbnail
23	easy_thumbnails	thumbnaildimensions
24	products	category
25	products	product
26	products	facility
27	products	industry
28	products	tag
29	products	series
30	products	photo
31	products	handling
32	products	brand
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2022-03-07 09:37:10.540157+00
2	contenttypes	0002_remove_content_type_name	2022-03-07 09:37:10.569508+00
3	auth	0001_initial	2022-03-07 09:37:10.754892+00
4	auth	0002_alter_permission_name_max_length	2022-03-07 09:37:10.774801+00
5	auth	0003_alter_user_email_max_length	2022-03-07 09:37:10.827408+00
6	auth	0004_alter_user_username_opts	2022-03-07 09:37:10.847993+00
7	auth	0005_alter_user_last_login_null	2022-03-07 09:37:10.877223+00
8	auth	0006_require_contenttypes_0002	2022-03-07 09:37:10.883032+00
9	auth	0007_alter_validators_add_error_messages	2022-03-07 09:37:10.931278+00
10	auth	0008_alter_user_username_max_length	2022-03-07 09:37:10.966127+00
11	auth	0009_alter_user_last_name_max_length	2022-03-07 09:37:10.984432+00
12	auth	0010_alter_group_name_max_length	2022-03-07 09:37:11.020012+00
13	auth	0011_update_proxy_permissions	2022-03-07 09:37:11.036858+00
14	auth	0012_alter_user_first_name_max_length	2022-03-07 09:37:11.082625+00
15	users	0001_initial	2022-03-07 09:37:11.276583+00
16	account	0001_initial	2022-03-07 09:37:11.465481+00
17	account	0002_email_max_length	2022-03-07 09:37:11.50795+00
18	admin	0001_initial	2022-03-07 09:37:11.67428+00
19	admin	0002_logentry_remove_auto_add	2022-03-07 09:37:11.706846+00
20	admin	0003_logentry_add_action_flag_choices	2022-03-07 09:37:11.76309+00
21	authtoken	0001_initial	2022-03-07 09:37:11.868338+00
22	authtoken	0002_auto_20160226_1747	2022-03-07 09:37:11.971545+00
23	authtoken	0003_tokenproxy	2022-03-07 09:37:11.979212+00
24	django_celery_beat	0001_initial	2022-03-07 09:37:12.2096+00
25	django_celery_beat	0002_auto_20161118_0346	2022-03-07 09:37:12.269551+00
26	django_celery_beat	0003_auto_20161209_0049	2022-03-07 09:37:12.30653+00
27	django_celery_beat	0004_auto_20170221_0000	2022-03-07 09:37:12.326665+00
28	django_celery_beat	0005_add_solarschedule_events_choices	2022-03-07 09:37:12.345729+00
29	django_celery_beat	0006_auto_20180322_0932	2022-03-07 09:37:12.441548+00
30	django_celery_beat	0007_auto_20180521_0826	2022-03-07 09:37:12.499075+00
31	django_celery_beat	0008_auto_20180914_1922	2022-03-07 09:37:12.601433+00
32	django_celery_beat	0006_auto_20180210_1226	2022-03-07 09:37:12.661591+00
33	django_celery_beat	0006_periodictask_priority	2022-03-07 09:37:12.696736+00
34	django_celery_beat	0009_periodictask_headers	2022-03-07 09:37:12.715238+00
35	django_celery_beat	0010_auto_20190429_0326	2022-03-07 09:37:13.30029+00
36	django_celery_beat	0011_auto_20190508_0153	2022-03-07 09:37:13.348362+00
37	django_celery_beat	0012_periodictask_expire_seconds	2022-03-07 09:37:13.366356+00
38	django_celery_beat	0013_auto_20200609_0727	2022-03-07 09:37:13.411318+00
39	django_celery_beat	0014_remove_clockedschedule_enabled	2022-03-07 09:37:13.426466+00
40	django_celery_beat	0015_edit_solarschedule_events_choices	2022-03-07 09:37:13.468254+00
41	sessions	0001_initial	2022-03-07 09:37:13.513373+00
42	sites	0001_initial	2022-03-07 09:37:13.551652+00
43	sites	0002_alter_domain_unique	2022-03-07 09:37:13.580315+00
44	sites	0003_set_site_domain_and_name	2022-03-07 09:37:13.685046+00
45	sites	0004_alter_options_ordering_domain	2022-03-07 09:37:13.702404+00
46	socialaccount	0001_initial	2022-03-07 09:37:14.308559+00
47	socialaccount	0002_token_max_lengths	2022-03-07 09:37:14.514821+00
48	socialaccount	0003_extra_data_default_dict	2022-03-07 09:37:14.579944+00
49	easy_thumbnails	0001_initial	2022-03-08 22:35:29.973149+00
50	easy_thumbnails	0002_thumbnaildimensions	2022-03-08 22:35:29.989016+00
52	products	0002_alter_product_category	2022-03-12 09:08:18.837337+00
54	products	0002_auto_20220317_0809	2022-03-16 23:09:29.38488+00
55	products	0003_alter_product_shipping_date	2022-03-16 23:59:37.121868+00
56	products	0004_auto_20220317_1012	2022-03-17 01:12:27.575787+00
57	products	0005_auto_20220317_1014	2022-03-17 01:14:13.217748+00
58	products	0006_auto_20220317_1025	2022-03-17 01:25:49.365147+00
67	products	0001_initial	2022-03-20 05:02:46.047369+00
68	products	0002_auto_20220320_1428	2022-03-20 05:28:15.124451+00
69	products	0003_rename_packing_product_packing	2022-03-20 06:21:49.731359+00
70	products	0004_rename_series_series_brand	2022-03-20 06:50:21.549349+00
71	products	0005_auto_20220321_0905	2022-03-21 00:05:22.761708+00
72	products	0006_auto_20220321_1042	2022-03-21 01:42:36.041179+00
73	products	0007_remove_product_preservation	2022-03-22 10:25:34.095368+00
74	products	0008_auto_20220322_2131	2022-03-22 12:31:48.424045+00
75	products	0009_alter_photo_product	2022-03-23 10:58:17.315282+00
76	products	0010_auto_20220325_0412	2022-03-24 21:02:50.019764+00
77	products	0011_category_the_order	2022-03-24 21:02:50.035475+00
78	products	0012_auto_20220325_0428	2022-03-24 21:02:50.132575+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
qp0lmt06j5zo3q7eezxdgbirau3ps7js	.eJxVjMsOgjAQRf-la9PQFunUpXu_gUznYVEDCYWV8d-FhIVu7znnvk2P61L6tcrcD2wuxpnT75aRnjLugB843idL07jMQ7a7Yg9a7W1ieV0P9--gYC1bHbI01CE0LXgOrXpJLC6S80pRUeHckebYkoAyhZjT5oJwkwKSRjCfLwRGOQY:1nSsfE:-muGv_OBhEaoreC2OK6M13zA5oJQEl9W8u5cKy46JTs	2022-03-26 03:43:32.893531+00
cuf8kz70qxcewkj1nch8q7fpddetn7o8	.eJxVjMsOgjAQRf-la9PQFunUpXu_gUznYVEDCYWV8d-FhIVu7znnvk2P61L6tcrcD2wuxpnT75aRnjLugB843idL07jMQ7a7Yg9a7W1ieV0P9--gYC1bHbI01CE0LXgOrXpJLC6S80pRUeHckebYkoAyhZjT5oJwkwKSRjCfLwRGOQY:1nSxXt:gOhvtlyC0E7BeekiB4aLhi7Zw42aqXGSJKRjG6HhCBc	2022-03-26 08:56:17.346942+00
6rmi0hnzf2zyqizt02o8jq7ag6tvj599	.eJxVjMsOgjAQRf-la9PQFunUpXu_gUznYVEDCYWV8d-FhIVu7znnvk2P61L6tcrcD2wuxpnT75aRnjLugB843idL07jMQ7a7Yg9a7W1ieV0P9--gYC1bHbI01CE0LXgOrXpJLC6S80pRUeHckebYkoAyhZjT5oJwkwKSRjCfLwRGOQY:1nVlYy:b0V5DGcToCEGXjWXLkAf-SyAx9AN_cmjHQhCeaHHHcY	2022-04-03 02:45:00.923408+00
9mqurut3gbvl7owq25urcgcnwnf6qikp	.eJxVjEEOwiAQRe_C2pAyhQIu3XsGMjCDVA0kpV0Z765NutDtf-_9lwi4rSVsnZcwkzgLJU6_W8T04LoDumO9NZlaXZc5yl2RB-3y2oifl8P9OyjYy7cGrREhs_MeLTlto2MFUdGgUnLJwMhgTcY4DlkbmFABRWZwhnweJxTvD-jVOCo:1nWqRP:rNKaPwNaSkka0rIYi9hozwUnB7yAPqaOASJ4X7VqOKE	2022-04-06 02:09:39.064417+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.django_site (id, domain, name) FROM stdin;
1	pro.nisshin-seifun-welna.com	nisshin_b2b
\.


--
-- Data for Name: easy_thumbnails_source; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.easy_thumbnails_source (id, storage_hash, name, modified) FROM stdin;
1	f9bde26a1556cd667f742bd34ec7c55e	photos/271300_01.jpg	2022-03-19 13:54:33.190988+00
3	f9bde26a1556cd667f742bd34ec7c55e	photos/から揚け調理画像①.jpg	2022-03-21 13:08:01.815952+00
7	f9bde26a1556cd667f742bd34ec7c55e	photos/ヘンネリカーテ.jpg	2022-03-21 13:12:17.808731+00
8	f9bde26a1556cd667f742bd34ec7c55e	photos/から揚け調理画像①_AbJIrkk.jpg	2022-03-21 13:12:38.363651+00
9	f9bde26a1556cd667f742bd34ec7c55e	photos/本体-左_777改.jpg	2022-03-21 13:13:22.560569+00
10	f9bde26a1556cd667f742bd34ec7c55e	photos/AI_画像.jpg	2022-03-21 13:17:42.545866+00
2	f9bde26a1556cd667f742bd34ec7c55e	photos/天ふら粉アイコン.jpg	2022-03-21 13:39:19.024323+00
13	f9bde26a1556cd667f742bd34ec7c55e	photos/からあけ.jpg	2022-03-21 13:39:20.290344+00
11	f9bde26a1556cd667f742bd34ec7c55e	photos/AI_画像_qrRT6tk.jpg	2022-03-21 13:39:20.927524+00
4	f9bde26a1556cd667f742bd34ec7c55e	photos/912.jpg	2022-03-21 13:39:21.757016+00
14	f9bde26a1556cd667f742bd34ec7c55e	photos/洋風.jpg	2022-03-21 13:39:22.672982+00
6	f9bde26a1556cd667f742bd34ec7c55e	photos/AdobeStock_246860321.jpeg	2022-03-21 13:39:23.259606+00
16	f9bde26a1556cd667f742bd34ec7c55e	photos/ショートハスタ.jpg	2022-03-21 13:39:23.579275+00
12	f9bde26a1556cd667f742bd34ec7c55e	photos/p2_2_30.jpg	2022-03-21 13:39:24.048693+00
5	f9bde26a1556cd667f742bd34ec7c55e	photos/トラティショナルソースシスル.jpg	2022-03-21 13:39:25.470543+00
15	f9bde26a1556cd667f742bd34ec7c55e	photos/その他.jpg	2022-03-21 13:39:25.814496+00
17	f9bde26a1556cd667f742bd34ec7c55e	photos/271390_01.jpg	2022-03-22 06:25:16.739214+00
18	f9bde26a1556cd667f742bd34ec7c55e	photos/340430_01.jpg	2022-03-22 06:25:17.171719+00
19	f9bde26a1556cd667f742bd34ec7c55e	photos/271390_01_6YOGbsw.jpg	2022-03-22 06:25:17.796688+00
20	f9bde26a1556cd667f742bd34ec7c55e	photos/340430_01_15in85P.jpg	2022-03-22 06:25:18.223509+00
21	377252dbefa2af9afc5a489521c16b85	photos/天ふら粉アイコン.jpg	2022-03-23 02:57:40.495895+00
22	377252dbefa2af9afc5a489521c16b85	photos/からあけ.jpg	2022-03-23 02:57:40.878737+00
23	377252dbefa2af9afc5a489521c16b85	photos/AI_画像_qrRT6tk.jpg	2022-03-23 02:57:40.95567+00
24	377252dbefa2af9afc5a489521c16b85	photos/912.jpg	2022-03-23 02:57:41.143524+00
25	377252dbefa2af9afc5a489521c16b85	photos/洋風.jpg	2022-03-23 02:57:41.567236+00
26	377252dbefa2af9afc5a489521c16b85	photos/AdobeStock_246860321.jpeg	2022-03-23 02:57:42.085339+00
27	377252dbefa2af9afc5a489521c16b85	photos/ショートハスタ.jpg	2022-03-23 02:57:42.362783+00
28	377252dbefa2af9afc5a489521c16b85	photos/p2_2_30.jpg	2022-03-23 02:57:42.637419+00
29	377252dbefa2af9afc5a489521c16b85	photos/トラティショナルソースシスル.jpg	2022-03-23 02:57:43.515449+00
30	377252dbefa2af9afc5a489521c16b85	photos/その他.jpg	2022-03-23 02:57:43.813617+00
31	377252dbefa2af9afc5a489521c16b85	photos/heros/331750_01.jpg	2022-03-23 03:06:57.006324+00
32	377252dbefa2af9afc5a489521c16b85	photos/309490_01.jpg	2022-03-23 05:11:28.597606+00
33	377252dbefa2af9afc5a489521c16b85	photos/309310_01.jpg	2022-03-23 05:11:40.539902+00
34	377252dbefa2af9afc5a489521c16b85	photos/321120_01.jpg	2022-03-23 05:12:35.398887+00
35	377252dbefa2af9afc5a489521c16b85	photos/368830_01.jpg	2022-03-23 05:14:05.935831+00
36	377252dbefa2af9afc5a489521c16b85	photos/368820_01.jpg	2022-03-23 05:14:24.880354+00
37	377252dbefa2af9afc5a489521c16b85	photos/368810_01.jpg	2022-03-23 05:14:42.047195+00
38	377252dbefa2af9afc5a489521c16b85	photos/368800_01.jpg	2022-03-23 05:15:01.336327+00
39	377252dbefa2af9afc5a489521c16b85	photos/362510_01.jpg	2022-03-23 05:15:29.944304+00
40	377252dbefa2af9afc5a489521c16b85	photos/363280_01.jpg	2022-03-23 05:15:59.392662+00
41	377252dbefa2af9afc5a489521c16b85	photos/363450_01.jpg	2022-03-23 05:16:18.810043+00
42	377252dbefa2af9afc5a489521c16b85	photos/363480_01.jpg	2022-03-23 05:16:39.72395+00
43	377252dbefa2af9afc5a489521c16b85	photos/368700_01.jpg	2022-03-23 05:17:08.671454+00
44	377252dbefa2af9afc5a489521c16b85	photos/363440_01.jpg	2022-03-23 05:17:23.008135+00
45	377252dbefa2af9afc5a489521c16b85	photos/368500_01.jpg	2022-03-23 05:17:40.086352+00
46	377252dbefa2af9afc5a489521c16b85	photos/368650_01.jpg	2022-03-23 05:18:00.684379+00
47	377252dbefa2af9afc5a489521c16b85	photos/368640_01.jpg	2022-03-23 05:18:20.466904+00
48	377252dbefa2af9afc5a489521c16b85	photos/368610_01.jpg	2022-03-23 05:18:37.199405+00
49	377252dbefa2af9afc5a489521c16b85	photos/368600_01.jpg	2022-03-23 05:19:01.073614+00
50	377252dbefa2af9afc5a489521c16b85	photos/363460_01.jpg	2022-03-23 05:19:16.92395+00
51	377252dbefa2af9afc5a489521c16b85	photos/363420_01.jpg	2022-03-23 05:19:38.428246+00
52	377252dbefa2af9afc5a489521c16b85	photos/363410_01.jpg	2022-03-23 05:19:51.42005+00
53	377252dbefa2af9afc5a489521c16b85	photos/363220_01.jpg	2022-03-23 05:20:04.45475+00
54	377252dbefa2af9afc5a489521c16b85	photos/363210_01.jpg	2022-03-23 05:20:18.201623+00
55	377252dbefa2af9afc5a489521c16b85	photos/363200_01.jpg	2022-03-23 05:20:33.133857+00
56	377252dbefa2af9afc5a489521c16b85	photos/350850_01.jpg	2022-03-23 05:20:48.509106+00
57	377252dbefa2af9afc5a489521c16b85	photos/368620_01.jpg	2022-03-23 05:21:04.748752+00
58	377252dbefa2af9afc5a489521c16b85	photos/368590_01.jpg	2022-03-23 05:21:19.026502+00
59	377252dbefa2af9afc5a489521c16b85	photos/368580_01.jpg	2022-03-23 05:21:34.558301+00
60	377252dbefa2af9afc5a489521c16b85	photos/368790_01.jpg	2022-03-23 05:21:55.92323+00
61	377252dbefa2af9afc5a489521c16b85	photos/368540_01.jpg	2022-03-23 05:22:10.475759+00
62	377252dbefa2af9afc5a489521c16b85	photos/362990_01.jpg	2022-03-23 05:22:26.989339+00
63	377252dbefa2af9afc5a489521c16b85	photos/333690_01.jpg	2022-03-23 05:22:46.659598+00
64	377252dbefa2af9afc5a489521c16b85	photos/333680_01.jpg	2022-03-23 05:23:00.791681+00
65	377252dbefa2af9afc5a489521c16b85	photos/327750_01.jpg	2022-03-23 05:23:15.324595+00
66	377252dbefa2af9afc5a489521c16b85	photos/327820_01.jpg	2022-03-23 05:23:30.335704+00
67	377252dbefa2af9afc5a489521c16b85	photos/385730_01.jpg	2022-03-23 05:23:47.340276+00
68	377252dbefa2af9afc5a489521c16b85	photos/386600_01.jpg	2022-03-23 05:24:01.586654+00
69	377252dbefa2af9afc5a489521c16b85	photos/386580_01.jpg	2022-03-23 05:24:17.439964+00
70	377252dbefa2af9afc5a489521c16b85	photos/386610_01.jpg	2022-03-23 05:24:34.951275+00
71	377252dbefa2af9afc5a489521c16b85	photos/378750_01.jpg	2022-03-23 05:24:51.016726+00
72	377252dbefa2af9afc5a489521c16b85	photos/386590_01.jpg	2022-03-23 05:25:06.353024+00
73	377252dbefa2af9afc5a489521c16b85	photos/395600_01.jpg	2022-03-23 05:25:24.011599+00
74	377252dbefa2af9afc5a489521c16b85	photos/395560_01.jpg	2022-03-23 05:25:37.679054+00
75	377252dbefa2af9afc5a489521c16b85	photos/395680_01.jpg	2022-03-23 05:25:51.573736+00
76	377252dbefa2af9afc5a489521c16b85	photos/375600_01.jpg	2022-03-23 05:26:04.58873+00
77	377252dbefa2af9afc5a489521c16b85	photos/331750_01.jpg	2022-03-23 05:26:51.207629+00
78	377252dbefa2af9afc5a489521c16b85	photos/388930_01.jpg	2022-03-23 05:27:09.284857+00
79	377252dbefa2af9afc5a489521c16b85	photos/290480_01.jpg	2022-03-23 05:27:51.23365+00
80	377252dbefa2af9afc5a489521c16b85	photos/290470_01.jpg	2022-03-23 05:28:12.947683+00
81	377252dbefa2af9afc5a489521c16b85	photos/290460_01.jpg	2022-03-23 05:28:46.091757+00
82	377252dbefa2af9afc5a489521c16b85	photos/290190_01.jpg	2022-03-23 05:29:24.852052+00
83	377252dbefa2af9afc5a489521c16b85	photos/290170_01.jpg	2022-03-23 05:29:51.382555+00
84	377252dbefa2af9afc5a489521c16b85	photos/290110_01.jpg	2022-03-23 05:30:18.299514+00
85	377252dbefa2af9afc5a489521c16b85	photos/333780_01.jpg	2022-03-23 05:30:35.040171+00
86	377252dbefa2af9afc5a489521c16b85	photos/333770_01.jpg	2022-03-23 05:30:49.116078+00
87	377252dbefa2af9afc5a489521c16b85	photos/333750_01.jpg	2022-03-23 05:31:02.181886+00
88	377252dbefa2af9afc5a489521c16b85	photos/333740_01.jpg	2022-03-23 05:31:18.414015+00
89	377252dbefa2af9afc5a489521c16b85	photos/382390_01.jpg	2022-03-23 05:31:33.765382+00
90	377252dbefa2af9afc5a489521c16b85	photos/321420_01.jpg	2022-03-23 05:31:59.155546+00
91	377252dbefa2af9afc5a489521c16b85	photos/387710_01.jpg	2022-03-23 05:32:23.196229+00
92	377252dbefa2af9afc5a489521c16b85	photos/321390_01.jpg	2022-03-23 05:32:50.803334+00
93	377252dbefa2af9afc5a489521c16b85	photos/321400_01.jpg	2022-03-23 05:33:07.555243+00
94	377252dbefa2af9afc5a489521c16b85	photos/290430_01.jpg	2022-03-23 05:35:44.411194+00
95	377252dbefa2af9afc5a489521c16b85	photos/290440_01.jpg	2022-03-23 05:36:14.650587+00
96	377252dbefa2af9afc5a489521c16b85	photos/290420_01.jpg	2022-03-23 05:36:32.590194+00
97	377252dbefa2af9afc5a489521c16b85	photos/290290_01.jpg	2022-03-23 05:36:48.719245+00
98	377252dbefa2af9afc5a489521c16b85	photos/290280_01.jpg	2022-03-23 05:37:07.987936+00
99	377252dbefa2af9afc5a489521c16b85	photos/290230_01.jpg	2022-03-23 05:37:23.984281+00
100	377252dbefa2af9afc5a489521c16b85	photos/290220_01.jpg	2022-03-23 05:37:42.707204+00
101	377252dbefa2af9afc5a489521c16b85	photos/290210_01.jpg	2022-03-23 05:37:57.729064+00
102	377252dbefa2af9afc5a489521c16b85	photos/330690_04.jpg	2022-03-23 05:38:34.711411+00
103	377252dbefa2af9afc5a489521c16b85	photos/330670_04.jpg	2022-03-23 05:39:16.474767+00
104	377252dbefa2af9afc5a489521c16b85	photos/330660_04.jpg	2022-03-23 05:39:55.62085+00
105	377252dbefa2af9afc5a489521c16b85	photos/300040_04.jpg	2022-03-23 05:40:28.835732+00
106	377252dbefa2af9afc5a489521c16b85	photos/344390_04.jpg	2022-03-23 05:40:48.889604+00
107	377252dbefa2af9afc5a489521c16b85	photos/344420_04.jpg	2022-03-23 05:41:17.237977+00
108	377252dbefa2af9afc5a489521c16b85	photos/361250_04.jpg	2022-03-23 05:41:29.677138+00
109	377252dbefa2af9afc5a489521c16b85	photos/330640_04.jpg	2022-03-23 05:41:41.48556+00
110	377252dbefa2af9afc5a489521c16b85	photos/321240_01.jpg	2022-03-23 05:41:56.766863+00
111	377252dbefa2af9afc5a489521c16b85	photos/387960_1.jpg	2022-03-23 05:42:12.921173+00
112	377252dbefa2af9afc5a489521c16b85	photos/387950_1.jpg	2022-03-23 05:42:31.163976+00
113	377252dbefa2af9afc5a489521c16b85	photos/353100_01.jpg	2022-03-23 05:42:50.003028+00
114	377252dbefa2af9afc5a489521c16b85	photos/387690_01.jpg	2022-03-23 05:43:05.674025+00
115	377252dbefa2af9afc5a489521c16b85	photos/353180_01.jpg	2022-03-23 05:43:17.037382+00
116	377252dbefa2af9afc5a489521c16b85	photos/353140_01.jpg	2022-03-23 05:43:28.273257+00
117	377252dbefa2af9afc5a489521c16b85	photos/353060_01.jpg	2022-03-23 05:43:43.174586+00
118	377252dbefa2af9afc5a489521c16b85	photos/353050_01.jpg	2022-03-23 05:43:57.92572+00
119	377252dbefa2af9afc5a489521c16b85	photos/353040_01.jpg	2022-03-23 05:44:07.799365+00
120	377252dbefa2af9afc5a489521c16b85	photos/353250_01.jpg	2022-03-23 05:44:22.237344+00
121	377252dbefa2af9afc5a489521c16b85	photos/353240_01.jpg	2022-03-23 05:44:35.95332+00
122	377252dbefa2af9afc5a489521c16b85	photos/353230_01.jpg	2022-03-23 05:44:49.552014+00
123	377252dbefa2af9afc5a489521c16b85	photos/353220_01.jpg	2022-03-23 05:45:02.83293+00
124	377252dbefa2af9afc5a489521c16b85	photos/353210_01.jpg	2022-03-23 05:45:17.925489+00
125	377252dbefa2af9afc5a489521c16b85	photos/364750_01.jpg	2022-03-23 05:45:30.673885+00
126	377252dbefa2af9afc5a489521c16b85	photos/364720_01.jpg	2022-03-23 05:45:46.620634+00
127	377252dbefa2af9afc5a489521c16b85	photos/364730_01.jpg	2022-03-23 05:46:00.521939+00
128	377252dbefa2af9afc5a489521c16b85	photos/364740_01.jpg	2022-03-23 05:46:10.657888+00
129	377252dbefa2af9afc5a489521c16b85	photos/395920_01.jpg	2022-03-23 05:46:27.286907+00
130	377252dbefa2af9afc5a489521c16b85	photos/395910_01.jpg	2022-03-23 05:46:47.594098+00
131	377252dbefa2af9afc5a489521c16b85	photos/271440_01.jpg	2022-03-23 05:47:06.643294+00
132	377252dbefa2af9afc5a489521c16b85	photos/343980_01.jpg	2022-03-23 05:47:28.64497+00
133	377252dbefa2af9afc5a489521c16b85	photos/368850_01.jpg	2022-03-23 05:47:43.045149+00
134	377252dbefa2af9afc5a489521c16b85	photos/361960_01.jpg	2022-03-23 05:48:00.066688+00
135	377252dbefa2af9afc5a489521c16b85	photos/368840_01.jpg	2022-03-23 05:48:18.70208+00
136	377252dbefa2af9afc5a489521c16b85	photos/395950_01.jpg	2022-03-23 05:48:29.333881+00
137	377252dbefa2af9afc5a489521c16b85	photos/395900_01.jpg	2022-03-23 05:48:41.952082+00
138	377252dbefa2af9afc5a489521c16b85	photos/395890_01.jpg	2022-03-23 05:48:57.374879+00
139	377252dbefa2af9afc5a489521c16b85	photos/395880_01.jpg	2022-03-23 05:49:10.420327+00
140	377252dbefa2af9afc5a489521c16b85	photos/388920_01.jpg	2022-03-23 05:49:22.936207+00
141	377252dbefa2af9afc5a489521c16b85	photos/388890_01.jpg	2022-03-23 05:49:41.456401+00
142	377252dbefa2af9afc5a489521c16b85	photos/308760_01.jpg	2022-03-23 05:49:58.961015+00
143	377252dbefa2af9afc5a489521c16b85	photos/339360_01.jpg	2022-03-23 05:50:22.115855+00
144	377252dbefa2af9afc5a489521c16b85	photos/381330_01.jpg	2022-03-23 05:50:38.796303+00
145	377252dbefa2af9afc5a489521c16b85	photos/383990_01.jpg	2022-03-23 05:50:56.966287+00
146	377252dbefa2af9afc5a489521c16b85	photos/386780_01.jpg	2022-03-23 05:51:13.435166+00
147	377252dbefa2af9afc5a489521c16b85	photos/350380_01.jpg	2022-03-23 05:51:30.391394+00
148	377252dbefa2af9afc5a489521c16b85	photos/348010_01.jpg	2022-03-23 05:51:53.14311+00
149	377252dbefa2af9afc5a489521c16b85	photos/348270_01.jpg	2022-03-23 05:52:10.629484+00
150	377252dbefa2af9afc5a489521c16b85	photos/348200_01.jpg	2022-03-23 05:52:21.995824+00
151	377252dbefa2af9afc5a489521c16b85	photos/348190_01.jpg	2022-03-23 05:52:35.841114+00
152	377252dbefa2af9afc5a489521c16b85	photos/348180_01.jpg	2022-03-23 05:52:54.989649+00
153	377252dbefa2af9afc5a489521c16b85	photos/348300_01.jpg	2022-03-23 05:53:07.847087+00
154	377252dbefa2af9afc5a489521c16b85	photos/348250_01.jpg	2022-03-23 05:53:21.931473+00
155	377252dbefa2af9afc5a489521c16b85	photos/467070_01.jpg	2022-03-23 05:53:32.776037+00
156	377252dbefa2af9afc5a489521c16b85	photos/350410_01.jpg	2022-03-23 05:55:09.499954+00
157	377252dbefa2af9afc5a489521c16b85	photos/351050_01.jpg	2022-03-23 05:55:25.782961+00
158	377252dbefa2af9afc5a489521c16b85	photos/348240_01.jpg	2022-03-23 05:55:41.001131+00
159	377252dbefa2af9afc5a489521c16b85	photos/386860_01.jpg	2022-03-23 06:06:44.765576+00
160	377252dbefa2af9afc5a489521c16b85	photos/383060_01.jpg	2022-03-23 06:07:05.800634+00
161	377252dbefa2af9afc5a489521c16b85	photos/309430_01.jpg	2022-03-23 06:07:24.635686+00
162	377252dbefa2af9afc5a489521c16b85	photos/302550_01.jpg	2022-03-23 06:08:03.931506+00
163	377252dbefa2af9afc5a489521c16b85	photos/387740_01.jpg	2022-03-23 06:08:23.947717+00
164	377252dbefa2af9afc5a489521c16b85	photos/385020_01.jpg	2022-03-23 06:08:44.601014+00
165	377252dbefa2af9afc5a489521c16b85	photos/348390_01.jpg	2022-03-23 06:10:17.783859+00
166	377252dbefa2af9afc5a489521c16b85	photos/350390_01.jpg	2022-03-23 06:11:09.030868+00
167	377252dbefa2af9afc5a489521c16b85	photos/313780_01.jpg	2022-03-23 06:11:34.406976+00
168	377252dbefa2af9afc5a489521c16b85	photos/313790_01.jpg	2022-03-23 06:12:16.587665+00
169	377252dbefa2af9afc5a489521c16b85	photos/335050_01.jpg	2022-03-23 06:13:51.803202+00
170	377252dbefa2af9afc5a489521c16b85	photos/337700_01.jpg	2022-03-23 06:14:08.840687+00
171	377252dbefa2af9afc5a489521c16b85	photos/410490_01.jpg	2022-03-23 06:14:51.605969+00
172	377252dbefa2af9afc5a489521c16b85	photos/410480_01.jpg	2022-03-23 06:15:07.452522+00
173	377252dbefa2af9afc5a489521c16b85	photos/337610_01.jpg	2022-03-23 06:15:22.666928+00
174	377252dbefa2af9afc5a489521c16b85	photos/271330_01.jpg	2022-03-23 06:15:38.874946+00
175	377252dbefa2af9afc5a489521c16b85	photos/271320_01.jpg	2022-03-23 06:15:59.803193+00
176	377252dbefa2af9afc5a489521c16b85	photos/271310_01.jpg	2022-03-23 06:16:23.73455+00
177	377252dbefa2af9afc5a489521c16b85	photos/271300_01.jpg	2022-03-23 06:16:51.806077+00
178	377252dbefa2af9afc5a489521c16b85	photos/270590_01.jpg	2022-03-23 06:17:07.461014+00
179	377252dbefa2af9afc5a489521c16b85	photos/335010_01.jpg	2022-03-23 06:17:21.740181+00
180	377252dbefa2af9afc5a489521c16b85	photos/340910_01.jpg	2022-03-23 06:17:34.060338+00
181	377252dbefa2af9afc5a489521c16b85	photos/337690_01.jpg	2022-03-23 06:17:50.710508+00
182	377252dbefa2af9afc5a489521c16b85	photos/335150_01.jpg	2022-03-23 06:18:14.93593+00
183	377252dbefa2af9afc5a489521c16b85	photos/335140_01.jpg	2022-03-23 06:19:11.105464+00
184	377252dbefa2af9afc5a489521c16b85	photos/335170_01.jpg	2022-03-23 06:20:29.707872+00
185	377252dbefa2af9afc5a489521c16b85	photos/335160_01.jpg	2022-03-23 06:21:29.020977+00
186	377252dbefa2af9afc5a489521c16b85	photos/271390_01_cyO9Doc.jpg	2022-03-23 06:22:02.573602+00
187	377252dbefa2af9afc5a489521c16b85	photos/337590_01.jpg	2022-03-23 06:22:45.439293+00
188	377252dbefa2af9afc5a489521c16b85	photos/334590_01.jpg	2022-03-23 06:23:46.000794+00
189	377252dbefa2af9afc5a489521c16b85	photos/394980_01.jpg	2022-03-23 06:23:57.868856+00
190	377252dbefa2af9afc5a489521c16b85	photos/394990_01.jpg	2022-03-23 06:24:24.719537+00
191	377252dbefa2af9afc5a489521c16b85	photos/334640_01.jpg	2022-03-23 06:24:36.921869+00
192	377252dbefa2af9afc5a489521c16b85	photos/340490_01.jpg	2022-03-23 06:24:53.570021+00
193	377252dbefa2af9afc5a489521c16b85	photos/340430_01_sdA7eGI.jpg	2022-03-23 06:25:05.050186+00
194	377252dbefa2af9afc5a489521c16b85	photos/340020_01.jpg	2022-03-23 06:26:06.612832+00
195	377252dbefa2af9afc5a489521c16b85	photos/334860_01.jpg	2022-03-23 06:26:21.860392+00
196	377252dbefa2af9afc5a489521c16b85	photos/340480_01.jpg	2022-03-23 06:26:43.265333+00
197	377252dbefa2af9afc5a489521c16b85	photos/305950_01.jpg	2022-03-23 06:27:06.477372+00
198	377252dbefa2af9afc5a489521c16b85	photos/334610_01.jpg	2022-03-23 06:27:30.405269+00
199	377252dbefa2af9afc5a489521c16b85	photos/334690_01.jpg	2022-03-23 06:27:46.033989+00
200	377252dbefa2af9afc5a489521c16b85	photos/334620_01.jpg	2022-03-23 06:28:11.019395+00
201	377252dbefa2af9afc5a489521c16b85	photos/334730_01.jpg	2022-03-23 06:28:26.060832+00
202	377252dbefa2af9afc5a489521c16b85	photos/334570_01.jpg	2022-03-23 06:28:45.663813+00
203	377252dbefa2af9afc5a489521c16b85	photos/334510_01.jpg	2022-03-23 06:28:57.523608+00
204	377252dbefa2af9afc5a489521c16b85	photos/334870_01.jpg	2022-03-23 06:29:12.417627+00
205	377252dbefa2af9afc5a489521c16b85	photos/305760_01.jpg	2022-03-23 06:29:25.403378+00
206	377252dbefa2af9afc5a489521c16b85	photos/305630_01.jpg	2022-03-23 06:29:37.883221+00
207	377252dbefa2af9afc5a489521c16b85	photos/395080_01.jpg	2022-03-23 06:29:48.835239+00
208	377252dbefa2af9afc5a489521c16b85	photos/381680_01.jpg	2022-03-23 06:30:01.583435+00
209	377252dbefa2af9afc5a489521c16b85	photos/394810_01.jpg	2022-03-23 06:30:18.819019+00
210	377252dbefa2af9afc5a489521c16b85	photos/395320_01.jpg	2022-03-23 06:30:30.400976+00
211	377252dbefa2af9afc5a489521c16b85	photos/332440_01.jpg	2022-03-23 06:30:47.71087+00
212	377252dbefa2af9afc5a489521c16b85	photos/271380_01.jpg	2022-03-23 06:31:38.171831+00
213	377252dbefa2af9afc5a489521c16b85	photos/heros/kitchen.jpg	2022-03-23 08:50:08.488278+00
214	377252dbefa2af9afc5a489521c16b85	photos/heros/karaage.jpg	2022-03-23 08:50:24.735942+00
215	377252dbefa2af9afc5a489521c16b85	photos/heros/kona.jpg	2022-03-23 08:50:36.895089+00
216	377252dbefa2af9afc5a489521c16b85	photos/heros/okonomiyaki.jpg	2022-03-23 08:51:16.583154+00
217	377252dbefa2af9afc5a489521c16b85	photos/heros/yofu.jpg	2022-03-23 08:51:29.796984+00
218	377252dbefa2af9afc5a489521c16b85	photos/heros/longpasta.jpg	2022-03-23 08:51:47.650475+00
219	377252dbefa2af9afc5a489521c16b85	photos/heros/shortpasta.jpg	2022-03-23 08:52:00.002936+00
220	377252dbefa2af9afc5a489521c16b85	photos/heros/souzai.jpg	2022-03-23 08:52:24.423966+00
221	377252dbefa2af9afc5a489521c16b85	photos/heros/kitchen_kxoB7Qb.jpg	2022-03-23 08:52:39.994749+00
222	377252dbefa2af9afc5a489521c16b85	photos/heros/longpasta_paMuhtx.jpg	2022-03-23 08:54:38.868996+00
\.


--
-- Data for Name: easy_thumbnails_thumbnail; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.easy_thumbnails_thumbnail (id, storage_hash, name, modified, source_id) FROM stdin;
1	d26becbf46ac48eda79c7a39a13a02dd	photos/天ふら粉アイコン.jpg.412x412_q85_crop.jpg	2022-03-21 13:07:01.927233+00	2
2	d26becbf46ac48eda79c7a39a13a02dd	photos/912.jpg.412x412_q85_crop.jpg	2022-03-21 13:12:17.205706+00	4
3	d26becbf46ac48eda79c7a39a13a02dd	photos/AdobeStock_246860321.jpeg.412x412_q85_crop.jpg	2022-03-21 13:12:17.513441+00	6
4	d26becbf46ac48eda79c7a39a13a02dd	photos/ヘンネリカーテ.jpg.412x412_q85_crop.jpg	2022-03-21 13:12:17.826259+00	7
5	d26becbf46ac48eda79c7a39a13a02dd	photos/トラティショナルソースシスル.jpg.412x412_q85_crop.jpg	2022-03-21 13:12:18.378898+00	5
6	d26becbf46ac48eda79c7a39a13a02dd	photos/から揚け調理画像①_AbJIrkk.jpg.412x412_q85_crop.jpg	2022-03-21 13:12:38.413582+00	8
7	d26becbf46ac48eda79c7a39a13a02dd	photos/本体-左_777改.jpg.412x412_q85_crop.jpg	2022-03-21 13:13:22.58768+00	9
8	d26becbf46ac48eda79c7a39a13a02dd	photos/AI_画像.jpg.412x412_q85_crop.jpg	2022-03-21 13:17:42.565884+00	10
9	d26becbf46ac48eda79c7a39a13a02dd	photos/AI_画像_qrRT6tk.jpg.412x412_q85_crop.jpg	2022-03-21 13:18:58.075928+00	11
10	d26becbf46ac48eda79c7a39a13a02dd	photos/p2_2_30.jpg.412x412_q85_crop.jpg	2022-03-21 13:19:35.283618+00	12
11	d26becbf46ac48eda79c7a39a13a02dd	photos/からあけ.jpg.412x412_q85_crop.jpg	2022-03-21 13:21:03.715638+00	13
12	d26becbf46ac48eda79c7a39a13a02dd	photos/洋風.jpg.412x412_q85_crop.jpg	2022-03-21 13:22:28.279334+00	14
13	d26becbf46ac48eda79c7a39a13a02dd	photos/その他.jpg.412x412_q85_crop.jpg	2022-03-21 13:29:27.881936+00	15
14	d26becbf46ac48eda79c7a39a13a02dd	photos/ショートハスタ.jpg.412x412_q85_crop.jpg	2022-03-21 13:34:09.15224+00	16
15	d26becbf46ac48eda79c7a39a13a02dd	photos/天ふら粉アイコン.jpg.500x320_q85_crop.jpg	2022-03-21 13:37:09.930031+00	2
16	d26becbf46ac48eda79c7a39a13a02dd	photos/からあけ.jpg.500x320_q85_crop.jpg	2022-03-21 13:37:10.900375+00	13
17	d26becbf46ac48eda79c7a39a13a02dd	photos/AI_画像_qrRT6tk.jpg.500x320_q85_crop.jpg	2022-03-21 13:37:11.228088+00	11
18	d26becbf46ac48eda79c7a39a13a02dd	photos/912.jpg.500x320_q85_crop.jpg	2022-03-21 13:37:11.582108+00	4
19	d26becbf46ac48eda79c7a39a13a02dd	photos/洋風.jpg.500x320_q85_crop.jpg	2022-03-21 13:37:12.033507+00	14
20	d26becbf46ac48eda79c7a39a13a02dd	photos/AdobeStock_246860321.jpeg.500x320_q85_crop.jpg	2022-03-21 13:37:12.388457+00	6
21	d26becbf46ac48eda79c7a39a13a02dd	photos/ショートハスタ.jpg.500x320_q85_crop.jpg	2022-03-21 13:37:12.599717+00	16
22	d26becbf46ac48eda79c7a39a13a02dd	photos/p2_2_30.jpg.500x320_q85_crop.jpg	2022-03-21 13:37:12.835459+00	12
23	d26becbf46ac48eda79c7a39a13a02dd	photos/トラティショナルソースシスル.jpg.500x320_q85_crop.jpg	2022-03-21 13:37:13.495723+00	5
24	d26becbf46ac48eda79c7a39a13a02dd	photos/その他.jpg.500x320_q85_crop.jpg	2022-03-21 13:37:13.643237+00	15
25	d26becbf46ac48eda79c7a39a13a02dd	photos/天ふら粉アイコン.jpg.128x128_q85_crop.jpg	2022-03-21 13:39:19.211043+00	2
26	d26becbf46ac48eda79c7a39a13a02dd	photos/からあけ.jpg.128x128_q85_crop.jpg	2022-03-21 13:39:20.462559+00	13
27	d26becbf46ac48eda79c7a39a13a02dd	photos/AI_画像_qrRT6tk.jpg.128x128_q85_crop.jpg	2022-03-21 13:39:21.194034+00	11
28	d26becbf46ac48eda79c7a39a13a02dd	photos/912.jpg.128x128_q85_crop.jpg	2022-03-21 13:39:21.831208+00	4
29	d26becbf46ac48eda79c7a39a13a02dd	photos/洋風.jpg.128x128_q85_crop.jpg	2022-03-21 13:39:22.752136+00	14
30	d26becbf46ac48eda79c7a39a13a02dd	photos/AdobeStock_246860321.jpeg.128x128_q85_crop.jpg	2022-03-21 13:39:23.314289+00	6
31	d26becbf46ac48eda79c7a39a13a02dd	photos/ショートハスタ.jpg.128x128_q85_crop.jpg	2022-03-21 13:39:23.650472+00	16
32	d26becbf46ac48eda79c7a39a13a02dd	photos/p2_2_30.jpg.128x128_q85_crop.jpg	2022-03-21 13:39:24.112704+00	12
33	d26becbf46ac48eda79c7a39a13a02dd	photos/トラティショナルソースシスル.jpg.128x128_q85_crop.jpg	2022-03-21 13:39:25.572232+00	5
34	d26becbf46ac48eda79c7a39a13a02dd	photos/その他.jpg.128x128_q85_crop.jpg	2022-03-21 13:39:25.875055+00	15
35	d26becbf46ac48eda79c7a39a13a02dd	photos/271390_01.jpg.412x412_q85_crop.jpg	2022-03-22 06:25:16.93464+00	17
36	d26becbf46ac48eda79c7a39a13a02dd	photos/340430_01.jpg.412x412_q85_crop.jpg	2022-03-22 06:25:17.310651+00	18
37	d26becbf46ac48eda79c7a39a13a02dd	photos/271390_01_6YOGbsw.jpg.412x412_q85_crop.jpg	2022-03-22 06:25:17.918925+00	19
38	d26becbf46ac48eda79c7a39a13a02dd	photos/340430_01_15in85P.jpg.412x412_q85_crop.jpg	2022-03-22 06:25:18.25985+00	20
43	d26becbf46ac48eda79c7a39a13a02dd	photos/洋風.jpg.412x412_q85_crop.jpg	2022-03-23 06:03:04.393353+00	25
44	d26becbf46ac48eda79c7a39a13a02dd	photos/AdobeStock_246860321.jpeg.412x412_q85_crop.jpg	2022-03-23 06:03:04.959989+00	26
45	d26becbf46ac48eda79c7a39a13a02dd	photos/ショートハスタ.jpg.412x412_q85_crop.jpg	2022-03-23 06:03:05.271742+00	27
46	d26becbf46ac48eda79c7a39a13a02dd	photos/p2_2_30.jpg.412x412_q85_crop.jpg	2022-03-23 06:03:05.585587+00	28
47	d26becbf46ac48eda79c7a39a13a02dd	photos/トラティショナルソースシスル.jpg.412x412_q85_crop.jpg	2022-03-23 06:03:06.594917+00	29
51	d26becbf46ac48eda79c7a39a13a02dd	photos/AI_画像_qrRT6tk.jpg.500x320_q85_crop.jpg	2022-03-23 03:17:52.582589+00	23
52	d26becbf46ac48eda79c7a39a13a02dd	photos/912.jpg.500x320_q85_crop.jpg	2022-03-23 03:17:52.747544+00	24
53	d26becbf46ac48eda79c7a39a13a02dd	photos/洋風.jpg.500x320_q85_crop.jpg	2022-03-23 03:17:53.159181+00	25
54	d26becbf46ac48eda79c7a39a13a02dd	photos/AdobeStock_246860321.jpeg.500x320_q85_crop.jpg	2022-03-23 03:17:53.668157+00	26
55	d26becbf46ac48eda79c7a39a13a02dd	photos/ショートハスタ.jpg.500x320_q85_crop.jpg	2022-03-23 03:17:53.924874+00	27
48	d26becbf46ac48eda79c7a39a13a02dd	photos/その他.jpg.412x412_q85_crop.jpg	2022-03-23 06:03:06.818173+00	30
60	d26becbf46ac48eda79c7a39a13a02dd	photos/からあけ.jpg.128x128_q85_crop.jpg	2022-03-23 06:53:43.888925+00	22
40	d26becbf46ac48eda79c7a39a13a02dd	photos/からあけ.jpg.412x412_q85_crop.jpg	2022-03-23 06:03:03.665778+00	22
41	d26becbf46ac48eda79c7a39a13a02dd	photos/AI_画像_qrRT6tk.jpg.412x412_q85_crop.jpg	2022-03-23 06:03:03.748047+00	23
42	d26becbf46ac48eda79c7a39a13a02dd	photos/912.jpg.412x412_q85_crop.jpg	2022-03-23 06:03:03.956313+00	24
49	d26becbf46ac48eda79c7a39a13a02dd	photos/天ふら粉アイコン.jpg.500x320_q85_crop.jpg	2022-03-23 03:17:52.162056+00	21
50	d26becbf46ac48eda79c7a39a13a02dd	photos/からあけ.jpg.500x320_q85_crop.jpg	2022-03-23 03:17:52.501186+00	22
56	d26becbf46ac48eda79c7a39a13a02dd	photos/p2_2_30.jpg.500x320_q85_crop.jpg	2022-03-23 03:17:54.200516+00	28
57	d26becbf46ac48eda79c7a39a13a02dd	photos/トラティショナルソースシスル.jpg.500x320_q85_crop.jpg	2022-03-23 03:17:55.019064+00	29
58	d26becbf46ac48eda79c7a39a13a02dd	photos/その他.jpg.500x320_q85_crop.jpg	2022-03-23 03:17:55.432192+00	30
59	d26becbf46ac48eda79c7a39a13a02dd	photos/天ふら粉アイコン.jpg.128x128_q85_crop.jpg	2022-03-23 06:53:43.541675+00	21
101	d26becbf46ac48eda79c7a39a13a02dd	photos/368540_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:39.959142+00	61
102	d26becbf46ac48eda79c7a39a13a02dd	photos/368790_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:40.063951+00	60
103	d26becbf46ac48eda79c7a39a13a02dd	photos/368580_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:40.275105+00	59
104	d26becbf46ac48eda79c7a39a13a02dd	photos/368590_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:40.424706+00	58
105	d26becbf46ac48eda79c7a39a13a02dd	photos/368620_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:40.628809+00	57
106	d26becbf46ac48eda79c7a39a13a02dd	photos/350850_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:40.776225+00	56
107	d26becbf46ac48eda79c7a39a13a02dd	photos/363200_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:40.937036+00	55
39	d26becbf46ac48eda79c7a39a13a02dd	photos/天ふら粉アイコン.jpg.412x412_q85_crop.jpg	2022-03-23 06:03:03.288863+00	21
62	d26becbf46ac48eda79c7a39a13a02dd	photos/912.jpg.128x128_q85_crop.jpg	2022-03-23 06:53:44.151023+00	24
63	d26becbf46ac48eda79c7a39a13a02dd	photos/洋風.jpg.128x128_q85_crop.jpg	2022-03-23 06:53:44.567814+00	25
64	d26becbf46ac48eda79c7a39a13a02dd	photos/AdobeStock_246860321.jpeg.128x128_q85_crop.jpg	2022-03-23 06:53:45.090099+00	26
65	d26becbf46ac48eda79c7a39a13a02dd	photos/ショートハスタ.jpg.128x128_q85_crop.jpg	2022-03-23 06:53:45.369741+00	27
66	d26becbf46ac48eda79c7a39a13a02dd	photos/p2_2_30.jpg.128x128_q85_crop.jpg	2022-03-23 06:53:45.646191+00	28
67	d26becbf46ac48eda79c7a39a13a02dd	photos/トラティショナルソースシスル.jpg.128x128_q85_crop.jpg	2022-03-23 06:53:46.680335+00	29
68	d26becbf46ac48eda79c7a39a13a02dd	photos/その他.jpg.128x128_q85_crop.jpg	2022-03-23 06:53:46.8915+00	30
69	d26becbf46ac48eda79c7a39a13a02dd	photos/337590_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:58:00.123998+00	187
70	d26becbf46ac48eda79c7a39a13a02dd	photos/395880_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:34.987124+00	139
71	d26becbf46ac48eda79c7a39a13a02dd	photos/395890_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:35.285545+00	138
72	d26becbf46ac48eda79c7a39a13a02dd	photos/395900_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:35.446255+00	137
73	d26becbf46ac48eda79c7a39a13a02dd	photos/395950_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:35.596464+00	136
74	d26becbf46ac48eda79c7a39a13a02dd	photos/368840_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:35.74592+00	135
75	d26becbf46ac48eda79c7a39a13a02dd	photos/361960_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:35.891887+00	134
76	d26becbf46ac48eda79c7a39a13a02dd	photos/368850_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:36.028115+00	133
77	d26becbf46ac48eda79c7a39a13a02dd	photos/343980_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:36.197567+00	132
78	d26becbf46ac48eda79c7a39a13a02dd	photos/271440_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:36.419417+00	131
79	d26becbf46ac48eda79c7a39a13a02dd	photos/395910_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:36.567211+00	130
80	d26becbf46ac48eda79c7a39a13a02dd	photos/395920_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:36.716184+00	129
81	d26becbf46ac48eda79c7a39a13a02dd	photos/364740_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:36.867596+00	128
82	d26becbf46ac48eda79c7a39a13a02dd	photos/364730_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:37.023214+00	127
83	d26becbf46ac48eda79c7a39a13a02dd	photos/364720_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:37.204467+00	126
84	d26becbf46ac48eda79c7a39a13a02dd	photos/364750_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:37.354451+00	125
85	d26becbf46ac48eda79c7a39a13a02dd	photos/353210_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:37.56768+00	124
86	d26becbf46ac48eda79c7a39a13a02dd	photos/353220_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:37.715992+00	123
87	d26becbf46ac48eda79c7a39a13a02dd	photos/353230_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:37.859561+00	122
88	d26becbf46ac48eda79c7a39a13a02dd	photos/353240_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:37.994588+00	121
89	d26becbf46ac48eda79c7a39a13a02dd	photos/353250_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:38.148031+00	120
90	d26becbf46ac48eda79c7a39a13a02dd	photos/353040_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:38.295223+00	119
91	d26becbf46ac48eda79c7a39a13a02dd	photos/353050_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:38.450047+00	118
92	d26becbf46ac48eda79c7a39a13a02dd	photos/353060_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:38.599458+00	117
93	d26becbf46ac48eda79c7a39a13a02dd	photos/353140_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:38.740857+00	116
94	d26becbf46ac48eda79c7a39a13a02dd	photos/353180_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:38.880233+00	115
95	d26becbf46ac48eda79c7a39a13a02dd	photos/387690_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:39.042569+00	114
96	d26becbf46ac48eda79c7a39a13a02dd	photos/353100_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:39.201901+00	113
97	d26becbf46ac48eda79c7a39a13a02dd	photos/387950_1.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:39.349921+00	112
98	d26becbf46ac48eda79c7a39a13a02dd	photos/387960_1.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:39.48695+00	111
99	d26becbf46ac48eda79c7a39a13a02dd	photos/321240_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:39.638596+00	110
100	d26becbf46ac48eda79c7a39a13a02dd	photos/362990_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:39.799503+00	62
108	d26becbf46ac48eda79c7a39a13a02dd	photos/363210_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:41.088053+00	54
109	d26becbf46ac48eda79c7a39a13a02dd	photos/363220_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:41.272098+00	53
110	d26becbf46ac48eda79c7a39a13a02dd	photos/363410_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:41.426406+00	52
111	d26becbf46ac48eda79c7a39a13a02dd	photos/363420_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:41.569428+00	51
112	d26becbf46ac48eda79c7a39a13a02dd	photos/363460_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:41.722104+00	50
113	d26becbf46ac48eda79c7a39a13a02dd	photos/363280_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:41.867052+00	40
114	d26becbf46ac48eda79c7a39a13a02dd	photos/362510_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:42.033574+00	39
115	d26becbf46ac48eda79c7a39a13a02dd	photos/368800_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:42.19016+00	38
116	d26becbf46ac48eda79c7a39a13a02dd	photos/368810_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:42.337921+00	37
117	d26becbf46ac48eda79c7a39a13a02dd	photos/321120_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:53:42.509472+00	34
61	d26becbf46ac48eda79c7a39a13a02dd	photos/AI_画像_qrRT6tk.jpg.128x128_q85_crop.jpg	2022-03-23 06:53:43.962203+00	23
118	d26becbf46ac48eda79c7a39a13a02dd	photos/335160_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:58:00.279095+00	185
119	d26becbf46ac48eda79c7a39a13a02dd	photos/335170_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:58:00.448845+00	184
120	d26becbf46ac48eda79c7a39a13a02dd	photos/335140_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:58:00.605348+00	183
121	d26becbf46ac48eda79c7a39a13a02dd	photos/335150_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:58:00.749324+00	182
122	d26becbf46ac48eda79c7a39a13a02dd	photos/337690_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:58:00.888601+00	181
123	d26becbf46ac48eda79c7a39a13a02dd	photos/340910_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:58:01.056008+00	180
124	d26becbf46ac48eda79c7a39a13a02dd	photos/335010_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:58:01.214261+00	179
125	d26becbf46ac48eda79c7a39a13a02dd	photos/270590_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:58:01.3572+00	178
126	d26becbf46ac48eda79c7a39a13a02dd	photos/271300_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:58:01.503864+00	177
127	d26becbf46ac48eda79c7a39a13a02dd	photos/271310_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:58:01.695922+00	176
128	d26becbf46ac48eda79c7a39a13a02dd	photos/271320_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:58:01.850214+00	175
129	d26becbf46ac48eda79c7a39a13a02dd	photos/271330_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:58:01.99328+00	174
130	d26becbf46ac48eda79c7a39a13a02dd	photos/337610_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:58:09.158493+00	173
131	d26becbf46ac48eda79c7a39a13a02dd	photos/410480_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:58:09.316788+00	172
132	d26becbf46ac48eda79c7a39a13a02dd	photos/410490_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:58:09.456823+00	171
133	d26becbf46ac48eda79c7a39a13a02dd	photos/337700_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:58:09.660048+00	170
134	d26becbf46ac48eda79c7a39a13a02dd	photos/335050_01.jpg.412x412_q85_crop.jpg	2022-03-23 06:58:09.809944+00	169
135	377252dbefa2af9afc5a489521c16b85	photos/337610_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:09:40.785556+00	173
136	377252dbefa2af9afc5a489521c16b85	photos/410480_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:09:41.125453+00	172
137	377252dbefa2af9afc5a489521c16b85	photos/410490_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:09:41.357726+00	171
138	377252dbefa2af9afc5a489521c16b85	photos/337700_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:09:41.622346+00	170
139	377252dbefa2af9afc5a489521c16b85	photos/335050_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:09:41.897512+00	169
140	377252dbefa2af9afc5a489521c16b85	photos/天ふら粉アイコン.jpg.128x128_q85_crop.jpg	2022-03-23 07:09:43.000725+00	21
141	377252dbefa2af9afc5a489521c16b85	photos/からあけ.jpg.128x128_q85_crop.jpg	2022-03-23 07:09:43.449072+00	22
142	377252dbefa2af9afc5a489521c16b85	photos/AI_画像_qrRT6tk.jpg.128x128_q85_crop.jpg	2022-03-23 07:09:43.61446+00	23
143	377252dbefa2af9afc5a489521c16b85	photos/912.jpg.128x128_q85_crop.jpg	2022-03-23 07:09:43.893193+00	24
144	377252dbefa2af9afc5a489521c16b85	photos/洋風.jpg.128x128_q85_crop.jpg	2022-03-23 07:09:44.435595+00	25
145	377252dbefa2af9afc5a489521c16b85	photos/AdobeStock_246860321.jpeg.128x128_q85_crop.jpg	2022-03-23 07:09:45.067547+00	26
146	377252dbefa2af9afc5a489521c16b85	photos/ショートハスタ.jpg.128x128_q85_crop.jpg	2022-03-23 07:09:45.415964+00	27
147	377252dbefa2af9afc5a489521c16b85	photos/p2_2_30.jpg.128x128_q85_crop.jpg	2022-03-23 07:09:45.887984+00	28
148	377252dbefa2af9afc5a489521c16b85	photos/トラティショナルソースシスル.jpg.128x128_q85_crop.jpg	2022-03-23 07:09:46.874451+00	29
149	377252dbefa2af9afc5a489521c16b85	photos/その他.jpg.128x128_q85_crop.jpg	2022-03-23 07:09:47.179099+00	30
150	377252dbefa2af9afc5a489521c16b85	photos/337590_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:09:55.008604+00	187
151	377252dbefa2af9afc5a489521c16b85	photos/335160_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:09:55.2304+00	185
152	377252dbefa2af9afc5a489521c16b85	photos/335170_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:09:55.477911+00	184
153	377252dbefa2af9afc5a489521c16b85	photos/335140_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:09:55.723413+00	183
154	377252dbefa2af9afc5a489521c16b85	photos/335150_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:09:55.959433+00	182
155	377252dbefa2af9afc5a489521c16b85	photos/337690_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:09:56.197729+00	181
156	377252dbefa2af9afc5a489521c16b85	photos/340910_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:09:56.469727+00	180
157	377252dbefa2af9afc5a489521c16b85	photos/335010_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:09:56.701464+00	179
158	377252dbefa2af9afc5a489521c16b85	photos/270590_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:09:56.963912+00	178
159	377252dbefa2af9afc5a489521c16b85	photos/271300_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:09:57.202839+00	177
160	377252dbefa2af9afc5a489521c16b85	photos/271310_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:09:57.450131+00	176
161	377252dbefa2af9afc5a489521c16b85	photos/271320_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:09:57.680766+00	175
162	377252dbefa2af9afc5a489521c16b85	photos/271330_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:09:57.933538+00	174
163	377252dbefa2af9afc5a489521c16b85	photos/313790_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:26.752287+00	168
164	377252dbefa2af9afc5a489521c16b85	photos/313780_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:27.058744+00	167
165	377252dbefa2af9afc5a489521c16b85	photos/350390_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:27.298345+00	166
166	377252dbefa2af9afc5a489521c16b85	photos/348390_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:27.569322+00	165
167	377252dbefa2af9afc5a489521c16b85	photos/385020_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:27.856061+00	164
168	377252dbefa2af9afc5a489521c16b85	photos/387740_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:28.092928+00	163
169	377252dbefa2af9afc5a489521c16b85	photos/302550_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:28.365937+00	162
170	377252dbefa2af9afc5a489521c16b85	photos/309430_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:28.702038+00	161
171	377252dbefa2af9afc5a489521c16b85	photos/383060_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:28.974006+00	160
172	377252dbefa2af9afc5a489521c16b85	photos/386860_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:29.214115+00	159
173	377252dbefa2af9afc5a489521c16b85	photos/395880_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:31.975209+00	139
174	377252dbefa2af9afc5a489521c16b85	photos/395890_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:32.252136+00	138
175	377252dbefa2af9afc5a489521c16b85	photos/395900_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:32.552552+00	137
176	377252dbefa2af9afc5a489521c16b85	photos/395950_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:32.888912+00	136
177	377252dbefa2af9afc5a489521c16b85	photos/368840_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:33.148285+00	135
178	377252dbefa2af9afc5a489521c16b85	photos/361960_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:33.382293+00	134
179	377252dbefa2af9afc5a489521c16b85	photos/368850_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:33.639536+00	133
180	377252dbefa2af9afc5a489521c16b85	photos/343980_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:33.891913+00	132
181	377252dbefa2af9afc5a489521c16b85	photos/271440_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:34.185051+00	131
182	377252dbefa2af9afc5a489521c16b85	photos/395910_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:34.433436+00	130
183	377252dbefa2af9afc5a489521c16b85	photos/395920_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:34.691318+00	129
184	377252dbefa2af9afc5a489521c16b85	photos/364740_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:35.029667+00	128
185	377252dbefa2af9afc5a489521c16b85	photos/364730_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:35.34464+00	127
186	377252dbefa2af9afc5a489521c16b85	photos/364720_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:35.59303+00	126
187	377252dbefa2af9afc5a489521c16b85	photos/364750_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:35.848186+00	125
188	377252dbefa2af9afc5a489521c16b85	photos/353210_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:36.101045+00	124
189	377252dbefa2af9afc5a489521c16b85	photos/353220_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:36.347318+00	123
190	377252dbefa2af9afc5a489521c16b85	photos/353230_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:36.592088+00	122
191	377252dbefa2af9afc5a489521c16b85	photos/353240_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:36.824942+00	121
192	377252dbefa2af9afc5a489521c16b85	photos/353250_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:37.084605+00	120
193	377252dbefa2af9afc5a489521c16b85	photos/353040_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:37.345568+00	119
194	377252dbefa2af9afc5a489521c16b85	photos/353050_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:37.600661+00	118
195	377252dbefa2af9afc5a489521c16b85	photos/353060_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:37.876156+00	117
196	377252dbefa2af9afc5a489521c16b85	photos/353140_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:38.152361+00	116
197	377252dbefa2af9afc5a489521c16b85	photos/353180_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:38.404374+00	115
198	377252dbefa2af9afc5a489521c16b85	photos/387690_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:38.646986+00	114
199	377252dbefa2af9afc5a489521c16b85	photos/353100_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:38.904972+00	113
200	377252dbefa2af9afc5a489521c16b85	photos/387950_1.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:39.19979+00	112
201	377252dbefa2af9afc5a489521c16b85	photos/387960_1.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:39.450791+00	111
202	377252dbefa2af9afc5a489521c16b85	photos/321240_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:39.694288+00	110
203	377252dbefa2af9afc5a489521c16b85	photos/362990_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:40.080468+00	62
204	377252dbefa2af9afc5a489521c16b85	photos/368540_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:40.349821+00	61
205	377252dbefa2af9afc5a489521c16b85	photos/368790_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:40.558211+00	60
206	377252dbefa2af9afc5a489521c16b85	photos/368580_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:40.88965+00	59
207	377252dbefa2af9afc5a489521c16b85	photos/368590_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:41.126617+00	58
208	377252dbefa2af9afc5a489521c16b85	photos/368620_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:41.362043+00	57
209	377252dbefa2af9afc5a489521c16b85	photos/350850_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:41.611638+00	56
210	377252dbefa2af9afc5a489521c16b85	photos/363200_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:41.903381+00	55
211	377252dbefa2af9afc5a489521c16b85	photos/363210_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:42.161812+00	54
212	377252dbefa2af9afc5a489521c16b85	photos/363220_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:42.41209+00	53
213	377252dbefa2af9afc5a489521c16b85	photos/363410_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:42.665662+00	52
214	377252dbefa2af9afc5a489521c16b85	photos/363420_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:42.909421+00	51
215	377252dbefa2af9afc5a489521c16b85	photos/363460_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:43.167807+00	50
216	377252dbefa2af9afc5a489521c16b85	photos/363280_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:43.436168+00	40
217	377252dbefa2af9afc5a489521c16b85	photos/362510_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:43.738084+00	39
218	377252dbefa2af9afc5a489521c16b85	photos/368800_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:43.98779+00	38
219	377252dbefa2af9afc5a489521c16b85	photos/368810_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:44.231365+00	37
220	377252dbefa2af9afc5a489521c16b85	photos/321120_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:44.477923+00	34
254	377252dbefa2af9afc5a489521c16b85	photos/332440_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:08.368054+00	211
255	377252dbefa2af9afc5a489521c16b85	photos/395320_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:08.658467+00	210
256	377252dbefa2af9afc5a489521c16b85	photos/394810_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:08.942055+00	209
257	377252dbefa2af9afc5a489521c16b85	photos/381680_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:09.198345+00	208
258	377252dbefa2af9afc5a489521c16b85	photos/395080_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:09.468713+00	207
259	377252dbefa2af9afc5a489521c16b85	photos/305630_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:09.71754+00	206
260	377252dbefa2af9afc5a489521c16b85	photos/305760_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:10.003233+00	205
261	377252dbefa2af9afc5a489521c16b85	photos/334870_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:10.277149+00	204
262	377252dbefa2af9afc5a489521c16b85	photos/334510_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:10.537124+00	203
263	377252dbefa2af9afc5a489521c16b85	photos/334570_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:10.85002+00	202
264	377252dbefa2af9afc5a489521c16b85	photos/334730_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:11.112735+00	201
265	377252dbefa2af9afc5a489521c16b85	photos/334620_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:11.385496+00	200
266	377252dbefa2af9afc5a489521c16b85	photos/334690_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:11.649445+00	199
267	377252dbefa2af9afc5a489521c16b85	photos/334610_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:11.921406+00	198
268	377252dbefa2af9afc5a489521c16b85	photos/305950_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:12.220534+00	197
269	377252dbefa2af9afc5a489521c16b85	photos/340480_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:12.494139+00	196
270	377252dbefa2af9afc5a489521c16b85	photos/334860_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:12.742512+00	195
271	377252dbefa2af9afc5a489521c16b85	photos/340020_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:13.034426+00	194
272	377252dbefa2af9afc5a489521c16b85	photos/340430_01_sdA7eGI.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:13.306254+00	193
273	377252dbefa2af9afc5a489521c16b85	photos/340490_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:13.551172+00	192
221	377252dbefa2af9afc5a489521c16b85	photos/321400_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:49.57503+00	93
222	377252dbefa2af9afc5a489521c16b85	photos/321390_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:49.826403+00	92
223	377252dbefa2af9afc5a489521c16b85	photos/387710_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:50.10894+00	91
224	377252dbefa2af9afc5a489521c16b85	photos/321420_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:50.352523+00	90
225	377252dbefa2af9afc5a489521c16b85	photos/382390_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:50.627449+00	89
226	377252dbefa2af9afc5a489521c16b85	photos/333740_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:50.89526+00	88
227	377252dbefa2af9afc5a489521c16b85	photos/333750_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:51.130537+00	87
228	377252dbefa2af9afc5a489521c16b85	photos/333770_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:51.354693+00	86
229	377252dbefa2af9afc5a489521c16b85	photos/333780_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:51.615526+00	85
230	377252dbefa2af9afc5a489521c16b85	photos/290110_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:51.876222+00	84
231	377252dbefa2af9afc5a489521c16b85	photos/290170_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:52.090252+00	83
232	377252dbefa2af9afc5a489521c16b85	photos/290190_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:52.352207+00	82
233	377252dbefa2af9afc5a489521c16b85	photos/290460_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:52.632307+00	81
234	377252dbefa2af9afc5a489521c16b85	photos/290470_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:52.923887+00	80
235	377252dbefa2af9afc5a489521c16b85	photos/290480_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:53.161615+00	79
236	377252dbefa2af9afc5a489521c16b85	photos/388930_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:53.42255+00	78
237	377252dbefa2af9afc5a489521c16b85	photos/331750_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:56.852495+00	77
238	377252dbefa2af9afc5a489521c16b85	photos/375600_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:57.124698+00	76
239	377252dbefa2af9afc5a489521c16b85	photos/395680_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:57.408307+00	75
240	377252dbefa2af9afc5a489521c16b85	photos/395560_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:57.729999+00	74
241	377252dbefa2af9afc5a489521c16b85	photos/395600_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:58.023852+00	73
242	377252dbefa2af9afc5a489521c16b85	photos/386590_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:58.262495+00	72
243	377252dbefa2af9afc5a489521c16b85	photos/378750_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:58.530071+00	71
244	377252dbefa2af9afc5a489521c16b85	photos/386610_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:58.806364+00	70
245	377252dbefa2af9afc5a489521c16b85	photos/386580_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:59.072577+00	69
246	377252dbefa2af9afc5a489521c16b85	photos/386600_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:59.294+00	68
247	377252dbefa2af9afc5a489521c16b85	photos/385730_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:59.495969+00	67
248	377252dbefa2af9afc5a489521c16b85	photos/327820_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:10:59.771063+00	66
249	377252dbefa2af9afc5a489521c16b85	photos/327750_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:00.013603+00	65
250	377252dbefa2af9afc5a489521c16b85	photos/333680_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:00.262768+00	64
251	377252dbefa2af9afc5a489521c16b85	photos/333690_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:00.543326+00	63
252	377252dbefa2af9afc5a489521c16b85	photos/309310_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:05.150125+00	33
253	377252dbefa2af9afc5a489521c16b85	photos/309490_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:05.381128+00	32
274	377252dbefa2af9afc5a489521c16b85	photos/334640_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:13.839604+00	191
275	377252dbefa2af9afc5a489521c16b85	photos/394990_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:14.074111+00	190
276	377252dbefa2af9afc5a489521c16b85	photos/394980_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:14.433239+00	189
277	377252dbefa2af9afc5a489521c16b85	photos/334590_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:14.662919+00	188
278	377252dbefa2af9afc5a489521c16b85	photos/271390_01_cyO9Doc.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:14.871998+00	186
279	377252dbefa2af9afc5a489521c16b85	photos/271380_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:15.132459+00	212
280	377252dbefa2af9afc5a489521c16b85	photos/351050_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:33.149666+00	157
281	377252dbefa2af9afc5a489521c16b85	photos/348240_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:33.457214+00	158
282	377252dbefa2af9afc5a489521c16b85	photos/350410_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:33.754168+00	156
283	377252dbefa2af9afc5a489521c16b85	photos/348250_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:34.00759+00	154
284	377252dbefa2af9afc5a489521c16b85	photos/348300_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:34.29091+00	153
285	377252dbefa2af9afc5a489521c16b85	photos/348180_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:34.515683+00	152
286	377252dbefa2af9afc5a489521c16b85	photos/348190_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:34.837013+00	151
287	377252dbefa2af9afc5a489521c16b85	photos/348200_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:35.124921+00	150
288	377252dbefa2af9afc5a489521c16b85	photos/348270_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:35.396665+00	149
289	377252dbefa2af9afc5a489521c16b85	photos/348010_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:35.684081+00	148
290	377252dbefa2af9afc5a489521c16b85	photos/350380_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:35.950151+00	147
291	377252dbefa2af9afc5a489521c16b85	photos/386780_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:36.184954+00	146
292	377252dbefa2af9afc5a489521c16b85	photos/383990_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:36.433109+00	145
293	377252dbefa2af9afc5a489521c16b85	photos/381330_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:36.684936+00	144
294	377252dbefa2af9afc5a489521c16b85	photos/339360_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:36.964559+00	143
295	377252dbefa2af9afc5a489521c16b85	photos/308760_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:37.252248+00	142
296	377252dbefa2af9afc5a489521c16b85	photos/388890_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:37.503641+00	141
297	377252dbefa2af9afc5a489521c16b85	photos/388920_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:11:37.781969+00	140
298	377252dbefa2af9afc5a489521c16b85	photos/290210_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:11.942678+00	101
299	377252dbefa2af9afc5a489521c16b85	photos/290220_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:12.204987+00	100
300	377252dbefa2af9afc5a489521c16b85	photos/290230_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:12.489584+00	99
301	377252dbefa2af9afc5a489521c16b85	photos/290280_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:12.735933+00	98
302	377252dbefa2af9afc5a489521c16b85	photos/290290_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:13.053831+00	97
303	377252dbefa2af9afc5a489521c16b85	photos/290420_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:13.367761+00	96
304	377252dbefa2af9afc5a489521c16b85	photos/290440_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:13.652627+00	95
305	377252dbefa2af9afc5a489521c16b85	photos/290430_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:13.987842+00	94
306	377252dbefa2af9afc5a489521c16b85	photos/368600_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:14.251646+00	49
307	377252dbefa2af9afc5a489521c16b85	photos/368610_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:14.561185+00	48
308	377252dbefa2af9afc5a489521c16b85	photos/368640_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:14.879292+00	47
309	377252dbefa2af9afc5a489521c16b85	photos/368650_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:15.133356+00	46
310	377252dbefa2af9afc5a489521c16b85	photos/368500_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:15.425834+00	45
311	377252dbefa2af9afc5a489521c16b85	photos/363440_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:15.698101+00	44
312	377252dbefa2af9afc5a489521c16b85	photos/368700_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:16.009074+00	43
313	377252dbefa2af9afc5a489521c16b85	photos/363480_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:16.325005+00	42
314	377252dbefa2af9afc5a489521c16b85	photos/363450_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:16.598175+00	41
315	377252dbefa2af9afc5a489521c16b85	photos/368820_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:16.911632+00	36
316	377252dbefa2af9afc5a489521c16b85	photos/368830_01.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:17.177204+00	35
317	377252dbefa2af9afc5a489521c16b85	photos/330640_04.jpg.412x412_q85_crop.jpg	2022-03-23 07:12:34.276531+00	109
318	377252dbefa2af9afc5a489521c16b85	photos/天ふら粉アイコン.jpg.500x320_q85_crop.jpg	2022-03-23 07:13:29.016544+00	21
319	377252dbefa2af9afc5a489521c16b85	photos/からあけ.jpg.500x320_q85_crop.jpg	2022-03-23 07:13:29.489965+00	22
320	377252dbefa2af9afc5a489521c16b85	photos/AI_画像_qrRT6tk.jpg.500x320_q85_crop.jpg	2022-03-23 07:13:29.672264+00	23
321	377252dbefa2af9afc5a489521c16b85	photos/912.jpg.500x320_q85_crop.jpg	2022-03-23 07:13:29.980007+00	24
322	377252dbefa2af9afc5a489521c16b85	photos/洋風.jpg.500x320_q85_crop.jpg	2022-03-23 07:13:30.508777+00	25
323	377252dbefa2af9afc5a489521c16b85	photos/AdobeStock_246860321.jpeg.500x320_q85_crop.jpg	2022-03-23 07:13:31.116519+00	26
324	377252dbefa2af9afc5a489521c16b85	photos/ショートハスタ.jpg.500x320_q85_crop.jpg	2022-03-23 07:13:31.538364+00	27
325	377252dbefa2af9afc5a489521c16b85	photos/p2_2_30.jpg.500x320_q85_crop.jpg	2022-03-23 07:13:31.935937+00	28
326	377252dbefa2af9afc5a489521c16b85	photos/トラティショナルソースシスル.jpg.500x320_q85_crop.jpg	2022-03-23 07:13:33.024408+00	29
327	377252dbefa2af9afc5a489521c16b85	photos/その他.jpg.500x320_q85_crop.jpg	2022-03-23 07:13:33.399542+00	30
328	377252dbefa2af9afc5a489521c16b85	photos/天ふら粉アイコン.jpg.412x412_q85_crop.jpg	2022-03-23 07:13:42.06958+00	21
329	377252dbefa2af9afc5a489521c16b85	photos/からあけ.jpg.412x412_q85_crop.jpg	2022-03-23 07:13:42.539753+00	22
330	377252dbefa2af9afc5a489521c16b85	photos/AI_画像_qrRT6tk.jpg.412x412_q85_crop.jpg	2022-03-23 07:13:42.720923+00	23
331	377252dbefa2af9afc5a489521c16b85	photos/912.jpg.412x412_q85_crop.jpg	2022-03-23 07:13:43.046758+00	24
332	377252dbefa2af9afc5a489521c16b85	photos/洋風.jpg.412x412_q85_crop.jpg	2022-03-23 07:13:43.597408+00	25
333	377252dbefa2af9afc5a489521c16b85	photos/AdobeStock_246860321.jpeg.412x412_q85_crop.jpg	2022-03-23 07:13:44.281593+00	26
334	377252dbefa2af9afc5a489521c16b85	photos/ショートハスタ.jpg.412x412_q85_crop.jpg	2022-03-23 07:13:44.738903+00	27
335	377252dbefa2af9afc5a489521c16b85	photos/p2_2_30.jpg.412x412_q85_crop.jpg	2022-03-23 07:13:45.117753+00	28
336	377252dbefa2af9afc5a489521c16b85	photos/トラティショナルソースシスル.jpg.412x412_q85_crop.jpg	2022-03-23 07:13:46.125172+00	29
337	377252dbefa2af9afc5a489521c16b85	photos/その他.jpg.412x412_q85_crop.jpg	2022-03-23 07:13:46.420452+00	30
338	377252dbefa2af9afc5a489521c16b85	photos/heros/kitchen.jpg.2400x700_q85_crop.jpg	2022-03-23 08:50:10.571917+00	213
339	377252dbefa2af9afc5a489521c16b85	photos/heros/karaage.jpg.2400x700_q85_crop.jpg	2022-03-23 08:52:44.185961+00	214
340	377252dbefa2af9afc5a489521c16b85	photos/heros/okonomiyaki.jpg.2400x700_q85_crop.jpg	2022-03-23 08:52:47.197039+00	216
341	377252dbefa2af9afc5a489521c16b85	photos/heros/yofu.jpg.2400x700_q85_crop.jpg	2022-03-23 08:52:50.605137+00	217
342	377252dbefa2af9afc5a489521c16b85	photos/heros/longpasta.jpg.2400x700_q85_crop.jpg	2022-03-23 08:52:53.581895+00	218
343	377252dbefa2af9afc5a489521c16b85	photos/heros/shortpasta.jpg.2400x700_q85_crop.jpg	2022-03-23 08:52:57.171696+00	219
344	377252dbefa2af9afc5a489521c16b85	photos/heros/longpasta_paMuhtx.jpg.2400x700_q85_crop.jpg	2022-03-23 08:54:41.587336+00	222
345	377252dbefa2af9afc5a489521c16b85	photos/heros/kitchen_kxoB7Qb.jpg.2400x700_q85_crop.jpg	2022-03-23 09:11:22.843112+00	221
346	377252dbefa2af9afc5a489521c16b85	photos/heros/kona.jpg.2400x700_q85_crop.jpg	2022-03-23 09:43:00.397589+00	215
347	377252dbefa2af9afc5a489521c16b85	photos/heros/souzai.jpg.2400x700_q85_crop.jpg	2022-03-23 09:43:19.527452+00	220
348	377252dbefa2af9afc5a489521c16b85	photos/330690_04.jpg.412x412_q85_crop.jpg	2022-03-23 10:13:27.690917+00	102
349	377252dbefa2af9afc5a489521c16b85	photos/361250_04.jpg.412x412_q85_crop.jpg	2022-03-23 10:59:03.746986+00	108
350	377252dbefa2af9afc5a489521c16b85	photos/344420_04.jpg.412x412_q85_crop.jpg	2022-03-23 10:59:06.785779+00	107
351	377252dbefa2af9afc5a489521c16b85	photos/344390_04.jpg.412x412_q85_crop.jpg	2022-03-23 10:59:10.861596+00	106
\.


--
-- Data for Name: easy_thumbnails_thumbnaildimensions; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.easy_thumbnails_thumbnaildimensions (id, thumbnail_id, width, height) FROM stdin;
\.


--
-- Data for Name: products_brand; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.products_brand (id, name, slug, the_order) FROM stdin;
1	マ・マーTHE PROブランド	mama_the_pro	0
\.


--
-- Data for Name: products_category; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.products_category (id, title, title_en, subtitle, description, hero, photo, slug, lft, rght, tree_id, level, parent_id, the_order) FROM stdin;
14	漬け込みまぶしタイプ	tsuke mabushi	\N				tsukemabushi	4	5	2	1	2	0
16	まぶしタイプ	mabushi	\N				mabushi	8	9	2	1	2	0
10	かるサクシリーズ	karusaku	\N				karusaku	2	3	1	1	1	0
11	揚げ上手シリーズ	agejouzu	\N				agejouzu	4	5	1	1	1	0
12	調理行程削減	reduction	\N				reduction	6	7	1	1	1	0
17	味つき	flavoured	\N				flavoured	10	11	2	1	2	0
13	水溶き	mizutoki	\N				mizutoki	2	3	2	1	2	0
15	水溶きまぶし	mizutoki mabushi	\N				mizutokimabushi	6	7	2	1	2	0
18	味なし	unflavoured	\N				unflavoured	12	13	2	1	2	0
19	打ち粉	uchiko	\N				uchiko	2	3	3	1	3	0
20	バッター	batter	\N				batter	4	5	3	1	3	0
21	畜肉用	meat	\N				meat	6	7	3	1	3	0
22	魚介用	seafood	\N				seafood	8	9	3	1	3	0
24	お好み焼	okonomiyaki	\N				okonomiyaki	4	5	4	1	4	0
25	鯛焼き	taiyaki	\N				taiyaki	6	7	4	1	4	0
26	大判焼き	obanyaki	\N				obanyaki	8	9	4	1	4	0
27	冷麺	reimen	\N				reimen	10	11	4	1	4	0
28	パンケーキ	pancake	\N				pancake	2	3	5	1	5	0
30	ホットケーキ	hot cake	\N				hotcake	6	7	5	1	5	0
31	蒸しパン	steamed bread	\N				steamedbread	8	9	5	1	5	0
34	チュロス	churros	\N				churros	14	15	5	1	5	0
35	ホワイトソース	white sauce	\N				whitesauce	16	17	5	1	5	0
50	ワンディッシュ	one dish	\N				onedish	2	3	8	1	8	0
51	付け合わせ	garnish	\N				garnish	4	5	8	1	8	0
44	ストレートマカロニ	macaroni	\N				macaroni	2	3	7	1	7	0
45	フィジリ	fusilli	\N				fusilli	4	5	7	1	7	0
48	その他	other short pasta	\N				others_short	10	11	7	1	7	0
38	1.8㎜～	1.8㎜ -	\N				1_8mm-	6	7	6	1	6	0
36	～1.5㎜	- 1.5mm	\N				-1_5mm	2	3	6	1	6	0
37	1.6～1.7㎜	1.6 - 1.7㎜	\N				1_6-1_7mm	4	5	6	1	6	0
40	乾麺	dried noodle	\N				driednoodle	10	11	6	1	6	0
41	生麺	raw noodle	\N				rawnoodle	12	13	6	1	6	0
42	ゆで時間短縮	fast	\N				fast	14	15	6	1	6	0
43	ディチェコ	dececco_long	\N				dececco_long	16	17	6	1	6	0
23	たこ焼	takoyaki	\N				takoyaki	2	3	4	1	4	0
29	クレープ	crepe	\N				crepe	4	5	5	1	5	0
32	ワッフル	waffle	\N				waffle	10	11	5	1	5	0
33	ピザ	pizza	\N				pizza	12	13	5	1	5	0
39	ハーフ	half	\N				half	8	9	6	1	6	0
46	ペンネ	penne	\N				penne	6	7	7	1	7	0
47	シェル	shell	\N				shell	8	9	7	1	7	0
49	ディチェコ	dececco shortpasta	\N				dececco_shortpasta	12	13	7	1	7	0
52	パウチ	pouch	\N				pouch	2	3	9	1	9	0
53	缶	can	\N				can	4	5	9	1	9	0
54	チューブ	tube	\N				tube	6	7	9	1	9	0
1	天ぷら粉	tempurako	\N		photos/heros/kitchen.jpg	photos/天ふら粉アイコン.jpg	tempurako	1	8	1	0	\N	0
2	から揚げ粉	karaageko	\N		photos/heros/karaage.jpg	photos/からあけ.jpg	karaageko	1	14	2	0	\N	0
3	バッター・打ち粉	batter uchiko	\N		photos/heros/kona.jpg	photos/AI_画像_qrRT6tk.jpg	bb	1	10	3	0	\N	0
4	和風メニュー	japanese menu	(お好み焼・たこ焼他)		photos/heros/okonomiyaki.jpg	photos/912.jpg	japanesemenu	1	12	4	0	\N	0
5	洋風メニュー	western menu	(スイーツ他)		photos/heros/yofu.jpg	photos/洋風.jpg	westernmenu	1	18	5	0	\N	0
6	ロングパスタ	long pasta	\N		photos/heros/longpasta.jpg	photos/AdobeStock_246860321.jpeg	longpasta	1	18	6	0	\N	0
7	ショートパスタ	short pasta	\N		photos/heros/shortpasta.jpg	photos/ショートハスタ.jpg	shortpasta	1	14	7	0	\N	0
8	調理済みパスタ	cooked pasta	\N		photos/heros/souzai.jpg	photos/p2_2_30.jpg	cookedpasta	1	6	8	0	\N	0
55	その他	others	\N		photos/heros/kitchen_kxoB7Qb.jpg	photos/その他.jpg	others	1	2	10	0	\N	0
9	パスタソース	pasta sauce	\N		photos/heros/longpasta_paMuhtx.jpg	photos/トラティショナルソースシスル.jpg	pastasauce	1	8	9	0	\N	0
\.


--
-- Data for Name: products_facility; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.products_facility (id, name, slug, the_order) FROM stdin;
1	フライ	fry	0
2	ボイル	boil	0
3	ベイク	bake	0
4	スチーム	steam	0
5	レンジ	microwave	0
\.


--
-- Data for Name: products_industry; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.products_industry (id, name, description, hero, photo, slug, the_order) FROM stdin;
1	外食				restaurant	0
2	中食惣菜				ready-made	0
3	テイクアウト・デリバリー				delivery	0
4	介護施設・病院				hospital	0
5	給食				school	0
6	加工工場				factory	0
\.


--
-- Data for Name: products_photo; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.products_photo (id, photo, label, product_id) FROM stdin;
5	photos/309490_01.jpg	main	257
6	photos/309310_01.jpg	main	256
7	photos/321120_01.jpg	main	255
8	photos/368830_01.jpg	main	254
9	photos/368820_01.jpg	main	253
10	photos/368810_01.jpg	main	252
11	photos/368800_01.jpg	main	251
12	photos/362510_01.jpg	main	250
13	photos/363280_01.jpg	main	249
14	photos/363450_01.jpg	main	248
15	photos/363480_01.jpg	main	247
16	photos/368700_01.jpg	main	246
17	photos/363440_01.jpg	main	245
18	photos/368500_01.jpg	main	244
19	photos/368650_01.jpg	main	243
20	photos/368640_01.jpg	main	242
21	photos/368610_01.jpg	main	241
22	photos/368600_01.jpg	main	240
23	photos/363460_01.jpg	main	239
24	photos/363420_01.jpg	main	238
25	photos/363410_01.jpg	main	237
26	photos/363220_01.jpg	main	236
27	photos/363210_01.jpg	main	234
28	photos/363200_01.jpg	main	231
29	photos/350850_01.jpg	main	230
30	photos/368620_01.jpg	main	229
31	photos/368590_01.jpg	main	228
32	photos/368580_01.jpg	main	227
33	photos/368790_01.jpg	main	226
34	photos/368540_01.jpg	main	225
35	photos/362990_01.jpg	main	224
36	photos/333690_01.jpg	main	223
37	photos/333680_01.jpg	main	222
38	photos/327750_01.jpg	main	221
39	photos/327820_01.jpg	main	220
40	photos/385730_01.jpg	main	219
41	photos/386600_01.jpg	main	218
42	photos/386580_01.jpg	main	217
43	photos/386610_01.jpg	main	216
44	photos/378750_01.jpg	main	215
45	photos/386590_01.jpg	main	214
46	photos/395600_01.jpg	main	213
47	photos/395560_01.jpg	main	212
48	photos/395680_01.jpg	main	211
49	photos/375600_01.jpg	main	210
50	photos/331750_01.jpg	main	209
51	photos/388930_01.jpg	main	208
52	photos/290480_01.jpg	main	207
53	photos/290470_01.jpg	main	206
54	photos/290460_01.jpg	main	205
55	photos/290190_01.jpg	main	204
56	photos/290170_01.jpg	main	203
57	photos/290110_01.jpg	main	202
58	photos/333780_01.jpg	main	201
59	photos/333770_01.jpg	main	200
60	photos/333750_01.jpg	main	199
61	photos/333740_01.jpg	main	198
62	photos/382390_01.jpg	main	197
63	photos/321420_01.jpg	main	196
64	photos/387710_01.jpg	main	195
65	photos/321390_01.jpg	main	194
66	photos/321400_01.jpg	main	193
67	photos/290430_01.jpg	main	186
68	photos/290440_01.jpg	main	185
69	photos/290420_01.jpg	main	184
70	photos/290290_01.jpg	main	183
71	photos/290280_01.jpg	main	182
72	photos/290230_01.jpg	main	181
73	photos/290220_01.jpg	main	180
74	photos/290210_01.jpg	main	179
75	photos/330690_04.jpg	cooked	178
76	photos/330670_04.jpg	cooked	177
77	photos/330660_04.jpg	cooked	176
78	photos/300040_04.jpg	cooked	175
79	photos/344390_04.jpg	cooked	174
80	photos/344420_04.jpg	cooked	173
81	photos/361250_04.jpg	cooked	172
82	photos/330640_04.jpg	cooked	169
83	photos/321240_01.jpg	main	168
84	photos/387960_1.jpg	main	167
85	photos/387950_1.jpg	main	166
86	photos/353100_01.jpg	main	165
87	photos/387690_01.jpg	main	164
88	photos/353180_01.jpg	main	163
89	photos/353140_01.jpg	main	162
90	photos/353060_01.jpg	main	161
91	photos/353050_01.jpg	main	160
92	photos/353040_01.jpg	main	159
93	photos/353250_01.jpg	main	158
94	photos/353240_01.jpg	main	157
95	photos/353230_01.jpg	main	156
96	photos/353220_01.jpg	main	155
97	photos/353210_01.jpg	main	154
98	photos/364750_01.jpg	main	153
99	photos/364720_01.jpg	main	152
100	photos/364730_01.jpg	main	151
101	photos/364740_01.jpg	main	150
102	photos/395920_01.jpg	main	149
103	photos/395910_01.jpg	main	148
104	photos/271440_01.jpg	main	147
105	photos/343980_01.jpg	main	146
106	photos/368850_01.jpg	main	145
107	photos/361960_01.jpg	main	144
108	photos/368840_01.jpg	main	143
109	photos/395950_01.jpg	main	142
110	photos/395900_01.jpg	main	141
111	photos/395890_01.jpg	main	140
112	photos/395880_01.jpg	main	139
113	photos/388920_01.jpg	main	138
114	photos/388890_01.jpg	main	137
115	photos/308760_01.jpg	main	136
116	photos/339360_01.jpg	main	135
117	photos/381330_01.jpg	main	134
118	photos/383990_01.jpg	main	133
119	photos/386780_01.jpg	main	132
120	photos/350380_01.jpg	main	131
121	photos/348010_01.jpg	main	130
122	photos/348270_01.jpg	main	129
123	photos/348200_01.jpg	main	128
124	photos/348190_01.jpg	main	127
125	photos/348180_01.jpg	main	126
126	photos/348300_01.jpg	main	125
127	photos/348250_01.jpg	main	124
129	photos/350410_01.jpg	main	120
130	photos/351050_01.jpg	main	119
131	photos/348240_01.jpg	main	118
132	photos/386860_01.jpg	main	117
133	photos/383060_01.jpg	main	116
134	photos/309430_01.jpg	main	115
135	photos/302550_01.jpg	main	114
136	photos/387740_01.jpg	main	113
137	photos/385020_01.jpg	main	112
138	photos/348390_01.jpg	main	107
139	photos/350390_01.jpg	main	106
140	photos/313780_01.jpg	main	105
141	photos/313790_01.jpg	main	104
142	photos/335050_01.jpg	main	97
143	photos/337700_01.jpg	main	96
144	photos/410490_01.jpg	main	93
145	photos/410480_01.jpg	main	92
146	photos/337610_01.jpg	main	91
147	photos/271330_01.jpg	main	90
148	photos/271320_01.jpg	main	89
149	photos/271310_01.jpg	main	88
150	photos/271300_01.jpg	main	87
151	photos/270590_01.jpg	main	86
152	photos/335010_01.jpg	main	85
153	photos/340910_01.jpg	main	84
154	photos/337690_01.jpg	main	83
155	photos/335150_01.jpg	main	82
156	photos/335140_01.jpg	main	81
157	photos/335170_01.jpg	main	78
158	photos/335160_01.jpg	main	77
159	photos/271390_01_cyO9Doc.jpg	main	74
160	photos/337590_01.jpg	main	76
161	photos/334590_01.jpg	main	73
162	photos/394980_01.jpg	main	72
163	photos/394990_01.jpg	main	71
164	photos/334640_01.jpg	main	70
165	photos/340490_01.jpg	main	69
166	photos/340430_01_sdA7eGI.jpg	main	68
167	photos/340020_01.jpg	main	67
168	photos/334860_01.jpg	main	66
169	photos/340480_01.jpg	main	65
170	photos/305950_01.jpg	main	64
171	photos/334610_01.jpg	main	63
172	photos/334690_01.jpg	main	62
173	photos/334620_01.jpg	main	61
174	photos/334730_01.jpg	main	60
175	photos/334570_01.jpg	main	59
176	photos/334510_01.jpg	main	58
177	photos/334870_01.jpg	main	57
178	photos/305760_01.jpg	main	56
179	photos/305630_01.jpg	main	55
180	photos/395080_01.jpg	main	54
181	photos/381680_01.jpg	main	53
182	photos/394810_01.jpg	main	52
183	photos/395320_01.jpg	main	51
184	photos/332440_01.jpg	main	50
185	photos/271380_01.jpg	main	75
\.


--
-- Data for Name: products_product; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.products_product (id, created, modified, title, subtitle, markcode, slug, price, description, is_published, is_new, shipping_date, hero, handling_water, handling_time, handling_temp, handling_recipe, brand_id, series_id, packing, additive, caution, country, expiration_date, gtin, pos, freespace_a, freespace_b, freespace_c, handling_extra, handling_link, carton_depth, carton_height, carton_weight, carton_width, packing_depth, packing_height, packing_weight, packing_width, the_order) FROM stdin;
64	2022-03-20 05:10:18.781358+00	2022-03-24 22:17:05.650026+00	天ぷら粉軽やか衣	\N	305950	305950	\N	上質な薄力小麦粉の風味を大切にした、シンプルで上品な味わいの衣が特徴。素材本来の持ち味を活かしたサクッと軽い食感に仕上がります。専門店でしか味わえなかった「揚げたての軽さと旨さ」を実現。使用しやすいチャック付きです。	t	f	\N		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	1kg×10	加工でん粉、ベーキングパウダー		日本	12ヶ月	14902110305958	4902110305951					\N	255	175	\N	509	40	310	\N	195	0
63	2022-03-20 05:10:18.781358+00	2022-03-24 22:16:38.633959+00	天ぷら粉揚げ上手Cタイプ	\N	334610	334610	\N	揚げ上手のコンセプトはそのままに、黄橙色を濃くし、スーパー様での惣菜向けに改良したタイプです。	t	f	\N		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	10kg	加工でん粉、ベーキングパウダー、乳化剤、着色料（クチナシ、ビタミンB₂、カロチン、アナトー）		日本	10ヶ月	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
62	2022-03-20 05:10:18.781358+00	2022-03-24 22:16:15.896831+00	天ぷら粉揚げ上手Cタイプ	\N	334690	334690	\N	揚げ上手のコンセプトはそのままに、黄橙色を濃くし、スーパー様での惣菜向けに改良したタイプです。	t	f	\N		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	1kg×10	加工でん粉、ベーキングパウダー、乳化剤、着色料（クチナシ、ビタミンB₂、カロチン、アナトー）		日本	12ヶ月	14902110334699	4902110334692					\N	255	175	\N	509	40	310	\N	195	0
61	2022-03-20 05:10:18.781358+00	2022-03-24 22:15:25.272946+00	天ぷら粉揚げ上手Jタイプ	\N	334620	334620	\N	揚げ上手のコンセプトはそのままに、黄橙色を濃くし適度に塩味を付けました。\r\n揚げ種の風味をより一層引き立てます。	t	f	\N		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	10kg	加工でん粉、ベーキングパウダー、乳化剤、調味料（アミノ酸）着色料（カロチン、クチナシ、ビタミンB₂、アナトー）		日本	10ヶ月	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
60	2022-03-20 05:10:18.781358+00	2022-03-24 22:15:02.123572+00	天ぷら粉揚げ上手Jタイプ	\N	334730	334730	\N	揚げ上手のコンセプトはそのままに、黄橙色を濃くし適度に塩味を付けました。\r\n揚げ種の風味をより一層引き立てます。	t	f	\N		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	1kg×10	加工でん粉、ベーキングパウダー、乳化剤、調味料（アミノ酸）着色料（カロチン、クチナシ、ビタミンB₂、アナトー）		日本	12ヶ月	14902110334736	4902110334739					\N	255	175	\N	509	40	310	\N	195	0
59	2022-03-20 05:10:18.781358+00	2022-03-24 22:01:57.128946+00	天ぷら粉揚げ上手	\N	334570	334570	\N	カラッと揚がり、時間経過後もサクサクした食感が残る画期的な天ぷら粉。冷水で仕込みをする必要も無くハンドリングも簡単なため、天ぷらを揚げるのに必要とされていたコツもいりません。スーパーの惣菜用からレストランまで幅広くご使用いただけます。荷姿は２タイプ、用途に合わせてお選び下さい。	t	f	\N		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	10kg	加工でん粉、ベーキングパウダー、乳化剤、着色料（クチナシ、ビタミンB₂、アナトー）		日本	10ヶ月	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
57	2022-03-20 05:10:18.781358+00	2022-03-24 22:00:34.064919+00	天ぷら粉レンジでサクサク揚げ上手	\N	334870	334870	\N	天ぷらを電子レンジで温めなおしてもしんなりしない食感の、経時耐性がある天ぷら粉です。\r\n食感をそそる細かい花咲に仕上がります。	t	f	\N		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	1kg×10	加工でん粉、ベーキングパウダー、乳化剤、増粘多糖類、マリーゴールド色素		日本	12ヶ月	14902110334873	4902110334876					\N	255	175	\N	509	40	310	\N	195	0
56	2022-03-20 05:10:18.781358+00	2022-03-24 21:59:31.72005+00	天ぷら粉 かる～い揚げ上手Bタイプ	\N	305760	305760	\N	「かる～い揚げ上手」の揚げ色を鮮やかな黄色にしたタイプ。見栄えの良い仕上がりは、惣菜売場でもおいしさを演出いたします。１袋に水１ℓを加えるだけなので、オペレーションにも優れた天ぷら粉です。	t	f	\N		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	625g×15	加工でん粉、ベーキングパウダー、マリーゴールド色素		日本	12ヶ月	14902110305767	4902110305760					\N	225	205	\N	510	30	260	\N	210	0
55	2022-03-20 05:10:18.781358+00	2022-03-24 21:58:40.333221+00	天ぷら粉かる～い揚げ上手	\N	305630	305630	\N	誰でも美味しく上手に揚がる「揚げ上手」がかる～い食感に。時間がたってもカラッとしたおいしさが長持ち。揚げる際の余分な衣の散りを抑\r\nえているため、かき揚げも簡単にソフトに仕上がります。	t	f	\N		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	1kg×10	加工でん粉、ベーキングパウダー、クチナシ色素		日本	12ヶ月	14902110305637	4902110305630					\N	255	175	\N	509	40	310	\N	195	0
53	2022-03-20 05:10:18.781358+00	2022-03-24 21:53:53.632584+00	天ぷら粉追い種いらずの揚げ上手	\N	381680	381680	\N	打ち粉・追い種も使わずに揚がる画期的な天ぷら粉です。手が汚れにくく、作業効率が向上します。	t	f	\N		150%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	1kg×10	加工でん粉、ベーキングパウダー、乳化剤、トレハロース、クチナシ色素		日本	12ヶ月	14902110381686	4902110381689					\N	255	175	\N	509	40	310	\N	190	0
52	2022-03-20 05:10:18.781358+00	2022-03-24 21:48:19.790413+00	天ぷら粉打ち粉いらずのかるサク衣	\N	394810	394810	\N	従来必要な打ち粉行程が必要ないことから、省作業、省スペース化が可能です。また粉で調理台を汚しません。初めて天ぷらを揚げる方にも作りやすい画期的な天ぷら粉です。	t	f	\N		150%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	1kg×10	加工でん粉、ベーキングパウダー、乳化剤、調味料（アミノ酸等）、クチナシ色素		日本	12ヶ月	14902110394815	4902110394818					\N	255	175	\N	509	40	310	\N	195	0
50	2022-03-20 05:10:18.781358+00	2022-03-24 21:46:08.147223+00	天ぷら粉かるサク衣	\N	332440	332440	\N	かるくてサクサクした食感が長持ちする天ぷら粉です。外食のテイクアウト需要や惣菜売場にも適しています。	t	f	\N		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	1kg×10	加工でん粉、ベーキングパウダー、乳化剤、調味料（アミノ酸等）、クチナシ色素		日本	12ヶ月	14902110332442	4902110332445					\N	255	175	\N	509	40	300	\N	195	0
51	2022-03-20 05:10:18.781358+00	2022-03-24 21:47:40.257742+00	天ぷら粉かるサク衣	\N	395320	395320	\N	かるくてサクサクした食感が長持ちする天ぷら粉です。外食のテイクアウト需要や惣菜売場にも適しています。	t	f	\N		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	10kg	加工でん粉、ベーキングパウダー、乳化剤、調味料（アミノ酸等）、クチナシ色素		日本	10ヶ月	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
100	2022-03-20 05:10:18.781358+00	2022-03-24 22:48:35.800945+00	魚フライ用ミックス #62-60	\N	452600	452600	\N	ソフトな食感でバター切れに優れたミックスです。歩留まりが極めて良好です。	t	f	\N		420%	約5分	170～180℃		\N	\N	20kg	グァーガム(糊料)、乳化剤		日本	\N	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
79	2022-03-20 05:10:18.781358+00	2022-03-24 22:28:32.497467+00	から揚げ粉 #11-68	水溶きタイプ	470430	470430	\N	各種香辛料で特徴づけしたチキンから揚げ用のミックスです。肉に下味をつけたり、製法の組み合わせによる応用が可能です。衣の食感は軽く、マイルドな味・香りを持つから揚げが作れます。	t	f	\N		150%	約4分	170～180℃		\N	\N	20kg	調味料（アミノ酸等）、香辛料抽出物、キサンタンガム(糊料)、パプリカ色素		日本	\N	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
78	2022-03-20 05:10:18.781358+00	2022-03-24 22:28:07.364616+00	聖地中津からあげセット 塩だれ	漬け込みまぶしタイプ	335170	335170	\N	「聖地中津から揚げの会」が監修。「漬け込み用たれ」と「サクサクから揚げ粉」がセットになっているので、本場のおいしさが誰にでも作れます。	t	f	\N			約4分	170℃		\N	\N	(ミックス360g+たれ200g)×16	【から揚げ粉】加工でん粉、pH調整剤、乳化剤　【たれ】ソルビトール、調味料（アミノ酸等）、酸味料、増粘剤（キサンタンガム）		日本	12ヶ月	14902110335177	4902110335170					\N	280	185	\N	430	40	310	\N	190	0
76	2022-03-20 05:10:18.781358+00	2022-03-24 22:27:33.726693+00	THE KARAAGE から揚げ粉	水溶きタイプ	337590	337590	\N	水溶きから揚げ粉で下味いらず、調理も簡単です。衣はソフトな食感で、発酵調味料粉末使用によりお肉がとてもジューシーに仕上がります。日本唐揚協会認定商品です。	t	f	\N		100%	約4分	170℃		\N	\N	1kg×10	加工でん粉、調味料（アミノ酸等）、ベーキングパウダー、乳化剤、pH調整剤		ベトナム	13ヶ月	14902110337591	4902110337594					\N	310	246	\N	390	40	330	\N	225	0
80	2022-03-20 05:10:18.781358+00	2022-03-24 22:28:51.810786+00	たつた揚げ粉 #13-35	まぶしタイプ	471350	471350	\N	表面に白い粉を吹き、フライ後の経時変化耐性にも優れたサックリした食感のたつた揚げができます。	t	f	\N			約4分	170～180℃		\N	\N	20kg	調味料（アミノ酸等）		日本	\N	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
74	2022-03-20 05:10:18.781358+00	2022-03-24 22:26:14.144723+00	天ぷら粉　味わい衣	\N	271390	271390	\N	小麦粉本来の持ち味を活かし、素材を引き立てる天ぷら粉です。明るい白色に揚がり、ソフトで口どけの良い食感に仕上がります。	t	t	2022-02-28 15:00:00+00		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	1kg×10	ベーキングパウダー		日本	12ヶ月	14902110271390	4902110271393					\N	280	265	\N	390	40	345	\N	225	0
73	2022-03-20 05:10:18.781358+00	2022-03-24 22:25:46.627702+00	天ぷら粉デラックス	\N	334590	334590	\N	卵とでんぷんをバランスよく配合した、薄衣タイプの天ぷら粉です。際立った揚げ色の白さは、素材のおいしさを一層引き立てます。	t	f	\N		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	10kg	加工でん粉、ベーキングパウダー		日本	10ヶ月	\N	4902110334593					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
72	2022-03-20 05:10:18.781358+00	2022-03-24 22:25:06.448297+00	おそば屋さん・うどん屋さんの天ぷら粉 つゆ溶け衣	\N	394980	394980	\N	口溶けが良い食感が、つゆにのせても、つゆにのせなくても持続します。着色料を使わずに、ほのかな黄橙色に揚がります。	t	f	\N		160～170％	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	10kg	ベーキングパウダー		日本	10ヶ月	\N	4902110394986					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
71	2022-03-20 05:10:18.781358+00	2022-03-24 22:21:56.965075+00	おそば屋さん・うどん屋さんの天ぷら粉 つゆにのせてもしっかり衣	\N	394990	394990	\N	つゆにのせても、サクッとした食感が持続します。ベーキングパウダーを使用しない独自配合の天ぷら粉です。	t	f	\N		170～180％	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	10kg	加工でん粉、乳化剤、クチナシ色素		日本	10ヶ月	\N	4902110394993					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
70	2022-03-20 05:10:18.781358+00	2022-03-24 22:20:52.115223+00	天ぷら粉Bタイプ	\N	334640	334640	\N	花咲が良く、鮮やかな黄色の天ぷらが揚がる天ぷら粉。粘度安定性が良いため機械適性に優れ、時間経過後も良好な食感を保つタイプです。大量生産に適し、惣菜用としてもお使いいただけます。	t	f	\N		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	20kg	加工でん粉、ベーキングパウダー、着色料（アナトー、ビタミンB₂）		日本	10ヶ月	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
69	2022-03-20 05:10:18.781358+00	2022-03-24 22:20:10.811547+00	天ぷら粉A2タイプ	\N	340490	340490	\N	「天ぷら粉Ａタイプ」をベースに、一層水溶きを良くした天ぷら粉。作業性に優れ、よりカラッとした食感で、明るい色の天ぷらが揚がります。	t	f	\N		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	20kg	加工でん粉、ベーキングパウダー		日本	10ヶ月	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
68	2022-03-20 05:10:18.781358+00	2022-03-24 22:19:28.980978+00	天ぷら粉Aタイプ	\N	340430	340430	\N	花咲が良く、明るい白色に揚がり、しかもボリューム感のある、軽い食感が味わえる天ぷら粉。汎用タイプですので、独自の味付けにより、幅広くお使いいただけます。荷姿は２タイプ、用途に合わせてお選びください。	t	f	\N		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	20kg	ベーキングパウダー		日本	10ヶ月	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
66	2022-03-20 05:10:18.781358+00	2022-03-24 22:18:07.624537+00	国内麦小麦粉使用おいしい天ぷら粉	\N	334860	334860	\N	天ぷら粉に使用している小麦粉はすべて国内麦小麦粉です。小麦粉のグルテンを分解する酵素プロテアーゼを配合しました。\r\n米粉を程よく配合しております。	t	f	\N		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	1kg×10	加工でん粉、ベーキングパウダー、乳化剤、調味料（アミノ酸等）、カロチン色素、酵素		日本	12ヶ月	14902110334866	4902110334869					\N	255	175	\N	509	40	310	\N	195	0
81	2022-03-20 05:10:18.781358+00	2022-03-24 22:29:13.36022+00	から揚げ粉 唐揚王	水溶きタイプ	335140	335140	\N	衣はサクっとしながら、お肉はソフトでジューシーな食感を実現しました。ふっくらと仕上がり歩留まりが良く経済的です。	t	f	\N		100%	約4分	170～180℃		\N	\N	400g×20	加工でん粉、調味料（アミノ酸等）、ベーキングパウダー、乳化剤		日本	12ヶ月	14902110335122	4902110335125					\N	310	175	\N	420	30	240	\N	145	0
98	2022-03-20 05:10:18.781358+00	2022-03-24 22:45:55.153541+00	トンカツ用ミックス #24-25	\N	474250	474250	\N	衣と肉の結着が良好で打ち粉なしでも衣が素材に良くつきます。	t	f	\N		200%	約5分	170～180℃		\N	\N	20kg	増粘多糖類、カゼインナトリウム、乳化剤		日本	\N	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
94	2022-03-20 05:10:18.781358+00	2022-03-24 22:40:58.987446+00	コロッケ用ミックス　#23-58	\N	472310	472310	\N	フライ後の経時変化耐性に優れた衣になります。サックリとした軽い食感の衣に仕上がります。	t	f	\N		300%	約5分	170～180℃		\N	\N	20kg	グァーガム(糊料)		日本	\N	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
93	2022-03-20 05:10:18.781358+00	2022-03-24 22:39:42.888549+00	バッターミックス サクミ長持ち上手！	\N	410490	410490	\N	フライ後の経時変化耐性を付与したバッターミックスです。サクミのある食感を維持。特にコロッケ、メンチカツに向いています。	t	f	\N		270%	約5分	170～180℃		\N	\N	10kg	加工でん粉、増粘多糖類、乳化剤		日本	8ヶ月	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
92	2022-03-20 05:10:18.781358+00	2022-03-24 22:36:42.66084+00	バッターミックス　これで結着！	\N	410480	410480	\N	打ち粉なしでは結着が難しいイカフライ・エビフライ等の魚介系や、トンカツ・メンチカツ・ハムカツ等の畜肉系にも結着性が高いバッターミックスです。	t	f	\N		210%	約5分	170～180℃		\N	\N	10kg	加工でん粉、増粘多糖類		日本	8ヶ月	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
91	2022-03-20 05:10:18.781358+00	2022-03-24 22:35:18.24532+00	THE TONKATSU	\N	337610	337610	\N	「お肉ジューシー被膜製法」採用。パン粉付けした後、肉の周りに強力な被膜を形成することで、肉汁を逃さずにお肉がジューシーに仕上がります。打ち粉行程も必要ありません。	t	f	\N		250%	約5分	170～180℃		\N	\N	1kg×10	加工でん粉、ベーキングパウダー、増粘剤（アルギン酸Na、増粘多糖類）、乳化剤、マリーゴールド色素		ベトナム	13ヶ月	14902110337614	4902110337617					\N	310	246	\N	390	40	330	\N	225	0
90	2022-03-20 05:10:18.781358+00	2022-03-24 22:34:08.641092+00	ザクザクから揚げ粉	まぶしタイプ	271330	271330	\N	米粉を配合しており、ザクザクとした特徴のある食感に仕上がるから揚げ粉です。フライドチキンやジーパイ等のアレンジから揚げにも最適です。	t	t	2022-02-28 15:00:00+00		25%	約4分	170～180℃		\N	\N	1kg×10	加工でん粉、調味料（アミノ酸等）、増粘剤（グァーガム）、乳化剤		日本	12ヶ月	14902110271338	4902110271331					\N	280	225	\N	390	40	345	\N	225	0
89	2022-03-20 05:10:18.781358+00	2022-03-24 22:33:26.097862+00	タレかけカリサクから揚げ粉	水溶きまぶしタイプ	271320	271320	\N	タレをかけても衣がしっかりしており、カリサク食感が長持ちするから揚げ粉です。時間が経っても、パックに入れても衣の食感が残りやすく美味しく召し上がれます。	t	t	2022-02-28 15:00:00+00		120%	約4分	170～180℃		\N	\N	1kg×10	加工でん粉、調味料（アミノ酸等）、ベーキングパウダー		日本	12ヶ月	14902110271321	4902110271324					\N	280	235	\N	390	40	345	\N	225	0
88	2022-03-20 05:10:18.781358+00	2022-03-24 22:32:53.956847+00	ゴツゴツから揚げ粉	まぶしタイプ	271310	271310	\N	専門店の様な凹凸感のあるゴツゴツとした外観に仕上がり、時間が経ってもしっかりとした食感が残るから揚げ粉です。	t	t	2022-02-28 15:00:00+00		対肉５％	約4分	170～180℃		\N	\N	1kg×10	加工でん粉、乳化剤		日本	12ヶ月	14902110271314	4902110271317					\N	280	225	\N	390	40	345	\N	225	0
87	2022-03-20 05:10:18.781358+00	2022-03-24 22:32:22.20509+00	薄衣サクサクから揚げ粉	まぶしタイプ	271300	271300	\N	昨今のから揚げのトレンドである「薄衣」でありながらも、軽くてサクサクした食感が長持ちするから揚げ粉です。	t	t	2022-02-28 15:00:00+00			約4分	170～180℃		\N	\N	1kg×10	加工でん粉		日本	12ヶ月	14902110271307	4902110271300					\N	280	225	\N	390	40	345	\N	225	0
86	2022-03-20 05:10:18.781358+00	2022-03-24 22:31:48.676565+00	から揚げ粉味付け自由な水溶きタイプ　中華街仕立て	水溶きタイプ	270590	270590	\N	カリッとした衣に仕上がる水溶きタイプのから揚げ粉です。ミックス粉に味付けをしていないため、お好みの味付けにアレンジいただけます。	t	t	\N		100%	約4分	170～180℃		\N	\N	1kg×10	加工でん粉、ベーキングパウダー、乳化剤		日本	12ヶ月	14902110270591	4902110270594					\N	316	224	\N	396	40	345	\N	225	0
84	2022-03-20 05:10:18.781358+00	2022-03-23 06:17:33.93733+00	から揚げミックス	水溶きまぶしタイプ	340910	340910	\N	粉末状なので、まぶし揚げと水溶き揚げが可能。また、塩分控えめのため、各種調味料、香辛料を加えることにより、お好みの味で調理できます。	t	f	\N		120%	約4分	170～180℃		\N	\N	2kg×5	調味料（アミノ酸等）、アナトー色素		日本	6ヶ月	14902110340911	4902110340914					\N	230	310	\N	350	50	390	\N	260	0
85	2022-03-20 05:10:18.781358+00	2022-03-24 22:30:27.967705+00	から揚げ粉 にんにく・しょうゆ風味	水溶きタイプ	335010	335010	\N	素材にから揚げと水を混ぜ合わせて揚げるだけで、本格的なから揚げができあがります。衣はカラッと、素材はジューシーに揚がり、冷めても、サクッと美味しさが長持ちします。香味豊かな和風タイプです。	t	f	\N		100%	約4分	160～180℃		\N	\N	1kg×10	加工でん粉、調味料（アミノ酸等）、ベーキングパウダー、カラメル色素、酸味料		日本	6ヶ月	14902110335016	4902110335019					\N	310	175	\N	390	40	330	\N	225	0
95	2022-03-20 05:10:18.781358+00	2022-03-24 22:42:14.349459+00	コロッケ用ミックス　#63-01	\N	453010	453010	\N	フライ後の経時変化耐性に優れた衣になります。サックリとした軽い食感の衣に仕上がります。	t	f	\N		300%	約5分	170～180℃		\N	\N	20kg	乳化剤、グァーガム(糊料)		日本	\N	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
96	2022-03-20 05:10:18.781358+00	2022-03-24 22:43:25.42732+00	パン粉が良くつく粉	\N	337700	337700	\N	打ち粉なしでも結着が良く、食感が軽くてジューシーに仕上がるバッターミックスです。卵入りなので、素材の旨味を引き立てます。	t	f	\N		250%	約5分	170～180℃		\N	\N	1kg×10	加工でん粉、調味料（アミノ酸）、乳化剤、増粘剤（キサンタンガム）、クチナシ色素		日本	12ヶ月	14902110337706	4902110337709					\N	310	215	\N	390	40	345	\N	225	0
99	2022-03-20 05:10:18.781358+00	2022-03-24 22:47:11.446878+00	海老フライ用ミックス #22-43	\N	472090	472090	\N	軽い食感で素材のジューシーさを逃しません。カキフライ用にも使用できます。	t	f	\N		450%	約5分	170～180℃		\N	\N	20kg	ベーキングパウダー、調味料（アミノ酸等）、グァーガム(糊料)、乳化剤、香辛料抽出物		日本	\N	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
102	2022-03-20 05:10:18.781358+00	2022-03-24 22:51:08.989214+00	打ち粉ミックス（魚介用） #22-02	\N	471520	471520	\N	流動性の高い打ち粉で均一に素材に付着します。	t	f	\N			約5分	170～180℃		\N	\N	20kg			日本	\N	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
103	2022-03-20 05:10:18.781358+00	2022-03-24 22:52:46.767441+00	打ち粉ミックス（畜肉用） #24-93	\N	474930	474930	\N	極めて結着が良好な打ち粉で衣と素材のはがれをなくします。	t	f	\N			約5分	170～180℃		\N	\N	20kg	乳成分・大豆		日本	\N	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
121	2022-03-20 05:10:18.781358+00	2022-03-24 23:21:55.992491+00	ホットケーキミックス #503	\N	465030	465030	\N	やや甘味を抑えた風味の良いボリューム感のあるホットケーキが作れます。	t	f	\N			片面3分、反転2分	185℃	60％+卵20％	\N	\N	10kg	ベーキングパウダー、乳化剤、香料、ビタミンB₂（着色料）		日本	\N	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
118	2022-03-20 05:10:18.781358+00	2022-03-24 23:20:09.211794+00	型のいらないホットケーキミックス 厚焼き上手	\N	348240	348240	\N	セルクルなどの型を使用せずに、今までにない厚みのある、ホットケーキが焼き上がります。口溶けが良く、ふんわり軽い食感です。ダマになりにくいミックスで、作業性に優れています。保持に便利なチャック付です。	t	f	\N			片面3分、反転3分	180℃	牛乳75%	\N	\N	1kg×10	ベーキングパウダー、乳化剤、加工でん粉、香料、増粘剤（キサンタンガム）		日本	12ヶ月	14902110348245	4902110348248					\N	255	175	\N	509	40	320	\N	210	0
117	2022-03-20 05:10:18.781358+00	2022-03-24 23:19:04.928666+00	冷凍のどごし冷麺	\N	386860	386860	\N	押し出し製法により、コシが強く、プリプリした食感が特徴です。のどごしも良好です。	t	f	\N			約60秒			\N	\N	(200g×5)×4×2	加工でん粉、アルギン酸エステル、炭酸水素Na		日本	12ヶ月	34902110386869	4902110386868					\N	330	130x2	\N	300	182	162	\N	121	0
116	2022-03-20 05:10:18.781358+00	2022-03-24 23:17:58.149467+00	ふんわりお好み焼（豚天）	\N	383060	383060	\N	軽い食感と口どけの良さ。角切りキャベツと保湿性を増す生地の配合で、パサつかない仕上がりに。	t	f	\N			①約2分<br>\r\n②約15分	①1500W<br>\r\n②220℃		\N	\N	900g(5枚)×8	加工でん粉、調味料（アミノ酸等）、膨張剤、安定剤（キサンタンガム）		日本	12ヶ月	14902110383062	4902110383065					\N	295	173	\N	460	\N	310	\N	150	0
114	2022-03-20 05:10:18.781358+00	2022-03-23 06:08:03.736937+00	たこ焼横丁 大玉たこ焼	\N	302550	302550	\N	一粒約30g！食べ応え満点の大型タイプ。生地の旨味ととろみが強く印象に残る大玉たこ焼です。	t	f	\N			①約1分30秒<br>\r\n②約5分	①1500W<br>\r\n②170～180℃		\N	\N	900g(30個)×12	加工でん粉、調味料（アミノ酸等）、膨張剤、安定剤（キサンタンガム）、酸味料、紅麴色素		日本	12ヶ月	14902110302551	\N					\N	291	359	\N	386	\N	340	\N	230	0
113	2022-03-20 05:10:18.781358+00	2022-03-24 23:12:37.310895+00	たこ焼横丁 Nたこ焼	\N	387740	387740	\N	国産キャベツを使用し、生地のとろみと旨みが特徴の釣り鐘型のたこ焼です。	t	f	\N			①約1分10秒<br>\r\n②約5分	①1500W<br>\r\n②170～180℃		\N	\N	800g(40個)×12	加工でん粉、膨張剤、調味料（アミノ酸等）、安定剤（キサンタンガム）、酸味料、紅麹色素		日本	12ヶ月	14902110387749	4902110387742					\N	291	349	\N	386	\N	340	\N	230	0
108	2022-03-20 05:10:18.781358+00	2022-03-24 23:06:35.99726+00	たい焼きミックス #916	\N	469160	469160	\N	餡に合うパリッとした食感で、焼き上がりも光沢があり、ボリューム感のある美しいたい焼きができます。	t	f	\N			3分合わせ3分（計6分）	180℃	105％+卵５％	\N	\N	25kg	ベーキングパウダー、アナトー色素、ビタミンB₂(着色料)		日本	\N	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
107	2022-03-20 05:10:18.781358+00	2022-03-24 23:05:21.568024+00	しっとり食感！鯛焼きミックス	\N	348390	348390	\N	水900gと混ぜるだけで簡単に鯛焼きの生地が出来上がります。しっとりとした食感で、中の餡を変えるだけで多彩なバリエーションが楽しめます。大判焼きにもご使用いただけます。	t	f	\N				175~185℃	90%	\N	\N	1kg×10	ベーキングパウダー、乳化剤、着色料（アナトー、ビタミンB₂）		日本	12ヶ月	14902110348399	4902110348392					\N	255	175	\N	509	40	310	\N	190	0
105	2022-03-20 05:10:18.781358+00	2022-03-24 23:03:47.998442+00	お好み焼粉 山いも入り	\N	313780	313780	\N	山いも入りで、ふんわり口どけの良いお好み焼き粉です。均一に焼き色がつき、香ばしく仕上がります。自然な鰹だし風味で、どのような素材にも良く合います。	t	f	\N				180℃	170%	\N	\N	1kg×10	ベーキングパウダー、安定剤（グァーガム）、調味料（アミノ酸）		日本	12ヶ月	14902110313786	4902110313789					\N	255	180	\N	509	40	310	\N	210	0
104	2022-03-20 05:10:18.781358+00	2022-03-24 22:54:10.224335+00	たこ焼粉	\N	313790	313790	\N	外はカリっと、中はとろ～りと仕上がるたこ焼粉です。丸くて色良い焼き上がりで、時間が経っても形が崩れにくいのでテイクアウトにも適しています。	t	f	\N					350%+卵6個	\N	\N	1kg×10	安定剤（グァーガム）、調味料（アミノ酸）		日本	12ヶ月	14902110313793	4902110313796					\N	255	180	\N	509	40	310	\N	210	0
109	2022-03-20 05:10:18.781358+00	2022-03-24 23:07:46.883301+00	大判焼きミックス #913	\N	469130	469130	\N	なめらかで光沢のある表皮とボリューム感のあるソフトな食感が特長の大判焼きが作れます。	t	f	\N			片面3分、反転3分	180℃	105％+卵５％	\N	\N	10kg	ベーキングパウダー、アナトー色素、ビタミンB₂(着色料)		日本	\N	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
110	2022-03-20 05:10:18.781358+00	2022-03-24 23:08:50.92236+00	お好み焼きミックス #912	\N	469120	469120	\N	豚肉、キャベツなどの具と調和する適度な旨味をもち、ソフトでしっとりしてベタつきがないお好み焼きが作れます。	t	f	\N			片面8分、反転7分	180℃	100%+卵70%	\N	\N	10kg	調味料（アミノ酸等）、ベーキングパウダー、香辛料抽出物		日本	\N	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
111	2022-03-20 05:10:18.781358+00	2022-03-24 23:09:55.953274+00	たこ焼きミックス #9CD	\N	460270	460270	\N	焼き縮みが少なく、あっさりとした風味のたこ焼きが作れます。	t	f	\N			片面8分、反転7分	180～200℃	250%	\N	\N	10kg	ベーキングパウダー、調味料（アミノ酸）		日本	\N	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
112	2022-03-20 05:10:18.781358+00	2022-03-24 23:11:24.917335+00	たこ焼横丁 関西丸たこ焼	\N	385020	385020	\N	本場関西風の旨味の聞いた味。カリっとした食感が活きるフライヤー調理がおすすめです。	t	f	\N			①約1分<br>\r\n②約4分	①1500W<br>\r\n②170～180℃		\N	\N	800g(40個)×10	加工でん粉、調味料（アミノ酸等）、膨張剤、酸味料、安定剤（キサンタンガム）、紅麴色素		日本	12ヶ月	14902110385028	4902110385021					\N	291	309	\N	386	\N	340	\N	230	0
115	2022-03-20 05:10:18.781358+00	2022-03-24 23:14:52.734763+00	Rお好み横丁 ふんわりお好み焼（豚玉）	\N	309430	309430	\N	100％国産キャベツを使用。ふんわりした生地に豚肉の旨味たっぷり。	t	f	\N			①約3分10秒<br>\r\n②約18分	①1500W<br>\r\n②180℃		\N	\N	1200g(5枚)×8	加工でん粉、調味料（アミノ酸等）、膨張剤、安定剤（キサンタンガム）		日本	12ヶ月	14902110309437	4902110309430					\N	355	238	\N	355	\N	345	\N	170	0
122	2022-03-20 05:10:18.781358+00	2022-03-24 23:24:07.614041+00	パンケーキミックス #505	\N	465050	465050	\N	ホットケーキより甘味とボリュームを抑えた、ソフトでしっとり、あっさりとした風味のスナックメニューが作れます。	t	f	\N			片面1.5分、反転1分	180～200℃	100%＋卵35%	\N	\N	10kg	ベーキングパウダー、香料		日本	\N	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
142	2022-03-20 05:10:18.781358+00	2022-03-24 23:50:35.894396+00	マ・マー スパゲティ　1.9	\N	395950	395950	\N		t	f	\N			12分			\N	\N	4kg×４			日本	36ヶ月	14902110395959	4902110395952					\N	279	159	\N	412	60	260	\N	320	0
141	2022-03-20 05:10:18.781358+00	2022-03-24 23:47:47.132466+00	マ・マー スパゲティ　1.7	\N	395900	395900	\N		t	f	\N			8分			\N	\N	4kg×４			トルコ	36ヶ月	14902110395904	4902110395907					\N	255	245	\N	285	60	260	\N	320	0
140	2022-03-20 05:10:18.781358+00	2022-03-24 23:44:50.374582+00	マ・マー スパゲティ　1.6	\N	395890	395890	\N		t	f	\N			7分			\N	\N	4kg×４			トルコ	36ヶ月	14902110395898	4902110395891					\N	255	245	\N	285	60	260	\N	320	0
138	2022-03-20 05:10:18.781358+00	2022-03-24 23:38:28.832506+00	ミニチュロス(チョコ味)	\N	388920	388920	\N	表面はカリカリ、中はソフトな食感が特長のスナックです。ココアパウダーを配合した、チョコ味のチュロスを、様々なデザートシーンにご利用いただける約５ｃｍのミニサイズにカットしました。	t	t	\N			①5～7分<br>\r\n②4～5分	①約190℃（オーブン）<br>\r\n②1000W（オーブントースター）		\N	\N	500g×8袋	カゼインNa、香料、乳化剤、糊料(グァーガム)、ベーキングパウダー		日本	12ヶ月	14902110388920	4902110388923					\N	416	209	\N	326	40	250	\N	400	0
136	2022-03-20 05:10:18.781358+00	2022-03-24 23:37:24.494394+00	チュロス®（チョコ味）	\N	308760	308760	\N	ココアパウダーを加えたチョコ味のチュロス。香ばしい香りが、食欲をそそります。約40㎝のロングサイズ。	t	f	\N			約5分	170～200℃		\N	\N	2.5kg(50本)×2	カゼインNa、香料、乳化剤、糊料(グァーガム)、ベーキングパウダー		日本	12ヶ月	14902110308768	\N					\N	323	180	\N	433	\N	\N	\N	\N	0
135	2022-03-20 05:10:18.781358+00	2022-03-24 23:36:50.639137+00	チュロス®（ミルク味）	\N	339360	339360	\N	表面はカリカリ、中身はソフト。軽い食感はそのままに、やさしく懐かしいミルクの風味を加えました。約40㎝のロングサイズ。	t	f	\N			約5分	170～200℃		\N	\N	2.5kg(50本)×2	カゼインNa、香料、ベーキングパウダー、糊料(グァーガム)、乳化剤		日本	12ヶ月	14902110339366	\N					\N	323	180	\N	433	\N	\N	\N	\N	0
133	2022-03-20 05:10:18.781358+00	2022-03-24 23:35:32.701797+00	チュロス®（ハーフサイズ）フライ＆ベイク	\N	383990	383990	\N	オーブン調理とフライヤー調理が可能です。長さが短いので、小型オーブンや、フライヤーで容易に調理することができます。	t	f	\N			①8～10分<br>\r\n②約3分<br>\r\n③約4～5分	①190℃（ベイク）<br>\r\n②165～175℃（フライ）\r\n③1000W		\N	\N	250g(10本)×8×2	加工でん粉、トレハロース、カゼインNa、乳化剤、増粘多糖類、香料、ベーキングパウダー		日本	12ヶ月	34902110383998	4902110383997					\N	220	100x2	\N	480	40	350	\N	150	0
132	2022-03-20 05:10:18.781358+00	2022-03-24 23:34:49.003218+00	自然解凍ミニパンケーキ	\N	386780	386780	\N	自然解凍でもちもちした食感のパンケーキです。本格的な銅板焼成で、均一な焼き目に仕上げました。（直径約８㎝）	t	f	\N			①約30分<br>\r\n②約25秒<br>\r\n③約50秒<br>\r\n④1分10秒	①室温（約20℃）<br>\r\n②1500W<br>\r\n③600W<br>\r\n④500W		\N	\N	400g(20枚)×10×2	加工でん粉、ベーキングパウダー、乳化剤、増粘多糖類		タイ	15ヶ月	34902110386784	4902110386783					\N	443	145x2	\N	338	40	290	\N	225	0
131	2022-03-20 05:10:18.781358+00	2022-03-24 23:33:52.431258+00	達人厨房 クリーミーホワイトソースMIX	\N	350380	350380	\N	水や牛乳で溶いて加熱するだけで、クリーミーで味わい深井ホワイトソースに仕上がります。ダマにならずに作業もラクラク。本格洋風メニューのベースとしてご使用下さい。	t	f	\N					900%<br>　\r\n※クリームシチューの場合	\N	\N	1kg×10	調味料（アミノ酸等）、香料		日本	12ヶ月	14902110350385	4902110350388					\N	255	175	\N	509	40	310	\N	190	0
130	2022-03-20 05:10:18.781358+00	2022-03-24 23:33:33.286262+00	ナポリ風ピッツァミックス	\N	348010	348010	\N	本格ナポリ風ピッツァを失敗なく作ることができます。延ばしやすい生地、ふんわりモチッとしたコルニチョーネが特徴です。薪窯はもちろん、ガス窯や電気オーブンにおいても本格的に焼き上がります。	t	f	\N			1分～1分30秒	400℃以上	60％+ドライイースト	\N	\N	2kg×6	加工でん粉、増粘多糖類、酵素		日本	8ヶ月	14902110348016	4902110348019					\N	254	230	\N	510	75	360	\N	160	0
129	2022-03-20 05:10:18.781358+00	2022-03-24 23:32:29.789504+00	ミシェーラ ナポリ風ピッツァミックス	\N	348270	348270	\N	「本格ピッツァ＝石窯」の常識を覆すピッツァミックス。300～350℃のオーブンでも本格的なナポリ風ピッツァができます。数種類の小麦粉をブレンドし、クラストに香ばしさと甘さが引き立ちます。	t	f	\N			2分30秒	300～350℃	50%＋ドライイースト	\N	\N	7kg	乳化剤、酵素		日本	6ヶ月	\N	4902110348279					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
128	2022-03-20 05:10:18.781358+00	2022-03-24 23:31:32.316245+00	イースト不要！ベルギーワッフルミックス	\N	348200	348200	\N	イーストが不要、発酵不要なのに、短時間で風味豊かなワッフルが焼き上がります。パールシュガーやあられ糖を加えるのが一般的です。パン生地タイプで、リエージュタイプともいいます。	t	f	\N			2分30秒	180℃	牛乳60％＋卵25%＋バター20%	\N	\N	1kg×10	ベーキングパウダー、乳化剤、香料		日本	6ヶ月	14902110348207	4902110348200					\N	310	230	\N	390	40	320	\N	225	0
127	2022-03-20 05:10:18.781358+00	2022-03-24 23:29:33.567545+00	ふわふわ食感！ソフトワッフルミックス	\N	348190	348190	\N	起泡性乳化油脂やSPが不要なのに、ふんわりと口溶けの良い食感のワッフルが焼き上がります。クリーム等をサンドしても背折れしにくいワッフルです。ケーキ生地タイプで、アメリカンタイプともいいます。	t	f	\N			3分	180℃	50%＋卵80%＋サラダ油10%	\N	\N	1kg×10	乳化剤、加工でん粉、ベーキングパウダー、増粘剤（キサンタンガム）、着色料（アナトー、ビタミンB₂）		日本	6ヶ月	14902110348191	4902110348194					\N	310	220	\N	390	40	320	\N	225	0
126	2022-03-20 05:10:18.781358+00	2022-03-24 23:28:35.912869+00	サクサク食感！クリスピーワッフルミックス	\N	348180	348180	\N	水と油を混ぜるだけの簡単ハンドリングで、サクっとした食感のワッフルが焼き上がります。焼きムラの少ない、ボリューム感のある	t	f	\N			5分	180℃	115%＋サラダ油6%	\N	\N	1kg×10	ベーキングパウダー、乳化剤、香料		日本	6ヶ月	14902110348184	4902110348187					\N	310	220	\N	390	40	320	\N	225	0
124	2022-03-20 05:10:18.781358+00	2022-03-24 23:26:20.453695+00	水1リットルでできる蒸しパンミックス（白）	\N	348250	348250	\N	水１リットルと混ぜて蒸すだけの簡単調理で、ボリュームのあるしっとりとした食感の蒸しパンに仕上がります。甘さ控えめなので、多彩なアレンジが可能です。	t	f	\N			約25分	100℃	80%	\N	\N	1.25kg×8	ベーキングパウダー、乳化剤、香料、マリーゴールド色素		日本	12ヶ月	14902110348252	4902110348255					\N	255	165	\N	509	40	320	\N	200	0
167	2022-03-20 05:10:18.781358+00	2022-03-23 05:42:12.749956+00	Rスパゲティ 1.7mm【湯せんタイプ】	\N	387960	387960	\N		t	f	\N			約30秒			\N	\N	(250g×5)×4×2			日本	12ヶ月	34902110387965	\N					\N	351	119x2	\N	411	100	170	\N	190	0
166	2022-03-20 05:10:18.781358+00	2022-03-23 05:42:31.005036+00	Rスパゲティ 1.7mm【湯せんタイプ】	\N	387950	387950	\N	湯せんに最適な形状を追求し、作業性向上を実現しました。コシの強さやおいしさは変わりません。	t	f	\N			約30秒			\N	\N	(200g×5)×4×2			日本	12ヶ月	34902110387958	\N					\N	351	119x2	\N	366	100	170	\N	180	0
165	2022-03-20 05:10:18.781358+00	2022-03-25 00:40:31.6846+00	マッシモプレミオ 冷凍スパゲティ《塩ゆで》	\N	353100	353100	\N	小麦の挽き方から乾燥工程まで、製法にこだわった乾麺「マッシモプレミオ＃201」を使用。風味や色調が良く、歯ごたえがあります。	t	f	\N			約30秒			\N	\N	(220g×5)×4×2			日本	12ヶ月	34902110353106	4902110353105					\N	330	130x2	\N	370	121	162	\N	182	0
164	2022-03-20 05:10:18.781358+00	2022-03-25 00:40:06.84521+00	ラウンドアップスパゲティ 1.7mm PREMIUM《塩ゆで》	\N	387690	387690	\N	厳選したプレミアム小麦を配合し、アルデンテのしっかりした歯ごたえと、彩り鮮やかな色味が特徴です。また、時間が経っても美味しさが長持ちします。	t	f	\N			約30秒			\N	\N	(220g×5)×4×2			日本	12ヶ月	34902110387699	4902110387698					\N	330	130x2	\N	370	121	162	\N	182	0
163	2022-03-20 05:10:18.781358+00	2022-03-25 00:39:33.224741+00	ラウンドアップスパゲティ 太麺タイプ 2.2mm《塩ゆで》	\N	353180	353180	\N	2.2mmのスパゲティが約30秒で茹で上がる。茹で上げの美味しさを再現した、もちもちした弾力ある食感。	t	f	\N			約30秒			\N	\N	(220g×5)×4×2			日本	12ヶ月	34902110353182	4902110353181					\N	320	130x2	\N	390	121	162	\N	192	0
162	2022-03-20 05:10:18.781358+00	2022-03-25 00:39:03.506751+00	ラウンドアップスパゲティ 1.4mm《塩ゆで》	\N	353140	353140	\N	細麵でも茹で伸びせず、コシの強さや噛みごたえはそのまま。	t	f	\N			約30秒			\N	\N	(220g×5)×4×2	加工でん粉、炭酸カリウム、増粘多糖類、食塩		日本	12ヶ月	34902110353144	4902110353143					\N	330	130x2	\N	355	121	162	\N	182	0
161	2022-03-20 05:10:18.781358+00	2022-03-25 00:38:34.768365+00	ラウンドアップスパゲティ Super Hardタイプ 1.6mm《塩ゆで》　250g	\N	353060	353060	\N		t	f	\N			約30秒			\N	\N	(250g×5)×4×2	加工でん粉、炭酸カリウム、増粘多糖類、食塩		日本	12ヶ月	34902110353069	4902110353068					\N	330	130x2	\N	390	121	162	\N	192	0
160	2022-03-20 05:10:18.781358+00	2022-03-25 00:38:04.825339+00	ラウンドアップスパゲティ Super Hardタイプ 1.6mm《塩ゆで》　220g	\N	353050	353050	\N		t	f	\N			約30秒			\N	\N	(220g×5)×4×2	加工でん粉、炭酸カリウム、増粘多糖類、食塩		日本	12ヶ月	34902110353052	4902110353051					\N	330	130x2	\N	370	121	162	\N	182	0
158	2022-03-20 05:10:18.781358+00	2022-03-25 00:36:22.847749+00	タリオリーニ（卵入り）	\N	353250	353250	\N	卵を配合し、風味とモチモチ感のある細目平打ち麺です。幅広いメニューにご使用いただけます。麺幅約３mm。	t	f	\N			約30秒			\N	\N	(200g×5)×4×2	加工でん粉、食塩		日本	12ヶ月	34902110353250	4902110353259					\N	330	130x2	\N	380	121	162	\N	182	0
155	2022-03-20 05:10:18.781358+00	2022-03-25 00:34:32.654184+00	リングイネ	\N	353220	353220	\N	すずめの舌の形状のように、楕円形をしたパスタです。丸い形状のスパゲティ類にない、独特の食感を生み出します。麺幅約2.8mm。	t	f	\N			約30秒			\N	\N	(200g×5)×4×2	加工でん粉、食塩		日本	12ヶ月	34902110353229	4902110353228					\N	330	130x2	\N	380	121	162	\N	182	0
154	2022-03-20 05:10:18.781358+00	2022-03-25 00:33:55.383965+00	スパゲッティーニ	\N	353210	353210	\N	丸麺でソースの自由度が高いパスタです。弾力のある食感が魅力。麺幅約1.8mm。	t	f	\N			約30秒			\N	\N	(200g×5)×4×2	加工でん粉、食塩		日本	12ヶ月	34902110353212	4902110353211					\N	330	130x2	\N	380	121	162	\N	182	0
153	2022-03-20 05:10:18.781358+00	2022-03-25 00:33:17.01695+00	マッシモ プレミオ #201　1.7	\N	364750	364750	\N		t	f	\N			8分			\N	\N	4kg×4			日本	36ヶ月	14902110364757	4902110364750					\N	279	159	\N	412	60	260	\N	320	0
152	2022-03-20 05:10:18.781358+00	2022-03-25 00:32:50.327792+00	マッシモ プレミオ #201　1.7	\N	364720	364720	\N		t	f	\N			8分			\N	\N	1kg×15			日本	36ヶ月	14902110364726	4902110364729					\N	282	149	\N	412	20	120	\N	320	0
151	2022-03-20 05:10:18.781358+00	2022-03-25 00:32:21.550583+00	マッシモ プレミオ #201　1.5	\N	364730	364730	\N		t	f	\N			6分			\N	\N	4kg×4			日本	36ヶ月	14902110364733	4902110364736					\N	279	159	\N	412	60	260	\N	320	0
150	2022-03-20 05:10:18.781358+00	2022-03-25 00:31:52.869742+00	マッシモ プレミオ #201　1.5	\N	364740	364740	\N	デュラムセモリナ100％の製品。色調と風味がやや強く、粘性・弾性も優れています。表面がとても滑らかで硬さの強い食感が魅力です。経時変化が少なく、ハーフボイル、茹でたて両方のハンドリングに対応でき、温製メニューのほか惣菜弁当用にも適しています。	t	f	\N			6分			\N	\N	1kg×15			日本	36ヶ月	14902110364740	4902110364743					\N	282	149	\N	412	20	120	\N	320	0
149	2022-03-20 05:10:18.781358+00	2022-03-25 00:29:08.973824+00	マ・マー ミニスパゲティ　ミニ1.7	\N	395920	395920	\N		t	f	\N			8分			\N	\N	4kg×4			トルコ	36ヶ月	14902110395928	4902110395921					\N	286	158	\N	421	140	135	\N	305	0
148	2022-03-20 05:10:18.781358+00	2022-03-25 00:25:53.244848+00	マ・マー ミニスパゲティ　ミニ1.6	\N	395910	395910	\N	デュラムセモリナ100％の製品。マ・マースパゲティを半分の長さにカットし、調理、加工適性をアップしました。太さは1.6ミリ、1.7ミリを揃えました。用途に合わせてお使い下さい。	t	f	\N			7分			\N	\N	4kg×4			トルコ	36ヶ月	14902110395911	4902110395914					\N	286	158	\N	421	140	135	\N	305	0
147	2022-03-20 05:10:18.781358+00	2022-03-25 00:22:09.950247+00	マ・マーTHE　PRO早ゆでスパゲティ1.6mm	\N	271440	271440	\N	デュラムセモリナ100％の製品。当社独自の「早ゆで・スーパープロント製法」により、茹で時間たったの３分で提供できるスパゲティです。フライパン煽り・レンジ調理が可能な為、様々な用途でご使用いただけます。	t	f	2022-05-31 15:00:00+00			3分			\N	\N	2.5kg×4			トルコ	36ヶ月	14902110271444	4902110271447					\N	253	234	\N	283	50	270	\N	330	0
146	2022-03-20 05:10:18.781358+00	2022-03-25 00:09:47.201884+00	マ・マー 早ゆでスパゲティ プロント 2.2mm	\N	343980	343980	\N	デュラムセモリナ100％の製品。独自の製法により４カ所に切れ込みを入れたことで、早ゆでとアルデンテの両立を実現しました。	t	f	\N			8分			\N	\N	2.5kg×4			日本	36ヶ月	14902110343981	4902110343984					\N	279	159	\N	412	60	260	\N	320	0
145	2022-03-20 05:10:18.781358+00	2022-03-25 00:06:50.480412+00	早ゆでスパゲティプロント 1.6mm	\N	368850	368850	\N		t	f	\N			3分			\N	\N	2.5kg×4			トルコ	36ヶ月	14902110360391	4902110360394					\N	255	238	\N	285	60	260	\N	320	0
144	2022-03-20 05:10:18.781358+00	2022-03-24 23:59:28.567239+00	早ゆでスパゲティプロント 1.6mm	\N	361960	361960	\N	デュラムセモリナ100％の製品。当社独自の「早ゆで・スーパープロント製法」により、パスタ本来のおいしさはそのままに茹で時間を短縮しました。茹で上げの美味しさを茹で時間たったの３分で提供できるスパゲティです。	t	t	\N			3分			\N	\N	500g×15			トルコ	36ヶ月	14902110361961	4902110361964					\N	288	159	\N	368	25	135	\N	340	0
170	2022-03-20 05:10:18.781358+00	2022-03-22 15:49:37.420265+00	MACARONI マカロニ 4.7-30	\N	300470	300470	\N	デュラムセモリナ100％の製品。硬さと粘弾性のバランスのとれたストレートタイプのマカロニです。サラダからグラタンまで幅広くご使用いただけます。	t	f	\N			10分			\N	\N	4kg×4			アメリカ	36ヶ月	14902110300472	4902110300475					\N	373	164	\N	557	85	430	\N	260	0
171	2022-03-20 05:10:18.781358+00	2022-03-22 15:50:38.088461+00	MACARONI ペンネリガーテ 7-25	\N	344490	344490	\N	デュラムセモリナ100％の製品。ペン先型をしたマカロニ料理用です。ペンネアラビアータやグラタン料理にも最適です。	t	f	\N			11分			\N	\N	3kg×4			アメリカ	36ヶ月	14902110344490	4902110344493					\N	373	151	\N	548	75	410	\N	280	0
182	2022-03-20 05:10:18.781358+00	2022-03-25 01:19:59.658994+00	IQF（バラ凍結）カサレッチャ	\N	290280	290280	\N	断面がS字形のシチリア発祥のショートパスタ。豆のソースとの相性が良く、ミートソースにもおすすめです。	t	t	\N			30秒			\N	\N	500g×12×2	加工でん粉、アルギン酸エステル		日本	12ヶ月	34902110290289	4902110290288					\N	352	199x2	\N	406	40	270	\N	190	0
181	2022-03-20 05:10:18.781358+00	2022-03-25 01:20:40.680702+00	IQF（バラ凍結）リガトーニ	\N	290230	290230	\N	表面に溝が入った、太めの筒状ショートパスタです。ソースののりがよく食べ応えがあります。濃厚なソースに良く合います。	t	t	\N			30秒			\N	\N	500g×12×2	加工でん粉、アルギン酸エステル		日本	12ヶ月	34902110290234	4902110290233					\N	352	199x2	\N	406	40	270	\N	190	0
180	2022-03-20 05:10:18.781358+00	2022-03-25 01:21:19.604365+00	IQF（バラ凍結）フィジリ	\N	290220	290220	\N	らせん状の形をしたパスタです。グルグルとねじれた溝にソースが程よくからみます。シンプルなオイル系から濃厚なクリーム系まで様々なソースとよく合います。	t	t	\N			30秒			\N	\N	500g×12×2	加工でん粉、アルギン酸エステル		日本	12ヶ月	34902110290227	4902110290226					\N	352	199x2	\N	406	40	270	\N	190	0
178	2022-03-20 05:10:18.781358+00	2022-03-23 05:38:34.590114+00	MACARONI ツイスト	\N	330690	330690	\N	ねじれた形のマカロニ。サラダ、グラタン、シチューなどにお使い下さい。デュラムセモリナ100％の製品です。	t	f	\N			9分			\N	\N	4kg×4			アメリカ	36ヶ月	14902110330691	4902110330694					\N	373	205	\N	557	70	460	\N	280	0
177	2022-03-20 05:10:18.781358+00	2022-03-23 05:39:16.378938+00	MACARONI シェルスモール	\N	330670	330670	\N	貝殻の形をした、小型のマカロニ。スープの浮き実や、サラダなどにお使い下さい。デュラムセモリナ100％の製品です。	t	f	\N			7分			\N	\N	4kg×4			アメリカ	36ヶ月	14902110330677	4902110330670					\N	373	175	\N	557	65	480	\N	280	0
175	2022-03-20 05:10:18.781358+00	2022-03-23 05:40:28.718016+00	MACARONI 野菜入りクルル	\N	300040	300040	\N	トマト、ほうれん草、にんじんの３種の野菜粉末だけで色をつけたカラフルなマカロニです。サラダ料理のバリエーションを広げます。	t	f	\N			9分			\N	\N	1kg×12			アメリカ	36ヶ月	14902110300045	4902110300048					\N	344	251	\N	514	60	350	\N	210	0
176	2022-03-20 05:10:18.781358+00	2022-03-23 05:39:55.516243+00	MACARONI シェル	\N	330660	330660	\N	貝殻の形をしたマカロニ。サラダ、グラタン、シチューなどにお使い下さい。デュラムセモリナ100％の製品です。	t	f	\N			15分			\N	\N	4kg×4			アメリカ	36ヶ月	14902110330660	4902110330663					\N	373	183	\N	557	65	480	\N	280	0
174	2022-03-20 05:10:18.781358+00	2022-03-23 05:40:48.780728+00	MACARONI デリカ201 クルル 9-15	\N	344390	344390	\N	クルルを１/２サイズの長さにした加工適性に優れたマカロニです。サラダなどにお使い下さい。	t	f	\N			8分			\N	\N	3kg×4			アメリカ	36ヶ月	14902110344391	4902110344394					\N	368	176	\N	548	75	410	\N	280	0
173	2022-03-20 05:10:18.781358+00	2022-03-23 05:41:17.109104+00	MACARONI クルル	\N	344420	344420	\N	デュラムセモリナ100％の製品。らせん形のマカロニです。ソースで和えたり、サラダ、グラタン、シチューなどにお使い下さい。	t	f	\N			8分			\N	\N	3kg×4			アメリカ	36ヶ月	14902110344421	4902110344424					\N	364	229	\N	545	85	410	\N	280	0
172	2022-03-20 05:10:18.781358+00	2022-03-23 05:41:29.554111+00	MACARONI サラダマカロニ	\N	361250	361250	\N	ワインコルクの栓抜きを型どったマカロニ。サラダ、グラタン、シチューなどにお使い下さい。デュラムセモリナ100％の製品です。	t	f	\N			10分			\N	\N	3kg×4			アメリカ	36ヶ月	14902110361251	4902110361254					\N	373	160	\N	557	85	410	\N	280	0
169	2022-03-20 05:10:18.781358+00	2022-03-23 05:41:41.388533+00	MACARONI ブラウン 4-40	\N	330640	330640	\N	デュラムセモリナ100％の製品。コシがあり、茹耐性が強く、茹で上がった後のボリューム感が特長です。	t	f	\N			10分			\N	\N	4kg×4			アメリカ	36ヶ月	14902110330646	4902110330649					\N	373	164	\N	557	65	500	\N	280	0
189	2022-03-20 05:10:18.781358+00	2022-03-25 01:14:00.304153+00	PASTA STELLA クリーミーカルボナーラ	\N	290070	290070	\N	生クリームとチーズ、卵黄で仕上げた濃厚な味わいのソースに、ショルダーベーコンとブロッコリーのトッピング。麺はプリプリとした弾力の太さ1.7mmのスパゲティです。	t	f	\N			約2分	1500W		\N	\N	320g×8×4	増粘剤（加工でん粉、増粘多糖類）、調味料（アミノ酸等）、乳化剤、リン酸塩(Na)、カゼインNa、pH調整剤、香料、カロチン色素、発色剤（亜硝酸Na）		日本	12ヶ月	34902110290074	4902110290073					\N	320	155x2	\N	210x2	25	140	\N	250	0
188	2022-03-20 05:10:18.781358+00	2022-03-25 01:15:02.01038+00	PASTA STELLA 和風たらこ	\N	290080	290080	\N	かつお節の一番だしと別添のきざみのりで、風味豊かな味わいを実現しました。	t	f	\N			約1分40秒	1500W		\N	\N	265g×8×4	調味料（アミノ酸等）、増粘剤（加工でん粉、増粘多糖類）、乳化剤、香料、紅麹色素、pH調整剤、		日本	12ヶ月	34902110290081	4902110290080					\N	320	155x2	\N	210x2	25	140	\N	250	0
187	2022-03-20 05:10:18.781358+00	2022-03-25 01:15:33.880674+00	PASTA STELLA ソテーナポリタン	\N	290030	290030	\N	香ばしい炒め感が魅力。玉ねぎ、にんじんなどの野菜と、ケチャップの旨味あふれるソースに、粗挽きソーセージとピーマンのトッピング。麺は食べ応えのある太さ2.2mmの太麺スパゲティです。	t	f	\N			約1分50秒	1500W		\N	\N	320g×8×4	調味料（アミノ酸等）、増粘剤（加工でん粉、増粘多糖類）、パプリカ色素、リン酸塩（Na）、乳化剤、カラメル色素、発色剤（亜硝酸Na）、くん液、いため油（ショートニング）／乳化剤		日本	12ヶ月	34902110290036	4902110290035					\N	320	155x2	\N	210x2	25	140	\N	250	0
183	2022-03-20 05:10:18.781358+00	2022-03-25 01:19:07.592077+00	IQF（バラ凍結）パッケリ	\N	290290	290290	\N	南イタリア発祥の大きなチューブ形状のショートパスタ。濃厚な肉のラグーソースがおすすめです。ナポリなどでは具材を詰めて使われることもあります。	t	t	\N			30秒			\N	\N	400g×12×2	加工でん粉、アルギン酸エステル		日本	12ヶ月	34902110290296	4902110290295					\N	352	199x2	\N	406	40	270	\N	190	0
244	2022-03-20 05:10:18.781358+00	2022-03-23 05:17:39.909421+00	No.88 Casareccia（カサレッチャ）	\N	368500	368500	\N	断面が」S字形のシチリア発祥のショートパスタです。豆のソースとの相性が良く、ミートソースにもお勧めです。	t	f	\N			11分			\N	\N	500g×24			イタリア	36ヶ月	\N	8001250120885					\N	238	292	\N	508	45	240	\N	140	0
200	2022-03-20 05:10:18.781358+00	2022-03-25 01:08:20.183775+00	N付け合せ用 ナポリタン	\N	333770	333770	\N	色鮮やかで、付け合わせにピッタリのナポリタンスパゲティ。盛り付けやすいハーフサイズのパスタを使用。小ロットのお弁当にも使いやすい300g入りです。	t	f	\N			①約30分<br>\r\n②約1分30秒	①100℃<br>\r\n②1500W		\N	\N	(300g×2食入り)×6×3	増粘剤(加工でん粉、キサンタンガム)、調味料(アミノ酸等)、着色料(カラメル)		日本	12ヶ月	34902110333771	4902110333770					\N	221	159x3	\N	376	65	150	\N	200	0
198	2022-03-20 05:10:18.781358+00	2022-03-25 01:09:23.277106+00	N惣菜用 焼きスパゲティ ナポリタン《2.2mm》	\N	333740	333740	\N	解凍後、そのまま提供できるよう具材をトッピングした１人前用。売り場で目立つ色鮮やかなソースと2.2mmの太麺をソテーしています。	t	f	\N			①約20分<br>\r\n②約1分40秒	①100℃<br>\r\n②1500W		\N	\N	(230g×2食入り)×6×3	調味料（アミノ酸等）、増粘剤（加工でん粉、増粘多糖類）、着色料(パプリカ色素、カラメル)、リン酸塩(Na)、香料、発色剤(亜硝酸Na)、いため油(ショートニング)、乳化剤		日本	12ヶ月	34902110333740	4902110333749					\N	206	179x3	\N	306	55	150	\N	200	0
197	2022-03-20 05:10:18.781358+00	2022-03-25 01:09:51.444681+00	レンジ用スパゲティ プレーン	\N	382390	382390	\N	レンジ調理で、アルデンテの茹で上がりを再現。1.7mmの乾麺を使用し、下味をつけています。様々なソースと組み合わせれば、多彩なメニューが提供できます。	t	f	\N			約1分強	1500W		\N	\N	220g×20×2	増粘多糖類		日本	12ヶ月	34902110382397	\N					\N	330	130x2	\N	340	25	165	\N	250	0
195	2022-03-20 05:10:18.781358+00	2022-03-25 01:10:47.344457+00	レンジ用スパゲティ ミートソース	\N	387710	387710	\N	牛肉を使用した味わい深いミートソーススパゲティです。デミグラスソースを配合したミートソースです。	t	f	\N			約2分10秒	1500W		\N	\N	310g×12×2	増粘剤（加工でん粉、増粘多糖類）、調味料（アミノ酸等）、着色料(カラメル)、乳化剤、キシロース、ビタミンB₁、香料		日本	12ヶ月	34902110387712	4902110387711					\N	236	139x2	\N	396	25	165	\N	250	0
194	2022-03-20 05:10:18.781358+00	2022-03-25 01:11:14.072384+00	レンジ用スパゲティ カルボナーラ	\N	321390	321390	\N	クリーミーなカルボナーラソースにベーコンをトッピング、ブラックペッパーをアクセントにしています。	t	f	\N			約2分	1500W		\N	\N	300g×12×2	増粘剤（加工でん粉、増粘多糖類）、グリシン、調味料（アミノ酸等）、乳化剤、リン酸塩(Na)、酢酸Na、カゼインNa、pH調整剤、香料、発色剤（亜硝酸Na）、着色料(カロチン)		日本	12ヶ月	34902110321396	4902110321395					\N	236	139x2	\N	396	25	165	\N	250	0
192	2022-03-20 05:10:18.781358+00	2022-03-25 01:12:12.788286+00	PASTA STELLA ポルチーニクリーム	\N	290050	290050	\N	ポルチーニの芳醇な香り、生クリームとチーズのコクを加えた濃厚で旨みのあるソースに、ベーコンとぶなしめじのトッピング。平たくて幅広のパスタ「フェットチーネ」使用。	t	f	\N			約1分30秒	1500W		\N	\N	270g×8×4	増粘剤（加工でん粉、増粘多糖類）、調味料（アミノ酸等）、カラメル色素、乳化剤、リン酸塩(Na)、pH調整剤、カゼインNa、発色剤（亜硝酸Na）、香料、くん液		日本	12ヶ月	34902110290050	4902110290059					\N	320	155x2	\N	210x2	25	140	\N	250	0
191	2022-03-20 05:10:18.781358+00	2022-03-25 01:12:44.640895+00	PASTA STELLA 濃厚海老トマトクリーム	\N	290060	290060	\N	アメリケーヌソースを使用し、えびの旨味あふれる味わい。ソースとの絡みが良く、もちもち食感の平たくて幅広のパスタ「フェットチーネ」使用。	t	f	\N			約1分50秒	1500W		\N	\N	275g×8×4	調味料（アミノ酸等）、増粘剤（加工でん粉、増粘多糖類）、pH調整剤、乳化剤、カゼインNa、リン酸塩(Na)		日本	12ヶ月	34902110290067	4902110290066					\N	320	155x2	\N	210x2	25	140	\N	250	0
201	2022-03-20 05:10:18.781358+00	2022-03-25 01:07:54.245793+00	N付け合せ用 塩バター	\N	333780	333780	\N	パセリの緑色が効いたスパゲティ。付け合せはもちろん、そのままでも一品となる塩バター風味です。盛り付けやすいハーフサイズのパスタを使用。	t	f	\N			①約30分<br>\r\n②約1分30秒	①100℃<br>\r\n②1500W		\N	\N	(300g×2食入り)×6×3	調味料（アミノ酸等）、増粘剤（キサンタンガム）		日本	12ヶ月	34902110333788	4902110333787					\N	221	159x3	\N	376	65	150	\N	200	0
196	2022-03-20 05:10:18.781358+00	2022-03-25 01:10:18.242015+00	レンジ用スパゲティ たらこと舞茸	\N	321420	321420	\N	たらこ風味豊かな和風仕立てのソース。舞茸をトッピングし、食感にアクセントを加えました。	t	f	\N			約1分40秒	1500W		\N	\N	250g×12×2	増粘剤（加工でん粉、増粘多糖類）、調味料（アミノ酸等）、着色料（紅麴）、香料、乳化剤		日本	12ヶ月	34902110321426	4902110321425					\N	236	139x2	\N	396	25	165	\N	250	0
190	2022-03-20 05:10:18.781358+00	2022-03-25 01:13:21.924502+00	PASTA STELLA クリーミーボロネーゼ	\N	290040	290040	\N	じっくり煮込んだミートソースと、クリームソースをあわせた濃厚でクリーミーな味わいのソースに、まいたけのトッピング。細めの平麵パスタ「タリオリーニ」使用。	t	f	\N			約1分50秒	1500W		\N	\N	275g×8×4	増粘剤（加工でん粉、増粘多糖類）、調味料（アミノ酸等）、カラメル色素、乳化剤、カゼインNa、pH調整剤、リン酸塩(Na)、キシロース、ビタミンB₁、香料		日本	12ヶ月	34902110290043	4902110290042					\N	320	155x2	\N	210x2	25	140	\N	250	0
185	2022-03-20 05:10:18.781358+00	2022-03-25 01:17:00.658218+00	マ・マー THE PRO IQF（バラ凍結）MINI ストレートマカロニ	\N	290440	290440	\N	ストレートタイプの小型マカロニ。スプーンにのっかるサイズで、スープやサラダ､ガロニ等の副菜や小鉢メニューとしてご使用いただけます。ソフトな食感で、お子様から年配の方まで幅広い層におすすめです。	t	t	2022-02-28 15:00:00+00			30秒			\N	\N	500g×12×2	加工でん粉、アルギン酸エステル		日本	12ヶ月	34902110290449	4902110290448					\N	352	199x2	\N	406	40	270	\N	190	0
217	2022-03-20 05:10:18.781358+00	2022-03-25 00:56:50.062332+00	ナポリタンソース	\N	386580	386580	\N	野菜の甘さとトマトの酸味がしっかりとした味わいのソースです。太麺と合わせても色鮮やかです。	t	f	\N			約5分			\N	\N	(120g×5)×4×2	調味料（アミノ酸等）、乳化剤、増粘剤（加工でん粉、キサンタンガム）、パプリカ色素、リン酸塩(Na)、カラメル色素、発色剤(亜硝酸Na)		タイ	12ヶ月	34902110386586	4902110386585					\N	188	165x2	\N	288	\N	180	\N	150	0
216	2022-03-20 05:10:18.781358+00	2022-03-25 00:57:38.279608+00	ボロネーゼ	\N	386610	386610	\N	牛肉・豚肉と野菜を煮込んで素材のおいしさを引き出しました。バターと赤ワインを使用し、コク深く仕上げています。	t	f	\N			約5分			\N	\N	(140g×5)×4×2	増粘剤（加工でん粉）、カラメル色素、調味料（アミノ酸等）、キシロース、酸味料		タイ	12ヶ月	34902110386616	4902110386615					\N	188	165x2	\N	288	\N	180	\N	150	0
215	2022-03-20 05:10:18.781358+00	2022-03-25 00:58:29.67169+00	HQクリームソース（1kg）	\N	378750	378750	\N	生クリームを使ったベシャメルソースに、チーズのコクを加えたソース。卵とベーコンを加えればカルボナーラにも。	t	f	\N			約20分			\N	\N	1kg×5×2	増粘剤（加工でん粉）		日本	12ヶ月	34902110378758	4902110378757					\N	206	154x2	\N	306	\N	300	\N	200	0
214	2022-03-20 05:10:18.781358+00	2022-03-25 00:59:18.273172+00	N HQポモドーロソース（1kg）	\N	386590	386590	\N	酸味と甘みのバランスがとれたトマトを使用。唐辛子入りのガーリックオイルの旨味、あめ色玉ねぎの甘味が一体となったトマトベースのソースです。	t	f	\N			約20分			\N	\N	1kg×5×2			タイ	12ヶ月	34902110386593	4902110386592					\N	208	175x2	\N	308	\N	300	\N	200	0
212	2022-03-20 05:10:18.781358+00	2022-03-25 01:00:26.27376+00	ミートソース	\N	395560	395560	\N		t	f	\N						\N	\N	1kg×6×2合	増粘剤（加工でん粉）、調味料（アミノ酸）、カラメル色素		タイ	18ヶ月	34902110395564	4902110395563					\N	240	260	\N	365	25	230	\N	350	0
211	2022-03-20 05:10:18.781358+00	2022-03-25 01:00:51.540665+00	ミートソース	\N	395680	395680	\N	良質の粗挽き肉と香味野菜を炒め、完熟トマトとともにじっくりと煮込んだ風味豊かなミートソースです。くせのない味なのでアレンジしやすくパスタ料理はもちろんピッツァ、グラタン、リゾットなどいろいろなメニューに活かせます。	t	f	\N						\N	\N	3kg×6	増粘剤（加工でん粉）、調味料（アミノ酸）、カラメル色素		タイ	24ヶ月	14902110332916	4902110332919					\N	321	187	\N	476	\N	155	\N	179	0
210	2022-03-20 05:10:18.781358+00	2022-03-25 01:01:20.875461+00	完熟トマトのソース	\N	375600	375600	\N	個食使い切りタイプ。魚介と鶏肉の旨み、数種の香辛料を加えて仕上げた、コク深いおいしさのトマトソース。鶏肉のトマト煮込みやラタトゥイユなどのメニューに使用可能です。	t	f	\N			3～5分			\N	\N	140g×12×４	増粘剤（加工でん粉）、調味料（アミノ酸等）、乳化剤、パプリカ色素、酸味料		タイ	18ヶ月	14902110375609	4902110375602					\N	283	182	\N	393	13	160	\N	125	0
209	2022-03-20 05:10:18.781358+00	2022-03-25 01:02:14.993029+00	ボロネーゼ	\N	331750	331750	\N	個食使い切りタイプ。挽き肉と香味野菜をしっかり炒めて旨味を引き出し、じっくり煮込んで仕上げたこだわりのコク深さです。	t	f	\N			3～5分			\N	\N	140g×12×４	増粘剤（加工でん粉）、カラメル色素、調味料（アミノ酸等）、キシロース、酸味料		タイ	18ヶ月	14902110331759	4902110331752					\N	283	182	\N	393	13	160	\N	125	0
208	2022-03-20 05:10:18.781358+00	2022-03-25 01:04:52.441449+00	テイクアウト用生パスタスパゲティ	\N	388930	388930	\N	時間が経っても伸びた食感になりにくい、テイクアウト用途に適した冷凍パスタです。湯せん３０秒で解凍するだけですぐ提供できます。\r\nテイクアウト用途だけでなく、即食用途でもご使用いただけます。	t	t	\N			約30秒			\N	\N	220g×5×4×2合	加工でん粉、アルギン酸エステル、着色料（カロチン）、食塩		日本	12ヶ月	34902110388931	4902110388930					\N	330	260	\N	370	121	162	\N	182	0
205	2022-03-20 05:10:18.781358+00	2022-03-25 01:06:20.899927+00	ペペロンチーニ	\N	290460	290460	\N	時間が経っても食感のあるパスタを使用し、売り場での見栄えがよく時間が経ってもおいしく食べられるソース配合としています。冷めた状態でもおいしくお召し上がりいただけます。	t	t	2022-02-28 15:00:00+00			約30分	100℃		\N	\N	330ｇ×12×2	調味料（アミノ酸等）、増粘剤（加工でん粉、増粘多糖類）、乳化剤、グリシン、酢酸Na、リン酸塩（Na)、pH調整剤、発色剤（亜硝酸Na）		日本	12ヶ月	34902110290463	4902110290462					\N	396	308x2	\N	236	40	240	\N	150	0
204	2022-03-20 05:10:18.781358+00	2022-03-25 01:06:45.076527+00	たらこ	\N	290190	290190	\N	時間が経っても食感のあるパスタを使用し、こんぶの風味がたらこの味わいを引き立てるソース配合としています。冷めた状態でもおいしくお召し上がりいただけます。	t	t	\N			約30分	100℃		\N	\N	330ｇ×12×2	増粘剤（加工でん粉、増粘多糖類）、調味料（アミノ酸等）、グリシン、香料、着色料(紅麴)、乳化剤、酢酸Na、pH調整剤		日本	12ヶ月	34902110290197	4902110290196					\N	396	154x2	\N	236	40	240	\N	150	0
203	2022-03-20 05:10:18.781358+00	2022-03-25 01:07:06.530426+00	和風きのこ	\N	290170	290170	\N	時間が経っても食感のあるパスタを使用し、きのこの味わいとかつおだしの風味が感じられるソース配合としています。冷めた状態でもおいしくお召し上がりいただけます。	t	t	\N			約30分	100℃		\N	\N	330ｇ×12×2	増粘剤（加工でん粉、増粘多糖類）、調味料（アミノ酸等）、グリシン、酢酸Na、乳化剤、pH調整剤、リン酸塩(Na)、発色剤(亜硝酸Na)		日本	12ヶ月	34902110290173	4902110290172					\N	396	154x2	\N	236	40	240	\N	150	0
202	2022-03-20 05:10:18.781358+00	2022-03-25 01:07:30.388992+00	ナポリタン	\N	290110	290110	\N	時間が経っても食感のあるパスタを使用し、ソースについても照り感がでる配合としています。冷めた状態でもおいしくお召し上がりいただけます。	t	t	\N			約30分	100℃		\N	\N	330ｇ×12×2	調味料（アミノ酸等）、増粘剤（加工でん粉、増粘多糖類）、着色料(カラメル、パプリカ色素)、乳化剤、リン酸塩(Na)、発色剤(亜硝酸Na)、くん液		日本	12ヶ月	34902110290111	4902110290110					\N	416	149x2	\N	226	40	240	\N	150	0
218	2022-03-20 05:10:18.781358+00	2022-03-25 00:55:52.113221+00	完熟トマトソース	\N	386600	386600	\N	イタリア産の完熟トマトを使用した、ほどよい酸味のさわやかなソース。さまざまな具材やクリーム系のソースとの相性も抜群です。	t	f	\N			約5分			\N	\N	(150g×5)×4×2	増粘剤（加工でん粉）、調味料（アミノ酸等）		タイ	12ヶ月	34902110386609	4902110386608					\N	188	165x2	\N	288	\N	180	\N	150	0
232	2022-03-20 05:10:18.781358+00	2022-03-22 20:57:17.932451+00	No.11 Spaghettini（スパゲッティーニ）	\N	368630	368630	\N	太さ1.6mm。ロングパスタの定番。多くのソースに合う万能タイプです。	t	f	\N			9分			\N	\N	500g×24			イタリア	36ヶ月	8001250001870	8001250001887					\N	178	282	\N	298	20	85	\N	310	0
233	2022-03-20 05:10:18.781358+00	2022-03-22 20:58:39.62617+00	No.11 Spaghettini（スパゲッティーニ）	\N	350750	350750	\N		t	f	\N			9分			\N	\N	1kg×12			イタリア	36ヶ月	\N	8001250160119					\N	178	282	\N	298	30	310	\N	110	0
235	2022-03-20 05:10:18.781358+00	2022-03-22 21:00:21.354416+00	No.12 Spaghetti（スパゲッティ）	\N	368750	368750	\N	太さ1.9mmのやや太めのパスタ。ボリューム感を出したい時や、コクのあるしっかりしたソースによく合います。	t	f	\N			12分			\N	\N	500g×24			イタリア	36ヶ月	8001250001894	8001250001900					\N	178	282	\N	298	20	85	\N	310	0
242	2022-03-20 05:10:18.781358+00	2022-03-23 05:18:20.310279+00	No.41 Penne Rigate（ペンネ リガーテ）	\N	368640	368640	\N	ペン先の形をしたパスタ。リガーテとは「表面に筋のついた」という意味で、この筋にソースが入り込んでよくからみ、様々なタイプのソースによく合います。	t	f	\N			12分			\N	\N	500g×24			イタリア	36ヶ月	\N	8001250120410					\N	238	292	\N	508	45	240	\N	145	0
241	2022-03-20 05:10:18.781358+00	2022-03-23 05:18:37.025614+00	No.34 Fusilli（フスィリ）	\N	368610	368610	\N	らせん状の形をしたパスタ。グルグルとねじれた溝にソースが程よくからみます。シンプルなオイル系から濃厚なクリーム系までさまざまなソースとよく合います。	t	f	\N			11分			\N	\N	500g×24			イタリア	36ヶ月	\N	8001250120342					\N	258	292	\N	548	45	270	\N	155	0
240	2022-03-20 05:10:18.781358+00	2022-03-23 05:19:00.940815+00	No.25 Mille righe（ミッレ リーゲ）	\N	368600	368600	\N	「千本の線」という意味の直径約12mmの太めの筒状ショートパスタ。表面に溝が入っているためソースののりがよく食べ応えがあります。生クリームやチーズをたっぷり使った濃厚なソースに良く合います。また、コクのあるソースで焼くグラタンにもお勧めです。	t	f	\N			13分			\N	\N	500g×24			イタリア	36ヶ月	\N	8001250120250					\N	258	332	\N	548	45	250	\N	155	0
239	2022-03-20 05:10:18.781358+00	2022-03-23 05:19:16.796567+00	No.170 Vermicelli（ヴェルミチェッリ）	\N	363460	363460	\N	ナポリ発祥の太めのスパゲッティ形状のロングパスタで、パスタの最も古い形状の一つと考えられています。北部イタリアでは、別の名称で呼ばれることがあります。トマトソースとの相性が良く、オイルベースのソース、魚介のソースもお勧めです。	t	f	\N			14分			\N	\N	500g×24			イタリア	36ヶ月	\N	8001250121707					\N	178	282	\N	298	20	320	\N	95	0
238	2022-03-20 05:10:18.781358+00	2022-03-23 05:19:38.343148+00	No.14 Bucatini Piccoli（ブカティーニ・ピッコリ）	\N	363420	363420	\N	ナポリ発祥の穴の空いたロングパスタです。バター、パンチェッタ、野菜、肉、チーズや卵のソースにお勧めです。	t	f	\N			8分			\N	\N	500g×24			イタリア	36ヶ月	\N	8001250120144					\N	178	282	\N	303	20	320	\N	105	0
237	2022-03-20 05:10:18.781358+00	2022-03-23 05:19:51.292886+00	No.13 Maccheroni alla Chitarra（マッケローニ・アッラ・キタッラ）	\N	363410	363410	\N	アブルッツォ発祥の断面が四角のロングパスタです。肉類のソースとの相性が良く、最も伝統的な料理は子羊のラグーです。	t	f	\N			10分			\N	\N	500g×24			イタリア	36ヶ月	\N	8001250120137					\N	178	282	\N	298	20	320	\N	95	0
236	2022-03-20 05:10:18.781358+00	2022-03-23 05:20:04.2717+00	No.12 Spaghetti（スパゲッティ）	\N	363220	363220	\N		t	f	\N			12分			\N	\N	5kg×2			イタリア	36ヶ月	\N	8001250170125					\N	235	175	\N	300	80	290	\N	300	0
234	2022-03-20 05:10:18.781358+00	2022-03-23 05:20:18.043395+00	No.11 Spaghettini（スパゲッティーニ）	\N	363210	363210	\N		t	f	\N			9分			\N	\N	5kg×2			イタリア	36ヶ月	\N	8001250170118					\N	235	175	\N	300	80	290	\N	300	0
231	2022-03-20 05:10:18.781358+00	2022-03-23 05:20:32.986259+00	No.10 Fedelini（フェデリーニ）	\N	363200	363200	\N		t	f	\N			6分			\N	\N	5kg×2			イタリア	36ヶ月	\N	8001250170101					\N	235	175	\N	300	80	290	\N	300	0
230	2022-03-20 05:10:18.781358+00	2022-03-23 05:20:48.405556+00	No.10 Fedelini（フェデリーニ）	\N	350850	350850	\N		t	f	\N			6分			\N	\N	1kg×12			イタリア	36ヶ月	\N	8001250160102					\N	178	282	\N	298	30	310	\N	110	0
229	2022-03-20 05:10:18.781358+00	2022-03-23 05:21:04.630135+00	No.10 Fedelini（フェデリーニ）	\N	368620	368620	\N	太さ1.4mmのやや細麺タイプ。トマト系からオイル系まで幅広いソースに合います。	t	f	\N			6分			\N	\N	500g×24			イタリア	36ヶ月	8001250001856	8001250001863					\N	178	282	\N	298	20	85	\N	310	0
227	2022-03-20 05:10:18.781358+00	2022-03-23 05:21:34.415217+00	No.8 Linguine piccole（リングイーネ ピッコレ）	\N	368580	368580	\N	リングイーネよりもやや幅が小さいタイプのパスタ。リングイーネ同様、麺が平たいのでソースがよくのり、弾力のある食感も特長です。	t	f	\N			8分			\N	\N	500g×24			イタリア	36ヶ月	8001250002440	8001250002433					\N	178	282	\N	298	20	85	\N	310	0
226	2022-03-20 05:10:18.781358+00	2022-03-23 05:21:55.810356+00	No.7 Linguine（リングイーネ）	\N	368790	368790	\N		t	f	\N			12分			\N	\N	5kg×2			イタリア	36ヶ月	\N	8001250170071					\N	235	175	\N	300	80	290	\N	300	0
225	2022-03-20 05:10:18.781358+00	2022-03-23 05:22:10.316063+00	No.7 Linguine（リングイーネ）	\N	368540	368540	\N	「小さな舌」という意味の断面が楕円型の平麺。麺が平たいのでソースがよくのり、弾力のある食感も特長です。	t	f	\N			12分			\N	\N	500g×24			イタリア	36ヶ月	8001250002426	8001250002419					\N	178	282	\N	298	20	85	\N	310	0
224	2022-03-20 05:10:18.781358+00	2022-03-23 05:22:26.849115+00	No.1 Lasagna（ラザーニャ）	\N	362990	362990	\N	平たい板状のパスタ。ベシャメッラソース、ミートソースに合わせるのがお勧めです。	t	f	\N			ボイル4分<br>\r\n（ベイク20分）			\N	\N	500g×20			イタリア	36ヶ月	\N	8001250110015					\N	377	205	\N	445	80	190	\N	90	0
207	2022-03-20 05:10:18.781358+00	2022-03-25 01:05:10.235132+00	マ・マーTHE PRO Smile Meal やさしい味わい 和風パスタ	\N	290480	290480	\N		t	t	2022-02-28 15:00:00+00			約25分	100℃		\N	\N	230g×12×2	増粘剤（加工でん粉、増粘多糖類）、乳化剤、調味料（アミノ酸等）、グリシン、酢酸Na、pH調整剤		日本	12ヶ月	34902110290487	4902110290486					\N	400	150x2	\N	220	23	250	\N	140	0
223	2022-03-20 05:10:18.781358+00	2022-03-25 00:51:03.952886+00	明太子ソース　（チューブ入・パスタ用）	\N	333690	333690	\N		t	f	\N				流水・冷蔵庫で解凍		\N	\N	240g×20×2	調味料（アミノ酸等）、酒精、紅麴色素、酢酸Na、増粘剤(キサンタンガム)、グリシン、甘味料(ステビア)、トウガラシ色素		日本	12ヶ月	34902110333696	4902110333695					\N	230	187x2	\N	282	\N	230	\N	100	0
254	2022-03-20 05:10:18.781358+00	2022-03-25 00:47:56.396508+00	No.41 Penne Rigate Organic（ペンネ リガーテ オーガニック）	\N	368830	368830	\N		t	f	\N			11分			\N	\N	500g×16			イタリア	36ヶ月	\N	8001250008800					\N	238	197	\N	508	45	240	\N	145	0
252	2022-03-20 05:10:18.781358+00	2022-03-25 00:49:00.15475+00	No.12 Spaghetti Organic（スパゲッティ オーガニック）	\N	368810	368810	\N		t	f	\N			12分			\N	\N	500g×24			イタリア	36ヶ月	\N	8001250008749					\N	178	282	\N	298	20	310	\N	85	0
250	2022-03-20 05:10:18.781358+00	2022-03-23 05:15:29.770325+00	No.310 Fettuccine con spinaci（フェットゥチーネ コン スピナーチ）	\N	362510	362510	\N	ホウレン草入りのフェットゥチーネ。緑色を生かして、トマトソースやクリームソースなどと合わせると美しい彩りになります。	t	f	\N			7分			\N	\N	250g×20			イタリア	24ヶ月	\N	8001250511072					\N	391	229	\N	386	75	145	\N	215	0
249	2022-03-20 05:10:18.781358+00	2022-03-23 05:15:59.222577+00	No.303 Fettuccine（フェットゥチーネ）	\N	363280	363280	\N	卵を練りこんだ幅広の平打ちパスタ。クリーム系やチーズ系、ミートソースなどのコクのあるソースとよく合います。	t	f	\N			7分			\N	\N	250g×20			イタリア	24ヶ月	\N	8001250243034					\N	391	229	\N	386	75	145	\N	215	0
248	2022-03-20 05:10:18.781358+00	2022-03-23 05:16:18.683387+00	No.125 Paccheri（パッケリ）	\N	363450	363450	\N	南部イタリアの大きなチューブ形状のショートパスタです。濃厚な肉のラグーソースがお勧めです。ナポリなどでは具材を詰めて使われることもあります。	t	f	\N			16分			\N	\N	500g×12			イタリア	36ヶ月	\N	8001250121257					\N	395	293	\N	497	95	265	\N	140	0
247	2022-03-20 05:10:18.781358+00	2022-03-23 05:16:39.547939+00	No.118 Zita Tagliata（ジータ・タリアータ）	\N	363480	363480	\N	南部イタリアのチューブ形状のショートパスタです。肉と野菜のラグーや、トマトソース、ピーマン、ナス、ズッキーニ、オリーブ、ケーパー入りの野菜ソースがお勧めです。	t	f	\N			11分			\N	\N	500g×24			イタリア	36ヶ月	\N	8001250121189					\N	258	312	\N	548	45	240	\N	155	0
255	2022-03-20 05:10:18.781358+00	2022-03-25 00:47:19.689125+00	冷凍パスタ No.11 Spaghettini（スパゲッティーニ）	\N	321120	321120	\N	ディ・チェコ原麺を使用した冷凍パスタ。太さ1.6mmの乾物スパゲッティーニを使用。どんなソースにも相性ピッタリです。	t	f	\N			①約30秒<br>\r\n②約50秒	①ボイル<br>\r\n②スチーム		\N	\N	(220g×5)×4×2			原料原産地：イタリア　製造地：日本	\N	34902110321129	4902110321128					\N	330	130x2	\N	390	121	162	\N	182	0
101	2022-03-20 05:10:18.781358+00	2022-03-24 22:49:52.186192+00	メンチカツ用ミックス #24-HU	\N	470850	470850	\N	衣と具材の結着が良好でサクみのある食感の衣に仕上がります。パン粉の付きも良好です。	t	f	\N		300%	約5分	170～180℃		\N	\N	10kg	増粘多糖類、加工でん粉、乳化剤		日本	\N	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
75	2022-03-20 05:10:18.781358+00	2022-03-24 22:26:49.832275+00	天ぷら粉　パックに入れてもかるサク衣	\N	271380	271380	\N	パックに入れてもサクっとかるい食感が長持ちする天ぷら粉です。黄色い揚げ色に仕上がり、べちゃつきや油っぽさを感じにくい為、テイクアウトや惣菜売場におすすめです。	t	t	2022-02-28 15:00:00+00		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	1kg×10	加工でん粉、ベーキングパウダー、乳化剤、増粘多糖類、着色料（マリーゴールド）		日本	12ヶ月	14902110271383	4902110271386					\N	255	175	\N	509	40	320	\N	210	0
67	2022-03-20 05:10:18.781358+00	2022-03-24 22:18:53.053507+00	天ぷら粉Aタイプ	\N	340020	340020	\N	花咲が良く、明るい白色に揚がり、しかもボリューム感のある、軽い食感が味わえる天ぷら粉。汎用タイプですので、独自の味付けにより、幅広くお使いいただけます。荷姿は２タイプ、用途に合わせてお使いください。	t	f	\N		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	10kg	ベーキングパウダー		日本	10ヶ月	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
58	2022-03-20 05:10:18.781358+00	2022-03-24 22:01:33.96205+00	天ぷら粉揚げ上手	\N	334510	334510	\N	カラッと揚がり、時間経過後もサクサクした食感が残る画期的な天ぷら粉。冷水で仕込みをする必要も無くハンドリングも簡単なため、天ぷらを揚げるのに必要とされていたコツもいりません。スーパーの惣菜用からレストランまで幅広くご使用いただけます。荷姿は２タイプ、用途に合わせてお選び下さい。	t	f	\N		160%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	1kg×10	加工でん粉、ベーキングパウダー、乳化剤、着色料（クチナシ、ビタミンB₂、アナトー）		日本	12ヶ月	14902110334514	4902110334517					\N	255	175	\N	509	40	310	\N	195	0
83	2022-03-20 05:10:18.781358+00	2022-03-24 22:29:46.967321+00	から揚げ粉	まぶしタイプ	337690	337690	\N	チキンエキスとねぎエキスのダブルの旨味をベースに、数種のスパイスと香味野菜をきかせた、香り高く深い味わい。まぶすだけでから揚げ本来のおいしさであるジューシーさを保ちます。しかも粉落ちが抑えられますので油汚れも少なくてすみます。	t	f	\N			約4分	160～170℃		\N	\N	1kg×10	調味料（アミノ酸等）、乳化剤、パプリカ色素、香辛料抽出物		日本	24ヶ月	14902110337690	4902110337693					\N	310	200	\N	390	40	330	\N	225	0
54	2022-03-20 05:10:18.781358+00	2022-03-24 21:57:43.141909+00	天ぷら粉打ち粉いらずの揚げ上手	\N	395080	395080	\N	打ち粉をする作業が省けます。また、軽くゆすって揚げるだけで、追いバッターも必要がない画期的な天ぷら粉です。保存に便利なチャック付きです。	t	f	\N		140%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	1kg×10	加工でん粉、ベーキングパウダー、トレハロース、乳化剤、マリーゴールド色素		日本	12ヶ月	14902110395089	4902110395082					\N	255	175	\N	509	40	320	\N	210	0
119	2022-03-20 05:10:18.781358+00	2022-03-24 23:20:36.11978+00	達人厨房 しっとりパンケーキMIX	\N	351050	351050	\N	薄生地のパンケーキはしっとり、厚手のホットケーキはふっくら。甘さ控えめのヘルシーなおいしさで、食事メニューからデザートメニューまで、幅広いアレンジが可能です。	t	f	\N			片面2分、反転1.5分	180℃	900％+卵250g+サラダ油50ml	\N	\N	1kg×10	ベーキングパウダー、加工でん粉、乳化剤、香料		日本	12ヶ月	14902110351054	4902110351057					\N	255	175	\N	509	40	310	\N	190	0
253	2022-03-20 05:10:18.781358+00	2022-03-25 00:48:46.62497+00	No.34 Fusilli Organic（フスィリ オーガニック）	\N	368820	368820	\N		t	f	\N			11分			\N	\N	500g×16			イタリア	36ヶ月	\N	8001250008787					\N	258	222	\N	548	45	270	\N	155	0
246	2022-03-20 05:10:18.781358+00	2022-03-23 05:17:08.544564+00	No.93 Farfalle（ファルファーレ）	\N	368700	368700	\N	「蝶々」という名の結んだリボン形状のパスタ。結び目のもっちりとした弾力と平たい部分との食感の違いが楽しめます。ひだの部分にソースがよく絡み、サラダにもお勧めです。	t	f	\N			13分			\N	\N	500g×24			イタリア	36ヶ月	\N	8001250120939					\N	258	352	\N	548	55	260	\N	145	0
228	2022-03-20 05:10:18.781358+00	2022-03-23 05:21:18.894513+00	No.9 Capellini（カッペリーニ）	\N	368590	368590	\N	その細さを「髪の毛」(capelli)に喩えたところからそう呼ばれる太さ0.9mmの極細パスタ。冷製パスタにおすすめ。ソースとのからみ具合も抜群。スープの具にも適しています。	t	f	\N			2分			\N	\N	500g×24			イタリア	36ヶ月	8001250001832	8001250001849					\N	178	282	\N	298	20	85	\N	310	0
219	2022-03-20 05:10:18.781358+00	2022-03-25 00:54:53.154251+00	ポルチーニクリームソース	\N	385730	385730	\N	香り高いポルチーニクリームソースに、ベーコンと、エリンギ、まいたけの２種のきのこを加え、味わい深く仕上げています。	t	f	\N			約5分			\N	\N	(120g×5)×4×2	増粘剤（加工でん粉）、調味料（アミノ酸等）、着色料(カラメル)、乳化剤、カゼインNa、リン酸塩(Na)、発色剤(亜硝酸Na)、香料、くん液		日本	12ヶ月	34902110385732	4902110385731					\N	281	154x2	\N	186	\N	180	\N	150	0
213	2022-03-20 05:10:18.781358+00	2022-03-25 00:59:57.087346+00	サルサポモドーロ	\N	395600	395600	\N	完熟トマトをじっくり炒めた香味野菜やハーブと煮込んだ、トマトの果肉感あふれるソースです。添加物の調味料を使用せず、優しい味わいに仕上げていますので、様々な料理に幅広くご使用いただけます。	t	f	\N						\N	\N	3kg×6	酸味料		タイ	24ヶ月	14902110395607	4902110395600					\N	321	187	\N	476	\N	155	\N	179	0
193	2022-03-20 05:10:18.781358+00	2022-03-25 01:11:38.46461+00	レンジ用ソテースパゲティ ナポリタン	\N	321400	321400	\N	ナポリタンソースと絡めたパスタをソテーし、香ばしく仕上げました。ピーマン、ソーセージをトッピングし彩り豊かにしています。	t	f	\N			約1分30秒	1500W		\N	\N	260g×12×2	調味料（アミノ酸等）、増粘剤（加工でん粉、増粘多糖類）、着色料(パプリカ色素、カラメル)、乳化剤、リン酸塩(Na)、発色剤(亜硝酸Na)、くん液、いため油(ショートニング)		日本	12ヶ月	34902110321402	4902110321401					\N	236	139x2	\N	396	25	165	\N	250	0
184	2022-03-20 05:10:18.781358+00	2022-03-25 01:18:27.699111+00	マ・マー THE PRO IQF（バラ凍結）MINI フィジリ	\N	290420	290420	\N	らせん状の形をした小型パスタ。スプーンにのっかるサイズで、スープやサラダ､ガロニ等の副菜や小鉢メニューとしてご使用いただけます。ソフトな食感で、お子様から年配の方まで幅広い層におすすめです。	t	t	2022-02-28 15:00:00+00			30秒			\N	\N	500g×12×2	加工でん粉、アルギン酸エステル		日本	12ヶ月	34902110290425	4902110290424					\N	352	199x2	\N	406	40	270	\N	190	0
179	2022-03-20 05:10:18.781358+00	2022-03-25 01:22:09.705349+00	IQF（バラ凍結）ペンネリガーテ	\N	290210	290210	\N	ペン先の形をしたパスタです。リガーテとは「表面に筋のついた」という意味で、この筋にソースが入り込んでよくからみ、様々なタイプのソースによく合います。	t	t	\N			30秒			\N	\N	500g×12×2	加工でん粉、アルギン酸エステル		日本	12ヶ月	34902110290210	4902110290219					\N	352	199x2	\N	406	40	270	\N	190	0
222	2022-03-20 05:10:18.781358+00	2022-03-25 00:51:58.822059+00	たらこソース　（チューブ入・パスタ用）	\N	333680	333680	\N	人気の和風パスタ、たらこ＆明太子。茹でたてのパスタに絡めるだけです。	t	f	\N				流水・冷蔵庫で解凍		\N	\N	240g×20×2	酒精、紅麹色素、調味料（アミノ酸等）、酢酸Na、増粘剤(キサンタンガム)、グリシン、トウガラシ色素		日本	12ヶ月	34902110333689	4902110333688					\N	230	187x2	\N	282	\N	230	\N	100	0
157	2022-03-20 05:10:18.781358+00	2022-03-25 00:35:21.323543+00	フェットチーネ（ほうれん草入り）	\N	353240	353240	\N	幅広パスタならではの弾力。ほうれん草ペーストを練りこみ、鮮やかな緑色に仕上げました。麺幅約６mm。	t	f	\N			約30秒			\N	\N	(200g×5)×4×2	加工でん粉、食塩		日本	12ヶ月	34902110353243	4902110353242					\N	330	130x2	\N	380	121	162	\N	182	0
137	2022-03-20 05:10:18.781358+00	2022-03-24 23:37:59.929343+00	ミニチュロス	\N	388890	388890	\N	表面はカリカリ、中はソフトな食感が特長のスナックです。通常４０ｃｍのチュロスを、様々なデザートシーンにご利用いただける約５ｃｍのミニサイズにカットしました。定番のシナモンフレーバーです。	t	t	\N			①5～7分<br>\r\n②4～5分	①約190℃（オーブン）<br>\r\n②1000W（オーブントースター）		\N	\N	500g×8袋	カゼインNa、香料、乳化剤、糊料(グァーガム)、ベーキングパウダー、着色料(アナトー、ビタミンB₂)		日本	12ヶ月	14902110388890	4902110388893					\N	416	209	\N	326	40	250	\N	400	0
134	2022-03-20 05:10:18.781358+00	2022-03-24 23:36:10.464536+00	チュロス®	\N	381330	381330	\N	スペイン生まれの、スティックタイプスナック。表面はカリカリ、中身はソフトの新感覚スナック。シナモンフレーバーの軽やかな味わい。約40㎝のロングサイズ。	t	f	\N			約5分	170～200℃		\N	\N	2.5kg(50本)×2	カゼインNa、香料、乳化剤、糊料(グァーガム)、ベーキングパウダー、着色料(アナトー、ビタミンB₂)		日本	12ヶ月	14902110381334	\N					\N	323	180	\N	433	\N	\N	\N	\N	0
125	2022-03-20 05:10:18.781358+00	2022-03-24 23:27:33.158245+00	水1リットルでできる蒸しパンミックス（黒）黒糖風味	\N	348300	348300	\N	水１リットルと混ぜて蒸すだけの簡単調理で、ボリュームのあるしっとりとした食感で、コクのある黒糖風味の蒸しパンに仕上がります。甘さ控えめなので、多彩なアレンジが可能です。	t	f	\N			約25分	100℃	80%	\N	\N	1.25kg×8	ベーキングパウダー、乳化剤、カラメル色素、香料		日本	6ヶ月	14902110348306	4902110348309					\N	255	165	\N	509	40	320	\N	200	0
159	2022-03-20 05:10:18.781358+00	2022-03-25 00:36:57.797513+00	ラウンドアップスパゲティ Super Hardタイプ 1.6mm《塩ゆで》　180g	\N	353040	353040	\N	コシが強く、しっかりした噛みごたえ。麺が伸びにくく、時間が経っても弾力が持続します。汎用性の高い便利な３サイズです。	t	f	\N			約30秒			\N	\N	(180g×5)×4×2	加工でん粉、炭酸カリウム、増粘多糖類、食塩		日本	12ヶ月	34902110353045	4902110353044					\N	325	130x2	\N	335	121	155	\N	157	0
251	2022-03-20 05:10:18.781358+00	2022-03-25 00:49:09.501691+00	No.11 Spaghettini Organic（スパゲッティーニ オーガニック）	\N	368800	368800	\N	ディ・チェコならではの、吟味された原料を使用し、こだわりの製法で作ったオーガニックパスタです。※オーガニック（有機）栽培とは、化学的に合成された肥料及び農薬を避けることを基本として、播種または植付けの２年以上（多年生作物）にあっては、最初の収穫前３年前）前の間、堆肥等による土づくりを行った農場において生産された農作物です。	t	f	\N			9分			\N	\N	500g×24			イタリア	36ヶ月	\N	8001250008763					\N	178	282	\N	298	20	310	\N	85	0
221	2022-03-20 05:10:18.781358+00	2022-03-25 00:52:52.852653+00	なめらかカルボナーラソース（個食用）	\N	327750	327750	\N	とろけるようになめらかでクリーミーな口当たりが魅力の上質カルボナーラソース。卵黄とパルメザンチーズの豊かなコクに、ブラックペッパーがアクセント。ベーコン入り。	t	f	\N			約5分			\N	\N	(140g×5)×4×2	増粘剤（加工でん粉、キサンタンガム）、調味料（アミノ酸等）、乳化剤、カゼインNa、リン酸塩(Na)、発色剤(亜硝酸Na)、着色料(カロチン)、香料、くん液		日本	12ヶ月	34902110327756	4902110327755					\N	186	154x2	\N	281	\N	180	\N	150	0
245	2022-03-20 05:10:18.781358+00	2022-03-23 05:17:22.839558+00	No.91 Orecchiette（オレキエッテ）	\N	363440	363440	\N	プーリア地方の最も典型的な耳たぶ形状のショートパスタです。伝統的にはブロッコリーやポテトと一緒に茹でて料理します。野菜のラグー、羊とリコッタのラグーにもお勧めです。	t	f	\N			11分			\N	\N	500g×24			イタリア	36ヶ月	\N	8001250120915					\N	238	272	\N	508	45	240	\N	140	0
243	2022-03-20 05:10:18.781358+00	2022-03-23 05:18:00.451151+00	No.50 Conchiglie Rigate（コンキリエ リガーテ）	\N	368650	368650	\N	「貝殻」という名のパスタ。貝形のくぼみにソースがからまり、味の一体感が楽しめます。貝形の中にあらかじめ具を詰めて料理することもあります。魚介系メニューやトマト風味で仕上げるメニューによく合います。	t	f	\N			13分			\N	\N	500g×24			イタリア	36ヶ月	\N	8001250120502					\N	258	352	\N	548	55	270	\N	145	0
168	2022-03-20 05:10:18.781358+00	2022-03-23 05:41:56.632325+00	Cool’s 冷製スパゲティR 1.4mm《塩ゆで》	\N	321240	321240	\N	日本人好みの「のどごし」を実現した冷製専用パスタ。解凍後に水でしめることを前提にした、冷凍とは思えぬ食感と粘弾性のあるスパゲティです。	t	f	\N			約30秒			\N	\N	(180g×5)×4×2			日本	12ヶ月	34902110321242	4902110321241					\N	330	130x2	\N	330	121	155	\N	157	0
139	2022-03-20 05:10:18.781358+00	2022-03-24 23:41:52.328536+00	マ・マー スパゲティ　1.4	\N	395880	395880	\N	デュラムセモリナ100％の製品。茹で上がった後の滑らかさと粘弾性が特徴のスパゲティです。太さは1.4ミリ、1.6ミリ、1.7ミリ、1.9ミリ、2.2ミリを揃えました。用途に合わせてお使い下さい。	t	f	\N			5分			\N	\N	4kg×４			トルコ	36ヶ月	14902110395881	4902110395884					\N	255	245	\N	285	60	260	\N	320	0
123	2022-03-20 05:10:18.781358+00	2022-03-24 23:25:17.295309+00	クレープミックス #707	\N	467070	467070	\N	口溶けの良い、ミルク風味のクレープが焼き上がります。生地は薄く伸ばしやすく作業性も良好です。	t	f	\N			0.5分	180～190℃	90～100％+卵10％	\N	\N	2kg×6	ベーキングパウダー		日本	\N	\N	\N					\N	190	385	\N	320	\N	\N	\N	\N	0
143	2022-03-20 05:10:18.781358+00	2022-03-24 23:53:16.024252+00	マ・マー スパゲティ　2.2	\N	368840	368840	\N		t	f	\N			17分			\N	\N	4kg×４			アメリカ	36ヶ月	14902110368847	4902110368840					\N	279	150	\N	407	60	260	\N	320	0
156	2022-03-20 05:10:18.781358+00	2022-03-25 00:34:57.630422+00	フェットチーネ（卵入り）	\N	353230	353230	\N	幅広パスタならではの弾力。卵を入れることで風味の良いパスタに仕上げました。麺幅6mm。	t	f	\N			約30秒			\N	\N	(200g×5)×4×2	加工でん粉、食塩		日本	12ヶ月	34902110353236	4902110353235					\N	330	130x2	\N	380	121	162	\N	182	0
256	2022-03-20 05:10:18.781358+00	2022-03-25 00:43:38.694698+00	ラウンドアップパスタスチーマー PSW-777	\N	309310	309310	\N	高温の”ドライスチーム”で解凍・加熱。茹で揚げ後のアツアツでコシのある食感を再現します。パスタを使う、すべての現場に。	t	f	\N						\N	\N	\N			\N	\N	\N	\N					\N	\N	\N	\N	\N	470	275	\N	380	0
257	2022-03-20 05:10:18.781358+00	2022-03-25 00:43:49.707431+00	ラウンドアップパスタスチーマー      軟水器	\N	309490	309490	\N		t	f	\N	photos/heros/331750_01.jpg					\N	\N	\N			\N	\N	\N	\N					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
220	2022-03-20 05:10:18.781358+00	2022-03-25 00:53:52.527543+00	なめらかカルボナーラソース　（1kg）	\N	327820	327820	\N	とろけるようになめらかでクリーミーな口当たりが魅力の上質カルボナーラソース。卵黄とパルメザンチーズの豊かなコクに、ブラックペッパーがアクセント。1kgタイプはベーコンが入っておりません。	t	f	\N			約20分			\N	\N	1kg×5×2	増粘剤（加工でん粉、キサンタンガム）、調味料（アミノ酸等）、乳化剤、カゼインNa、リン酸塩(Na)、着色料(カロチン)、香料		日本	12ヶ月	34902110327824	4902110327823					\N	206	154x2	\N	306	\N	300	\N	200	0
206	2022-03-20 05:10:18.781358+00	2022-03-25 01:05:21.788051+00	マ・マーTHE PRO Smile Meal やさしい味わい ナポリタン	\N	290470	290470	\N	塩分は控えめですが、美味しく食べやすいソース配合としています。ハーフサイズの麺の長さと１食分の食物繊維７ｇが摂れる為、お子様から年配の方までおいしくお召し上がりいただけます。	t	t	2022-02-28 15:00:00+00			約25分	100℃		\N	\N	230g×12×2	増粘剤（加工でん粉、増粘多糖類）、調味料（アミノ酸等）、乳化剤、着色料(カラメル、パプリカ色素)		日本	12ヶ月	34902110290470	4902110290479					\N	400	150x2	\N	220	23	250	\N	140	0
186	2022-03-20 05:10:18.781358+00	2022-03-25 01:16:17.748691+00	マ・マー THE PRO IQF（バラ凍結）MINI シェル	\N	290430	290430	\N	貝殻の形をした小型のマカロニ。スプーンにのっかるサイズで、スープやサラダ､ガロニ等の副菜や小鉢メニューとしてご使用いただけます。ソフトな食感で、お子様から年配の方まで幅広い層におすすめです。	t	t	2022-02-28 15:00:00+00			30秒			\N	\N	500g×12×2	加工でん粉、アルギン酸エステル		日本	12ヶ月	34902110290432	4902110290431					\N	352	199x2	\N	406	40	270	\N	190	0
106	2022-03-20 05:10:18.781358+00	2022-03-23 06:11:08.876839+00	達人厨房 ふんわりお好み焼粉	\N	350390	350390	\N	水をたっぷり加える多加水生地で、ネチャつきや重たさがありません。スチコン調理でも、専門店で人気のふっくら厚手で軽い食感を実現します。	t	f	\N			②約10分	①180℃<br>\r\n②200℃(オーブンモード)	①300％(鉄板使用)<br>\r\n②90％(スチコン使用)	\N	\N	1kg×10	調味料（アミノ酸）、ベーキングパウダー、加工でん粉、増粘剤（グァーガム）、トレハロース、乳化剤		日本	12ヶ月	14902110350392	4902110350395					\N	255	175	\N	509	40	310	\N	190	0
65	2022-03-20 05:10:18.781358+00	2022-03-24 22:17:35.541193+00	おいしい天ぷら粉	\N	340480	340480	\N	手作り天ぷら用の高級粉。小麦粉のグルテンを分解する酵素プロテアーゼが小麦粉の粘りを抑え、サクッとした仕上がりになります。揚げ色が鮮やかで見栄えが良く、おいしい天ぷらが揚がります。使用しやすいチャック付きです。	t	f	\N		150%	約2分<br>\r\n（えび天の場合）	170～180℃		\N	\N	1kg×10	加工でん粉、ベーキングパウダー、調味料（アミノ酸等）カロチン色素、酵素		日本	12ヶ月	14902110340485	4902110340488					\N	255	175	\N	509	40	310	\N	195	0
77	2022-03-20 05:10:18.781358+00	2022-03-24 22:27:56.351431+00	聖地中津からあげセット しょうゆだれ	漬け込みまぶしタイプ	335160	335160	\N	「聖地中津から揚げの会」が監修。「漬け込み用たれ」と「サクサクから揚げ粉」がセットになっているので、本場のおいしさが誰にでも作れます。	t	f	\N			約4分	170℃		\N	\N	(ミックス360g+たれ200g)×16	【から揚げ粉】加工でん粉、pH調整剤、乳化剤　【たれ】ソルビトール、調味料（アミノ酸等）、酸味料、カラメル色素		日本	12ヶ月	14902110335160	4902110335163					\N	280	185	\N	430	40	310	\N	190	0
82	2022-03-20 05:10:18.781358+00	2022-03-24 22:29:35.91052+00	から揚げ粉 唐揚王	水溶きタイプ	335150	335150	\N	衣はサクっとしながら、お肉はソフトでジューシーな食感を実現しました。ふっくらと仕上がり歩留まりが良く経済的です。	t	f	\N		100%	約4分	170～180℃		\N	\N	10kg	加工でん粉、調味料（アミノ酸等）、ベーキングパウダー、乳化剤		日本	6ヶ月	\N	4902110335118					\N	\N	\N	\N	\N	\N	\N	\N	\N	0
97	2022-03-20 05:10:18.781358+00	2022-03-24 22:44:31.430301+00	打ち粉ミックス これで結着！	\N	335050	335050	\N	素材にピタッと結着し、肉汁等のしみ出しによる味と食感の低下を防止する、機能性打ち粉ミックス。衣浮きやはがれのない、ジューシーでおいしい揚げ物に仕上がります。	t	f	\N			約5分	170～180℃		\N	\N	1kg×10	加工でん粉、トレハロース		日本	12ヶ月	14902110335054	4902110335057					\N	310	205	\N	390	40	330	\N	225	0
120	2022-03-20 05:10:18.781358+00	2022-03-24 23:20:55.536475+00	達人厨房 クレープMIX	\N	350410	350410	\N	なめらかな生地なので、薄くしなやかなクレープが作れます。作り置きしても、しっとり・モチモチ感が長続き。ミール系に、デザート系に、メニューの幅も広がります。	t	f	\N			約1分	170～200℃	110％+卵600g	\N	\N	1kg×10	ベーキングパウダー		日本	8ヶ月	14902110350415	4902110350418					\N	255	175	\N	509	40	310	\N	190	0
199	2022-03-20 05:10:18.781358+00	2022-03-25 01:08:45.9207+00	N惣菜用 焼きスパゲティ ナポリタン	\N	333750	333750	\N	解凍後、そのまま提供できるように具材をトッピングした１人前用。パスタをソースとあわせてソテーしているので、味の馴染みがよく、懐かしい味です。	t	f	\N			①約20分<br>\r\n②約1分40秒	①100℃<br>\r\n②1500W		\N	\N	(260g×2食入り)×6×3	加工でん粉、増粘多糖類、炭酸カリウム、調味料(アミノ酸等)、増粘剤(加工でん粉、キサンタンガム)、リン酸塩Na、着色料(カラメル)、香料、発色剤(亜硝酸Na)、いため油(ショートニング)、乳化剤		日本	12ヶ月	34902110333757	4902110333756					\N	246	159x3	\N	356	60	150	\N	200	0
\.


--
-- Data for Name: products_product_category; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.products_product_category (id, product_id, category_id) FROM stdin;
3	50	1
4	50	10
5	51	1
6	51	10
7	52	1
8	52	10
9	52	12
10	53	1
11	53	11
12	53	12
13	54	1
14	54	11
15	54	12
16	55	1
17	55	11
18	56	1
19	56	11
20	56	12
21	57	1
22	57	11
23	58	1
24	58	11
25	59	1
26	59	11
27	60	1
28	60	11
29	61	1
30	61	11
31	62	1
32	62	11
33	63	1
34	63	11
35	64	1
36	65	1
37	66	1
38	67	1
39	68	1
40	69	1
41	70	1
42	71	1
43	72	1
44	73	1
45	74	1
46	75	1
47	75	10
48	76	17
49	76	2
50	76	13
51	77	17
52	77	2
53	77	14
54	78	17
55	78	2
56	78	14
57	79	17
58	79	2
59	79	13
60	80	16
61	80	17
62	80	2
63	81	17
64	81	2
65	81	13
66	82	17
67	82	2
68	82	13
69	83	16
70	83	17
71	83	2
72	84	17
73	84	2
74	84	15
75	85	17
76	85	2
77	85	13
78	86	17
79	86	2
80	86	13
81	87	16
82	87	2
83	87	18
84	88	16
85	88	2
86	88	18
87	89	2
88	89	18
89	89	15
90	90	16
91	90	2
92	90	18
93	91	3
94	91	20
95	91	21
96	92	3
97	92	20
98	92	21
99	92	22
100	93	3
101	93	20
102	93	21
103	94	3
104	94	20
105	95	3
106	95	20
107	96	3
108	96	20
109	96	21
110	96	22
111	97	19
112	97	3
113	97	21
114	97	22
115	98	3
116	98	20
117	98	21
118	99	3
119	99	20
120	99	22
121	100	3
122	100	20
123	100	22
124	101	3
125	101	20
126	101	21
127	102	19
128	102	3
129	102	22
130	103	19
131	103	3
132	103	21
133	104	4
134	104	23
135	105	24
136	105	4
137	106	24
138	106	4
139	107	25
140	107	4
141	108	25
142	108	4
143	109	26
144	109	4
145	110	24
146	110	4
147	111	4
148	111	23
149	112	4
150	112	23
151	113	4
152	113	23
153	114	4
154	114	23
155	115	24
156	115	4
157	116	24
158	116	4
159	117	27
160	117	4
161	119	28
162	119	5
163	118	5
164	118	30
165	120	29
166	120	5
167	121	5
168	121	30
169	122	28
170	122	5
171	123	29
172	123	5
173	124	5
174	124	31
175	125	5
176	125	31
177	126	32
178	126	5
179	127	32
180	127	5
181	128	32
182	128	5
183	129	33
184	129	5
185	130	33
186	130	5
187	131	35
188	131	5
189	132	28
190	132	5
191	133	34
192	133	5
193	134	34
194	134	5
195	135	34
196	135	5
197	136	34
198	136	5
199	137	34
200	137	5
201	138	34
202	138	5
203	139	40
204	139	36
205	139	6
206	140	40
207	140	37
208	140	6
209	141	40
210	141	37
211	141	6
212	142	38
213	142	40
214	142	6
215	143	38
216	143	40
217	143	6
218	144	40
219	144	42
220	144	37
221	144	6
222	145	40
223	145	42
224	145	37
225	145	6
226	146	38
227	146	40
228	146	42
229	146	6
230	147	40
231	147	42
232	147	37
233	147	6
234	148	40
235	148	37
236	148	6
237	148	39
238	149	40
239	149	37
240	149	6
241	149	39
242	150	40
243	150	36
244	150	6
245	151	40
246	151	36
247	151	6
248	152	40
249	152	37
250	152	6
251	153	40
252	153	37
253	153	6
254	154	38
255	154	41
256	154	6
257	155	38
258	155	41
259	155	6
260	156	38
261	156	41
262	156	6
263	157	38
264	157	41
265	157	6
266	158	38
267	158	41
268	158	6
269	159	37
270	159	6
271	160	37
272	160	6
273	161	37
274	161	6
275	162	36
276	162	6
277	163	38
278	163	6
279	164	37
280	164	6
281	165	37
282	165	6
283	166	37
284	166	6
285	167	37
286	167	6
287	168	36
288	168	6
289	169	44
290	169	7
291	170	44
292	170	7
293	171	46
294	171	7
295	172	48
296	172	7
297	173	45
298	173	7
299	174	45
300	174	7
301	175	45
302	175	7
303	176	47
304	176	7
305	177	47
306	177	7
307	178	48
308	178	7
309	179	46
310	179	7
311	180	45
312	180	7
313	181	44
314	181	7
315	182	48
316	182	7
317	183	48
318	183	7
319	184	45
320	184	7
321	185	44
322	185	7
323	186	47
324	186	7
325	187	8
326	187	50
327	188	8
328	188	50
329	189	8
330	189	50
331	190	8
332	190	50
333	191	8
334	191	50
335	192	8
336	192	50
337	193	8
338	193	50
339	194	8
340	194	50
341	195	8
342	195	50
343	196	8
344	196	50
345	197	8
346	197	50
347	198	8
348	198	50
349	199	8
350	199	50
351	200	8
352	200	51
353	201	8
354	201	51
355	202	8
356	202	50
357	203	8
358	203	50
359	204	8
360	204	50
361	205	8
362	205	50
363	206	8
364	206	50
365	207	8
366	207	50
367	208	8
368	208	50
369	209	9
370	209	52
371	210	9
372	210	52
373	211	9
374	211	53
375	212	9
376	212	52
377	213	9
378	213	53
379	214	9
380	214	52
381	215	9
382	215	52
383	216	9
384	216	52
385	217	9
386	217	52
387	218	9
388	218	52
389	219	9
390	219	52
391	220	9
392	220	52
393	221	9
394	221	52
395	222	9
396	222	54
397	223	9
398	223	54
399	224	40
400	224	43
401	224	6
402	225	40
403	225	43
404	225	6
405	226	40
406	226	43
407	226	6
408	227	40
409	227	43
410	227	6
411	228	40
412	228	43
413	228	36
414	228	6
415	229	40
416	229	43
417	229	36
418	229	6
419	230	40
420	230	43
421	230	36
422	230	6
423	231	40
424	231	43
425	231	36
426	231	6
427	232	40
428	232	43
429	232	37
430	232	6
431	233	40
432	233	43
433	233	37
434	233	6
435	234	40
436	234	43
437	234	37
438	234	6
439	235	38
440	235	40
441	235	43
442	235	6
443	236	38
444	236	40
445	236	43
446	236	6
447	237	40
448	237	43
449	237	37
450	237	6
451	238	38
452	238	40
453	238	43
454	238	6
455	239	38
456	239	40
457	239	43
458	239	6
459	240	49
460	240	44
461	240	7
462	241	49
463	241	46
464	241	7
465	242	49
466	242	46
467	242	7
468	243	49
469	243	47
470	243	7
471	244	48
472	244	49
473	244	7
474	245	48
475	245	49
476	245	7
477	246	48
478	246	49
479	246	7
480	247	49
481	247	44
482	247	7
483	248	49
484	248	44
485	248	7
486	249	40
487	249	43
488	249	6
489	250	40
490	250	43
491	250	6
492	251	40
493	251	43
494	251	37
495	251	6
496	252	38
497	252	40
498	252	43
499	252	6
500	253	49
501	253	45
502	253	7
503	254	49
504	254	46
505	254	7
506	255	41
507	255	43
508	255	37
509	255	6
510	256	55
511	257	55
\.


--
-- Data for Name: products_product_facility; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.products_product_facility (id, product_id, facility_id) FROM stdin;
3	50	1
4	51	1
5	52	1
6	53	1
7	54	1
8	55	1
9	56	1
10	57	1
11	58	1
12	59	1
13	60	1
14	61	1
15	62	1
16	63	1
17	64	1
18	65	1
19	66	1
20	67	1
21	68	1
22	69	1
23	70	1
24	71	1
25	72	1
26	73	1
27	74	1
28	75	1
29	76	1
30	77	1
31	78	1
32	79	1
33	80	1
34	81	1
35	82	1
36	83	1
37	84	1
38	85	1
39	86	1
40	87	1
41	88	1
42	89	1
43	90	1
44	91	1
45	92	1
46	93	1
47	94	1
48	95	1
49	96	1
50	97	1
51	98	1
52	99	1
53	100	1
54	101	1
55	102	1
56	103	1
57	104	3
58	105	3
59	106	3
60	107	3
61	108	3
62	109	3
63	110	3
64	111	3
65	112	1
66	112	5
67	113	1
68	113	5
69	114	1
70	114	5
71	115	3
72	115	5
73	116	3
74	116	5
75	117	2
76	118	3
77	119	3
78	120	3
79	121	3
80	122	3
81	123	3
82	124	4
83	125	4
84	126	3
85	127	3
86	128	3
87	129	3
88	130	3
89	132	5
90	133	1
91	133	3
92	134	3
93	135	3
94	136	3
95	137	3
96	138	3
97	139	2
98	140	2
99	141	2
100	142	2
101	143	2
102	144	2
103	145	2
104	146	2
105	147	2
106	148	2
107	149	2
108	150	2
109	151	2
110	152	2
111	153	2
112	154	2
113	155	2
114	156	2
115	157	2
116	158	2
117	159	2
118	160	2
119	161	2
120	162	2
121	163	2
122	164	2
123	165	2
124	166	2
125	167	2
126	168	2
127	169	2
128	170	2
129	171	2
130	172	2
131	173	2
132	174	2
133	175	2
134	176	2
135	177	2
136	178	2
137	179	2
138	180	2
139	181	2
140	182	2
141	183	2
142	184	2
143	185	2
144	186	2
145	187	5
146	188	5
147	189	5
148	190	5
149	191	5
150	192	5
151	193	5
152	194	5
153	195	5
154	196	5
155	197	5
156	198	4
157	198	5
158	199	4
159	199	5
160	200	4
161	200	5
162	201	4
163	201	5
164	202	4
165	203	4
166	204	4
167	205	4
168	206	4
169	207	4
170	208	2
171	209	2
172	210	2
173	211	2
174	212	2
175	213	2
176	214	2
177	215	2
178	216	2
179	217	2
180	218	2
181	219	2
182	220	2
183	221	2
184	224	2
185	225	2
186	226	2
187	227	2
188	228	2
189	229	2
190	230	2
191	231	2
192	232	2
193	233	2
194	234	2
195	235	2
196	236	2
197	237	2
198	238	2
199	239	2
200	240	2
201	241	2
202	242	2
203	243	2
204	244	2
205	245	2
206	246	2
207	247	2
208	248	2
209	249	2
210	250	2
211	251	2
212	252	2
213	253	2
214	254	2
215	255	2
\.


--
-- Data for Name: products_product_industry; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.products_product_industry (id, product_id, industry_id) FROM stdin;
4	50	1
5	50	2
6	50	3
7	50	5
8	51	1
9	51	2
10	51	3
11	51	5
12	51	6
13	52	1
14	52	2
15	52	3
16	52	5
17	53	1
18	53	2
19	53	5
20	54	1
21	54	2
22	54	5
23	55	1
24	55	2
25	55	5
26	56	1
27	56	2
28	57	1
29	57	2
30	57	3
31	58	1
32	58	2
33	58	3
34	58	5
35	59	1
36	59	2
37	59	5
38	59	6
39	60	1
40	60	2
41	60	3
42	60	5
43	61	1
44	61	2
45	61	5
46	61	6
47	62	2
48	62	3
49	62	5
50	63	2
51	63	5
52	63	6
53	64	1
54	65	1
55	66	1
56	67	1
57	67	2
58	68	1
59	68	2
60	68	6
61	69	1
62	69	2
63	69	6
64	70	1
65	70	2
66	70	6
67	71	1
68	71	2
69	71	6
70	72	1
71	72	2
72	72	6
73	73	1
74	73	2
75	73	6
76	74	1
77	74	2
78	75	1
79	75	2
80	75	3
81	76	1
82	76	2
83	76	3
84	77	1
85	77	2
86	77	3
87	78	1
88	78	2
89	78	3
90	79	2
91	79	6
92	80	2
93	80	6
94	81	1
95	81	3
96	82	1
97	82	2
98	82	5
99	83	1
100	83	2
101	83	5
102	84	1
103	84	2
104	84	5
105	85	1
106	85	2
107	85	5
108	86	1
109	86	2
110	86	3
111	86	5
112	87	1
113	87	2
114	87	3
115	87	5
116	88	1
117	88	2
118	88	3
119	88	5
120	89	1
121	89	2
122	89	3
123	89	5
124	90	1
125	90	2
126	90	3
127	90	5
128	91	1
129	91	2
130	91	3
131	92	2
132	92	6
133	93	2
134	93	6
135	94	2
136	94	6
137	95	1
138	95	2
139	95	6
140	96	1
141	96	2
142	97	1
143	97	2
144	97	6
145	98	2
146	98	6
147	99	2
148	99	6
149	100	2
150	100	6
151	101	2
152	101	6
153	102	2
154	102	6
155	103	2
156	103	6
157	104	1
158	104	3
159	105	1
160	105	2
161	105	3
162	106	1
163	106	2
164	106	3
165	107	1
166	107	3
167	108	1
168	108	2
169	108	3
170	108	6
171	109	1
172	109	2
173	109	3
174	109	6
175	110	1
176	110	2
177	110	3
178	110	6
179	111	1
180	111	2
181	111	3
182	111	6
183	112	1
184	112	2
185	112	3
186	113	1
187	113	2
188	113	3
189	114	1
190	114	2
191	114	3
192	115	1
193	115	2
194	115	3
195	116	1
196	116	2
197	116	3
198	117	1
199	117	3
200	118	1
201	118	3
202	119	1
203	119	3
204	120	1
205	120	3
206	121	1
207	121	3
208	121	6
209	122	1
210	122	3
211	122	6
212	123	1
213	123	3
214	123	6
215	124	1
216	124	2
217	124	3
218	124	4
219	124	5
220	125	1
221	125	2
222	125	3
223	125	4
224	125	5
225	126	1
226	126	3
227	127	1
228	127	3
229	128	1
230	128	3
231	129	1
232	129	3
233	130	1
234	130	3
235	131	1
236	131	5
237	132	1
238	132	2
239	132	3
240	132	4
241	132	5
242	132	6
243	133	1
244	133	3
245	134	1
246	134	3
247	135	1
248	135	3
249	136	1
250	136	3
251	137	1
252	137	3
253	138	1
254	138	3
255	139	1
256	139	2
257	139	5
258	139	6
259	140	1
260	140	2
261	140	5
262	140	6
263	141	1
264	141	2
265	141	5
266	141	6
267	142	1
268	142	2
269	142	5
270	142	6
271	143	1
272	143	2
273	143	5
274	143	6
275	144	1
276	144	5
277	145	1
278	145	5
279	146	1
280	146	2
281	146	5
282	147	1
283	147	5
284	148	1
285	148	2
286	148	3
287	148	5
288	148	6
289	149	1
290	149	2
291	149	3
292	149	5
293	149	6
294	150	1
295	150	2
296	150	3
297	151	1
298	151	2
299	151	3
300	151	6
301	152	1
302	152	2
303	152	3
304	153	1
305	153	2
306	153	3
307	153	6
308	154	1
309	155	1
310	156	1
311	157	1
312	158	1
313	159	1
314	160	1
315	161	1
316	162	1
317	163	1
318	164	1
319	164	3
320	165	1
321	165	3
322	166	1
323	167	1
324	168	1
325	169	1
326	169	2
327	169	5
328	169	6
329	170	1
330	170	2
331	170	5
332	170	6
333	171	1
334	171	2
335	171	5
336	171	6
337	172	1
338	172	2
339	172	5
340	172	6
341	173	1
342	173	2
343	173	5
344	173	6
345	174	1
346	174	2
347	174	5
348	174	6
349	175	1
350	175	2
351	175	5
352	175	6
353	176	1
354	176	5
355	176	6
356	177	1
357	177	5
358	177	6
359	178	1
360	178	5
361	178	6
362	179	1
363	179	2
364	179	3
365	179	4
366	179	5
367	180	1
368	180	2
369	180	3
370	180	4
371	180	5
372	181	1
373	181	2
374	181	3
375	181	4
376	181	5
377	182	1
378	182	2
379	182	3
380	182	4
381	182	5
382	183	1
383	183	2
384	183	3
385	183	4
386	183	5
387	184	1
388	184	2
389	184	3
390	184	4
391	184	5
392	185	1
393	185	2
394	185	3
395	185	4
396	185	5
397	186	1
398	186	2
399	186	3
400	186	4
401	186	5
402	187	1
403	188	1
404	189	1
405	190	1
406	191	1
407	192	1
408	193	1
409	194	1
410	195	1
411	196	1
412	197	1
413	198	2
414	199	2
415	200	1
416	200	2
417	200	3
418	201	1
419	201	2
420	201	3
421	202	2
422	202	3
423	203	2
424	203	3
425	204	2
426	204	3
427	205	2
428	205	3
429	206	3
430	206	4
431	207	3
432	207	4
433	208	1
434	208	3
435	209	1
436	209	3
437	210	1
438	210	3
439	211	1
440	211	3
441	211	5
442	211	6
443	212	1
444	212	3
445	212	5
446	212	6
447	213	1
448	213	3
449	213	5
450	213	6
451	214	1
452	214	3
453	214	6
454	215	1
455	215	6
456	216	1
457	216	3
458	217	1
459	217	3
460	218	1
461	218	3
462	219	1
463	220	1
464	221	1
465	222	1
466	222	3
467	223	1
468	223	3
469	224	1
470	225	1
471	226	1
472	227	1
473	228	1
474	229	1
475	230	1
476	231	1
477	232	1
478	233	1
479	234	1
480	235	1
481	236	1
482	237	1
483	238	1
484	239	1
485	240	1
486	241	1
487	242	1
488	243	1
489	244	1
490	245	1
491	246	1
492	247	1
493	248	1
494	249	1
495	250	1
496	251	1
497	252	1
498	253	1
499	254	1
500	255	1
501	256	1
502	257	1
\.


--
-- Data for Name: products_product_related; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.products_product_related (id, from_product_id, to_product_id) FROM stdin;
2	50	51
3	50	52
4	50	75
5	51	50
6	51	75
7	51	52
8	52	75
9	52	50
10	52	51
11	53	54
12	53	55
13	53	56
14	53	57
15	53	58
16	53	60
17	53	62
18	54	53
19	54	55
20	54	56
21	54	57
22	54	58
23	54	60
24	54	62
25	55	53
26	55	54
27	55	56
28	55	57
29	55	58
30	55	60
31	55	62
32	56	53
33	56	54
34	56	55
35	56	57
36	56	58
37	56	60
38	56	62
39	57	53
40	57	54
41	57	55
42	57	56
43	57	58
44	57	60
45	57	62
46	58	53
47	58	54
48	58	55
49	58	56
50	58	57
51	58	60
52	58	62
53	59	61
54	59	63
55	60	53
56	60	54
57	60	55
58	60	56
59	60	57
60	60	58
61	60	62
62	61	59
63	61	63
64	62	53
65	62	54
66	62	55
67	62	56
68	62	57
69	62	58
70	62	60
71	63	59
72	63	61
73	64	65
74	64	66
75	64	74
76	65	64
77	65	66
78	65	74
79	66	64
80	66	65
81	66	74
82	67	68
83	67	69
84	67	70
85	67	71
86	67	72
87	67	73
88	68	67
89	68	69
90	68	70
91	68	71
92	68	72
93	68	73
94	69	67
95	69	68
96	69	70
97	69	71
98	69	72
99	69	73
100	70	67
101	70	68
102	70	69
103	70	71
104	70	72
105	70	73
106	71	67
107	71	68
108	71	69
109	71	70
110	71	72
111	71	73
112	72	67
113	72	68
114	72	69
115	72	70
116	72	71
117	72	73
118	73	67
119	73	68
120	73	69
121	73	70
122	73	71
123	73	72
124	74	64
125	74	65
126	74	66
127	75	50
128	75	51
129	75	52
130	76	89
131	76	90
132	77	78
133	78	77
134	79	81
135	79	82
136	79	85
137	80	83
138	81	82
139	81	85
140	81	79
141	82	81
142	82	85
143	82	79
144	83	80
145	85	81
146	85	82
147	85	79
148	86	76
149	86	87
150	86	88
151	86	89
152	86	90
153	87	76
154	87	86
155	87	88
156	87	89
157	87	90
158	88	76
159	88	86
160	88	87
161	88	89
162	88	90
163	89	76
164	89	86
165	89	87
166	89	88
167	89	90
168	90	76
169	90	86
170	90	87
171	90	88
172	90	89
173	91	96
174	91	97
175	91	98
176	91	99
177	91	100
178	91	101
179	91	102
180	91	103
181	91	92
182	91	93
183	91	94
184	91	95
185	92	96
186	92	97
187	92	98
188	92	99
189	92	100
190	92	101
191	92	102
192	92	103
193	92	91
194	92	93
195	92	94
196	92	95
197	93	96
198	93	97
199	93	98
200	93	99
201	93	100
202	93	101
203	93	102
204	93	103
205	93	91
206	93	92
207	93	94
208	93	95
209	94	96
210	94	97
211	94	98
212	94	99
213	94	100
214	94	101
215	94	102
216	94	103
217	94	91
218	94	92
219	94	93
220	94	95
221	95	96
222	95	97
223	95	98
224	95	99
225	95	100
226	95	101
227	95	102
228	95	103
229	95	91
230	95	92
231	95	93
232	95	94
233	96	97
234	96	98
235	96	99
236	96	100
237	96	101
238	96	102
239	96	103
240	96	91
241	96	92
242	96	93
243	96	94
244	96	95
245	97	96
246	97	98
247	97	99
248	97	100
249	97	101
250	97	102
251	97	103
252	97	91
253	97	92
254	97	93
255	97	94
256	97	95
257	98	96
258	98	97
259	98	99
260	98	100
261	98	101
262	98	102
263	98	103
264	98	91
265	98	92
266	98	93
267	98	94
268	98	95
269	99	96
270	99	97
271	99	98
272	99	100
273	99	101
274	99	102
275	99	103
276	99	91
277	99	92
278	99	93
279	99	94
280	99	95
281	100	96
282	100	97
283	100	98
284	100	99
285	100	101
286	100	102
287	100	103
288	100	91
289	100	92
290	100	93
291	100	94
292	100	95
293	101	96
294	101	97
295	101	98
296	101	99
297	101	100
298	101	102
299	101	103
300	101	91
301	101	92
302	101	93
303	101	94
304	101	95
305	102	96
306	102	97
307	102	98
308	102	99
309	102	100
310	102	101
311	102	103
312	102	91
313	102	92
314	102	93
315	102	94
316	102	95
317	103	96
318	103	97
319	103	98
320	103	99
321	103	100
322	103	101
323	103	102
324	103	91
325	103	92
326	103	93
327	103	94
328	103	95
329	104	105
330	104	107
331	104	108
332	104	109
333	104	110
334	104	111
335	104	112
336	104	113
337	104	114
338	104	115
339	104	116
340	104	117
341	105	104
342	105	107
343	105	108
344	105	109
345	105	110
346	105	111
347	105	112
348	105	113
349	105	114
350	105	115
351	105	116
352	105	117
353	107	104
354	107	105
355	107	108
356	107	109
357	107	110
358	107	111
359	107	112
360	107	113
361	107	114
362	107	115
363	107	116
364	107	117
365	108	104
366	108	105
367	108	107
368	108	109
369	108	110
370	108	111
371	108	112
372	108	113
373	108	114
374	108	115
375	108	116
376	108	117
377	109	104
378	109	105
379	109	107
380	109	108
381	109	110
382	109	111
383	109	112
384	109	113
385	109	114
386	109	115
387	109	116
388	109	117
389	110	104
390	110	105
391	110	107
392	110	108
393	110	109
394	110	111
395	110	112
396	110	113
397	110	114
398	110	115
399	110	116
400	110	117
401	111	104
402	111	105
403	111	107
404	111	108
405	111	109
406	111	110
407	111	112
408	111	113
409	111	114
410	111	115
411	111	116
412	111	117
413	112	104
414	112	105
415	112	107
416	112	108
417	112	109
418	112	110
419	112	111
420	112	113
421	112	114
422	112	115
423	112	116
424	112	117
425	113	104
426	113	105
427	113	107
428	113	108
429	113	109
430	113	110
431	113	111
432	113	112
433	113	114
434	113	115
435	113	116
436	113	117
1260	203	202
1261	203	204
1262	203	205
1263	202	203
1264	202	204
1265	202	205
1269	200	201
1270	200	198
1271	200	199
1275	198	200
1276	198	201
1277	198	199
449	115	104
450	115	105
451	115	107
452	115	108
453	115	109
454	115	110
455	115	111
456	115	112
457	115	113
458	115	114
459	115	116
460	115	117
461	116	104
462	116	105
463	116	107
464	116	108
465	116	109
466	116	110
467	116	111
468	116	112
469	116	113
470	116	114
471	116	115
472	116	117
473	117	104
474	117	105
475	117	107
476	117	108
477	117	109
478	117	110
479	117	111
480	117	112
481	117	113
482	117	114
483	117	115
484	117	116
485	118	128
486	118	129
487	118	130
488	118	132
489	118	121
490	118	122
491	118	123
492	118	124
493	118	125
494	118	126
495	118	127
496	119	120
497	119	131
498	120	131
499	120	119
500	121	128
501	121	129
502	121	130
503	121	132
504	121	118
505	121	122
506	121	123
507	121	124
508	121	125
509	121	126
510	121	127
511	122	128
512	122	129
513	122	130
514	122	132
515	122	121
516	122	123
517	122	124
518	122	125
519	122	126
520	122	127
521	123	128
522	123	129
523	123	130
524	123	132
525	123	118
526	123	121
527	123	122
528	123	124
529	123	125
530	123	126
531	123	127
532	124	128
533	124	129
534	124	130
535	124	132
536	124	118
537	124	121
538	124	122
539	124	123
540	124	125
541	124	126
542	124	127
543	125	128
544	125	129
545	125	130
546	125	132
547	125	118
548	125	121
549	125	122
550	125	123
551	125	124
552	125	126
553	125	127
554	126	128
555	126	129
556	126	130
557	126	132
558	126	118
559	126	121
560	126	122
561	126	123
562	126	124
563	126	125
564	126	127
565	127	128
566	127	129
567	127	130
568	127	132
569	127	118
570	127	121
571	127	122
572	127	123
573	127	124
574	127	125
575	127	126
576	128	129
577	128	130
578	128	132
579	128	118
580	128	121
581	128	122
582	128	123
583	128	124
584	128	125
585	128	126
586	128	127
587	129	128
588	129	130
589	129	132
590	129	118
591	129	121
592	129	122
593	129	123
594	129	124
595	129	125
596	129	126
597	129	127
598	130	128
599	130	129
600	130	132
601	130	118
602	130	122
603	130	123
604	130	124
605	130	125
606	130	126
607	130	127
608	131	120
609	131	119
610	132	128
611	132	129
612	132	130
613	132	118
614	132	121
615	132	122
616	132	123
617	132	124
618	132	125
619	132	126
620	132	127
621	133	134
622	133	135
623	133	136
624	133	137
625	133	138
626	134	133
627	134	135
628	134	136
629	134	137
630	134	138
631	135	133
632	135	134
633	135	136
634	135	137
635	135	138
636	136	133
637	136	134
638	136	135
639	136	137
640	136	138
641	137	133
642	137	134
643	137	135
644	137	136
645	137	138
646	138	133
647	138	134
648	138	135
649	138	136
650	138	137
651	139	140
652	139	141
653	139	142
654	139	143
655	139	144
656	139	145
657	139	146
658	139	147
659	139	148
660	139	149
661	139	166
662	139	167
663	139	168
664	139	208
665	139	225
666	139	226
667	139	227
668	139	228
669	139	229
670	139	230
671	139	231
672	139	232
673	139	233
674	139	234
675	139	235
676	139	236
677	139	237
678	139	238
679	139	239
680	139	249
681	139	250
682	139	255
683	140	139
684	140	141
685	140	142
686	140	143
687	140	144
688	140	145
689	140	146
690	140	147
691	140	148
692	140	149
693	140	166
694	140	167
695	140	168
696	140	208
697	140	225
698	140	226
699	140	227
700	140	228
701	140	229
702	140	230
703	140	231
704	140	232
705	140	233
706	140	234
707	140	235
708	140	236
709	140	237
710	140	238
711	140	239
712	140	249
713	140	250
714	140	255
715	141	139
716	141	140
717	141	142
718	141	143
719	141	144
720	141	145
721	141	146
722	141	147
723	141	148
724	141	149
725	141	166
726	141	167
727	141	168
728	141	208
729	141	225
730	141	226
731	141	227
732	141	228
733	141	229
734	141	230
735	141	231
736	141	232
737	141	233
738	141	234
739	141	235
740	141	236
741	141	237
742	141	238
743	141	239
744	141	249
745	141	250
746	141	255
747	142	139
748	142	140
749	142	141
750	142	143
751	142	144
752	142	145
753	142	146
754	142	147
755	142	148
756	142	149
757	142	166
758	142	167
759	142	168
760	142	208
761	142	225
762	142	226
763	142	227
764	142	228
765	142	229
766	142	230
767	142	231
768	142	232
769	142	233
770	142	234
771	142	235
772	142	236
773	142	237
774	142	238
775	142	239
776	142	249
777	142	250
778	142	255
779	143	139
780	143	140
781	143	141
782	143	142
783	143	144
784	143	145
785	143	146
786	143	147
787	143	148
788	143	149
789	143	166
790	143	167
791	143	168
792	143	208
793	143	225
794	143	226
795	143	227
796	143	228
797	143	229
798	143	230
799	143	231
800	143	232
801	143	233
802	143	234
803	143	235
804	143	236
805	143	237
806	143	238
807	143	239
808	143	249
809	143	250
810	143	255
811	144	139
812	144	140
813	144	141
814	144	142
815	144	143
816	144	145
817	144	146
818	144	147
819	144	148
820	144	149
821	144	166
822	144	167
823	144	168
824	144	208
825	144	225
826	144	226
827	144	227
828	144	228
829	144	229
830	144	230
831	144	231
832	144	232
833	144	233
834	144	234
835	144	235
836	144	236
837	144	237
838	144	238
839	144	239
840	144	249
841	144	250
842	144	255
843	145	139
844	145	140
845	145	141
846	145	142
847	145	143
848	145	144
849	145	146
850	145	147
851	145	148
852	145	149
853	145	166
854	145	167
855	145	168
856	145	208
857	145	225
858	145	226
859	145	227
860	145	228
861	145	229
862	145	230
863	145	231
864	145	232
865	145	233
866	145	234
867	145	235
868	145	236
869	145	237
870	145	238
871	145	239
872	145	249
873	145	250
874	145	255
875	146	139
876	146	140
877	146	141
878	146	142
879	146	143
880	146	144
881	146	145
882	146	147
883	146	148
884	146	149
885	146	166
886	146	167
887	146	168
888	146	208
889	146	225
890	146	226
891	146	227
892	146	228
893	146	229
894	146	230
895	146	231
896	146	232
897	146	233
898	146	234
899	146	235
900	146	236
901	146	237
902	146	238
903	146	239
904	146	249
905	146	250
906	146	255
907	147	139
908	147	140
909	147	141
910	147	142
911	147	143
912	147	144
913	147	145
914	147	146
915	147	148
916	147	149
917	147	166
918	147	167
919	147	168
920	147	208
921	147	225
922	147	226
923	147	227
924	147	228
925	147	229
926	147	230
927	147	231
928	147	232
929	147	233
930	147	234
931	147	235
932	147	236
933	147	237
934	147	238
935	147	239
936	147	249
937	147	250
938	147	255
939	148	139
940	148	140
941	148	141
942	148	142
943	148	143
944	148	144
945	148	145
946	148	146
947	148	147
948	148	149
949	148	166
950	148	167
951	148	168
952	148	208
953	148	225
954	148	226
955	148	227
956	148	228
957	148	229
958	148	230
959	148	231
960	148	232
961	148	233
962	148	234
963	148	235
964	148	236
965	148	237
966	148	238
967	148	239
968	148	249
969	148	250
970	148	255
971	149	139
972	149	140
973	149	141
974	149	142
975	149	143
976	149	144
977	149	145
978	149	146
979	149	147
980	149	148
981	149	166
982	149	167
983	149	168
984	149	208
985	149	225
986	149	226
987	149	227
988	149	228
989	149	229
990	149	230
991	149	231
992	149	232
993	149	233
994	149	234
995	149	235
996	149	236
997	149	237
998	149	238
999	149	239
1000	149	249
1001	149	250
1002	149	255
1003	150	152
1004	150	153
1005	150	165
1006	150	151
1007	151	152
1008	151	153
1009	151	165
1010	151	150
1011	152	153
1012	152	165
1013	152	150
1014	152	151
1015	153	152
1016	153	165
1017	153	150
1018	153	151
1019	154	155
1020	154	156
1021	154	157
1022	154	158
1023	155	154
1024	155	156
1025	155	157
1026	155	158
1027	156	154
1028	156	155
1029	156	157
1030	156	158
1031	157	154
1032	157	155
1033	157	156
1034	157	158
1035	158	154
1036	158	155
1037	158	156
1038	158	157
1039	159	160
1040	159	161
1041	159	162
1042	159	163
1043	159	164
1044	160	161
1045	160	162
1046	160	163
1047	160	164
1048	160	159
1049	161	160
1050	161	162
1051	161	163
1052	161	164
1053	161	159
1054	162	160
1055	162	161
1056	162	163
1057	162	164
1058	162	159
1059	163	160
1060	163	161
1061	163	162
1062	163	164
1063	163	159
1064	164	160
1065	164	161
1066	164	162
1067	164	163
1068	164	159
1069	165	152
1070	165	153
1071	165	150
1072	165	151
1073	256	257
1074	257	256
1075	255	139
1076	255	140
1077	255	141
1078	255	142
1079	255	143
1080	255	144
1081	255	145
1082	255	146
1083	255	147
1084	255	148
1085	255	149
1086	255	166
1087	255	167
1088	255	168
1089	255	208
1090	255	225
1091	255	226
1092	255	227
1093	255	228
1094	255	229
1095	255	230
1096	255	231
1097	255	232
1098	255	233
1099	255	234
1100	255	235
1101	255	236
1102	255	237
1103	255	238
1104	255	239
1105	255	249
1106	255	250
1107	254	253
1108	253	254
1109	252	251
1110	251	252
1111	223	214
1112	223	215
1113	223	216
1114	223	217
1115	223	218
1116	223	219
1117	223	220
1118	223	221
1119	223	222
1120	222	214
1121	222	215
1122	222	216
1123	222	217
1124	222	218
1125	222	219
1126	222	220
1127	222	221
1128	222	223
1129	221	214
1130	221	215
1131	221	216
1132	221	217
1133	221	218
1134	221	219
1135	221	220
1136	221	222
1137	221	223
1138	220	214
1139	220	215
1140	220	216
1141	220	217
1142	220	218
1143	220	219
1144	220	221
1145	220	222
1146	220	223
1147	219	214
1148	219	215
1149	219	216
1150	219	217
1151	219	218
1152	219	220
1153	219	221
1154	219	222
1155	219	223
1156	218	214
1157	218	215
1158	218	216
1159	218	217
1160	218	219
1161	218	220
1162	218	221
1163	218	222
1164	218	223
1165	217	214
1166	217	215
1167	217	216
1168	217	218
1169	217	219
1170	217	220
1171	217	221
1172	217	222
1173	217	223
1174	216	214
1175	216	215
1176	216	217
1177	216	218
1178	216	219
1179	216	220
1180	216	221
1181	216	222
1182	216	223
1183	215	214
1184	215	216
1185	215	217
1186	215	218
1187	215	219
1188	215	220
1189	215	221
1190	215	222
1191	215	223
1192	214	215
1193	214	216
1194	214	217
1195	214	218
1196	214	219
1197	214	220
1198	214	221
1199	214	222
1200	214	223
1201	213	210
1202	213	211
1203	213	212
1204	212	209
1205	212	210
1206	212	211
1207	212	213
1208	211	209
1209	211	210
1210	211	212
1211	211	213
1212	210	209
1213	210	211
1214	210	212
1215	210	213
1216	209	210
1217	209	211
1218	209	212
1219	209	213
1220	208	139
1221	208	140
1222	208	141
1223	208	142
1224	208	143
1225	208	144
1226	208	145
1227	208	146
1228	208	147
1229	208	148
1230	208	149
1231	208	166
1232	208	167
1233	208	168
1234	208	225
1235	208	226
1236	208	227
1237	208	228
1238	208	229
1239	208	230
1240	208	231
1241	208	232
1242	208	233
1243	208	234
1244	208	235
1245	208	236
1246	208	237
1247	208	238
1248	208	239
1249	208	249
1250	208	250
1251	208	255
1252	207	206
1253	206	207
1254	205	202
1255	205	203
1256	205	204
1257	204	202
1258	204	203
1259	204	205
1266	201	200
1267	201	198
1268	201	199
1272	199	200
1273	199	201
1274	199	198
1278	197	193
1279	197	194
1280	197	195
1281	197	196
1282	196	193
1283	196	194
1284	196	195
1285	196	197
1286	195	193
1287	195	194
1288	195	196
1289	195	197
1290	194	193
1291	194	195
1292	194	196
1293	194	197
1294	193	194
1295	193	195
1296	193	196
1297	193	197
1298	192	187
1299	192	188
1300	192	189
1301	192	190
1302	192	191
1303	191	192
1304	191	187
1305	191	188
1306	191	189
1307	191	190
1308	190	192
1309	190	187
1310	190	188
1311	190	189
1312	190	191
1313	189	192
1314	189	187
1315	189	188
1316	189	190
1317	189	191
1318	188	192
1319	188	187
1320	188	189
1321	188	190
1322	188	191
1323	187	192
1324	187	188
1325	187	189
1326	187	190
1327	187	191
1328	186	179
1329	186	180
1330	186	181
1331	186	182
1332	186	183
1333	186	184
1334	186	185
1335	185	179
1336	185	180
1337	185	181
1338	185	182
1339	185	183
1340	185	184
1341	185	186
1342	184	179
1343	184	180
1344	184	181
1345	184	182
1346	184	183
1347	184	185
1348	184	186
1349	183	179
1350	183	180
1351	183	181
1352	183	182
1353	183	184
1354	183	185
1355	183	186
1356	182	180
1357	182	181
1358	182	183
1359	182	184
1360	182	185
1361	182	186
1362	181	179
1363	181	180
1364	181	182
1365	181	183
1366	181	184
1367	181	185
1368	181	186
1369	180	179
1370	180	181
1371	180	182
1372	180	183
1373	180	184
1374	180	185
1375	180	186
1376	179	180
1377	179	181
1378	179	182
1379	179	183
1380	179	184
1381	179	185
1382	179	186
\.


--
-- Data for Name: products_product_tag; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.products_product_tag (id, product_id, tag_id) FROM stdin;
4	50	1
5	50	2
6	50	5
7	51	1
8	51	2
9	51	5
10	51	3
11	52	1
12	52	2
13	52	5
14	53	1
15	53	5
16	54	1
17	54	5
18	55	1
19	55	5
20	56	1
21	56	5
22	57	1
23	57	2
24	57	5
25	58	1
26	58	5
27	59	1
28	59	3
29	59	5
30	60	1
31	60	5
32	61	1
33	61	3
34	61	5
35	62	1
36	62	5
37	63	1
38	63	3
39	63	5
40	64	5
41	65	5
42	66	5
43	67	3
44	67	5
45	68	3
46	68	5
47	69	3
48	69	5
49	70	3
50	70	5
51	71	2
52	71	3
53	71	5
54	72	3
55	72	5
56	73	3
57	73	5
58	74	5
59	75	2
60	75	5
61	76	1
62	76	5
63	77	1
64	77	5
65	78	1
66	78	5
67	79	3
68	79	5
69	80	3
70	80	5
71	81	5
72	82	3
73	82	5
74	83	1
75	83	5
76	84	5
77	85	2
78	85	5
79	86	1
80	86	2
81	86	3
82	86	5
83	87	1
84	87	2
85	87	5
86	88	2
87	88	5
88	89	2
89	89	5
90	90	2
91	90	5
92	91	2
93	91	5
94	92	2
95	92	3
96	92	5
97	93	2
98	93	3
99	93	5
100	94	3
101	94	5
102	95	3
103	95	5
104	96	1
105	96	5
106	97	1
107	97	5
108	98	3
109	98	5
110	99	3
111	99	5
112	100	3
113	100	5
114	101	3
115	101	5
116	102	3
117	102	5
118	103	3
119	103	5
120	104	2
121	104	5
122	105	2
123	105	5
124	106	1
125	106	5
126	107	1
127	107	5
128	108	3
129	108	5
130	109	3
131	109	5
132	110	3
133	110	5
134	111	3
135	111	5
136	112	1
137	112	3
138	112	4
139	113	1
140	113	3
141	113	4
142	114	1
143	114	3
144	114	4
145	115	1
146	115	4
147	116	1
148	116	4
149	117	1
150	117	4
151	118	1
152	118	5
153	119	1
154	119	5
155	120	1
156	120	5
157	121	3
158	121	5
159	122	3
160	122	5
161	123	3
162	123	5
163	124	1
164	124	2
165	124	5
166	125	1
167	125	2
168	125	5
169	126	1
170	126	5
171	127	1
172	127	5
173	128	1
174	128	5
175	129	3
176	129	5
177	130	5
178	131	1
179	131	5
180	132	1
181	132	2
182	132	4
183	133	1
184	133	4
185	134	1
186	134	3
187	134	4
188	135	1
189	135	3
190	135	4
191	136	1
192	136	3
193	136	4
194	137	1
195	137	4
196	138	1
197	138	4
198	139	3
199	139	5
200	140	3
201	140	5
202	141	3
203	141	5
204	142	3
205	142	5
206	143	3
207	143	5
208	144	1
209	144	3
210	144	5
211	145	1
212	145	3
213	145	5
214	146	1
215	146	3
216	146	5
217	147	1
218	147	3
219	147	5
220	148	3
221	148	5
222	149	3
223	149	5
224	150	2
225	150	5
226	151	2
227	151	3
228	151	5
229	152	2
230	152	5
231	153	2
232	153	3
233	153	5
234	154	1
235	154	4
236	155	1
237	155	4
238	156	1
239	156	4
240	157	1
241	157	4
242	158	1
243	158	4
244	159	1
245	159	4
246	160	1
247	160	4
248	161	1
249	161	4
250	162	1
251	162	4
252	163	1
253	163	4
254	164	1
255	164	2
256	164	3
257	164	4
258	165	1
259	165	4
260	166	1
261	166	4
262	167	1
263	167	4
264	168	1
265	168	4
266	169	3
267	169	5
268	170	3
269	170	5
270	171	3
271	171	5
272	172	3
273	172	5
274	173	3
275	173	5
276	174	3
277	174	5
278	175	3
279	175	5
280	176	3
281	176	5
282	177	3
283	177	5
284	178	3
285	178	5
286	179	1
287	179	2
288	179	4
289	180	1
290	180	2
291	180	4
292	181	1
293	181	2
294	181	4
295	182	1
296	182	2
297	182	5
298	183	1
299	183	2
300	183	4
301	184	1
302	184	2
303	184	4
304	185	1
305	185	2
306	185	4
307	186	1
308	186	2
309	186	4
310	187	1
311	187	4
312	188	1
313	188	4
314	189	1
315	189	4
316	190	1
317	190	4
318	191	1
319	191	4
320	192	1
321	192	4
322	193	1
323	193	4
324	194	1
325	194	4
326	195	1
327	195	4
328	196	1
329	196	4
330	197	1
331	197	4
332	198	1
333	198	2
334	198	4
335	199	1
336	199	2
337	199	4
338	200	1
339	200	2
340	200	4
341	201	1
342	201	2
343	201	4
344	202	1
345	202	2
346	202	4
347	203	1
348	203	2
349	203	4
350	204	1
351	204	2
352	204	4
353	205	1
354	205	2
355	205	4
356	206	1
357	206	2
358	206	4
359	207	1
360	207	2
361	207	4
362	208	1
363	208	2
364	208	4
365	209	1
366	209	5
367	210	1
368	210	5
369	211	3
370	211	5
371	212	3
372	212	5
373	213	3
374	213	5
375	214	3
376	214	4
377	215	3
378	215	4
379	216	1
380	216	4
381	217	1
382	217	4
383	218	1
384	218	4
385	219	1
386	219	4
387	220	3
388	220	4
389	221	1
390	221	4
391	222	1
392	222	4
393	223	1
394	223	4
395	224	5
396	225	5
397	226	5
398	227	5
399	228	5
400	229	3
401	229	5
402	230	3
403	230	5
404	231	5
405	232	5
406	233	3
407	233	5
408	234	3
409	234	5
410	235	5
411	236	3
412	236	5
413	237	5
414	238	5
415	239	5
416	240	5
417	241	5
418	242	5
419	243	5
420	244	5
421	245	5
422	246	5
423	247	5
424	248	5
425	249	5
426	250	5
427	251	5
428	252	5
429	253	5
430	254	5
431	255	1
432	255	4
\.


--
-- Data for Name: products_series; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.products_series (id, name, slug, brand_id, the_order) FROM stdin;
1	PASTA  STELLAシリーズ	stella	1	0
\.


--
-- Data for Name: products_tag; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.products_tag (id, name, slug, the_order) FROM stdin;
2	おいしさ長持ち	lasting	3
3	大容量	large	4
1	簡単調理	easy	2
4	冷凍	frozen	1
5	常温	dry	0
\.


--
-- Data for Name: socialaccount_socialaccount; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.socialaccount_socialaccount (id, provider, uid, last_login, date_joined, extra_data, user_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.socialaccount_socialapp (id, provider, name, client_id, secret, key) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp_sites; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.socialaccount_socialapp_sites (id, socialapp_id, site_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialtoken; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.socialaccount_socialtoken (id, token, token_secret, expires_at, account_id, app_id) FROM stdin;
\.


--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.users_user (id, password, last_login, is_superuser, username, email, is_staff, is_active, date_joined, name) FROM stdin;
1	argon2$argon2id$v=19$m=102400,t=2,p=8$amtRMzFtZ1BTVlZ3NkVWa09NRTVnRw$Ush08ZNq9fDUqVJhUSLNp710aTpAVZUS3wAcQwfEJDo	2022-03-23 02:09:39.061919+00	t	admin	kudo@green-ghost.com	t	t	2022-03-12 03:42:53.77263+00	
\.


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.users_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: pro-nsw-admin
--

COPY public.users_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.account_emailaddress_id_seq', 1, false);


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.account_emailconfirmation_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 128, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 835, true);


--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.django_celery_beat_clockedschedule_id_seq', 1, false);


--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.django_celery_beat_crontabschedule_id_seq', 1, true);


--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.django_celery_beat_intervalschedule_id_seq', 1, false);


--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.django_celery_beat_periodictask_id_seq', 1, true);


--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.django_celery_beat_solarschedule_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 32, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 78, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, false);


--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.easy_thumbnails_source_id_seq', 222, true);


--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.easy_thumbnails_thumbnail_id_seq', 351, true);


--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.easy_thumbnails_thumbnaildimensions_id_seq', 1, false);


--
-- Name: products_brand_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.products_brand_id_seq', 1, true);


--
-- Name: products_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.products_category_id_seq', 55, true);


--
-- Name: products_facility_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.products_facility_id_seq', 5, true);


--
-- Name: products_industry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.products_industry_id_seq', 7, true);


--
-- Name: products_photo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.products_photo_id_seq', 185, true);


--
-- Name: products_product_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.products_product_category_id_seq', 511, true);


--
-- Name: products_product_facility_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.products_product_facility_id_seq', 215, true);


--
-- Name: products_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.products_product_id_seq', 257, true);


--
-- Name: products_product_industry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.products_product_industry_id_seq', 502, true);


--
-- Name: products_product_related_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.products_product_related_id_seq', 1382, true);


--
-- Name: products_product_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.products_product_tag_id_seq', 432, true);


--
-- Name: products_series_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.products_series_id_seq', 1, true);


--
-- Name: products_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.products_tag_id_seq', 5, true);


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.socialaccount_socialaccount_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_sites_id_seq', 1, false);


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.socialaccount_socialtoken_id_seq', 1, false);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.users_user_id_seq', 1, true);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pro-nsw-admin
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 1, false);


--
-- Name: account_emailaddress account_emailaddress_email_key; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_email_key UNIQUE (email);


--
-- Name: account_emailaddress account_emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_pkey PRIMARY KEY (id);


--
-- Name: account_emailconfirmation account_emailconfirmation_key_key; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_key_key UNIQUE (key);


--
-- Name: account_emailconfirmation account_emailconfirmation_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: authtoken_token authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- Name: authtoken_token authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_clockedschedule django_celery_beat_clockedschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_celery_beat_clockedschedule
    ADD CONSTRAINT django_celery_beat_clockedschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_crontabschedule django_celery_beat_crontabschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_celery_beat_crontabschedule
    ADD CONSTRAINT django_celery_beat_crontabschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_intervalschedule django_celery_beat_intervalschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_celery_beat_intervalschedule
    ADD CONSTRAINT django_celery_beat_intervalschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_periodictask django_celery_beat_periodictask_name_key; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_periodictask_name_key UNIQUE (name);


--
-- Name: django_celery_beat_periodictask django_celery_beat_periodictask_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_periodictask_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_periodictasks django_celery_beat_periodictasks_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_celery_beat_periodictasks
    ADD CONSTRAINT django_celery_beat_periodictasks_pkey PRIMARY KEY (ident);


--
-- Name: django_celery_beat_solarschedule django_celery_beat_solar_event_latitude_longitude_ba64999a_uniq; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule
    ADD CONSTRAINT django_celery_beat_solar_event_latitude_longitude_ba64999a_uniq UNIQUE (event, latitude, longitude);


--
-- Name: django_celery_beat_solarschedule django_celery_beat_solarschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule
    ADD CONSTRAINT django_celery_beat_solarschedule_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_source easy_thumbnails_source_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.easy_thumbnails_source
    ADD CONSTRAINT easy_thumbnails_source_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_source easy_thumbnails_source_storage_hash_name_481ce32d_uniq; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.easy_thumbnails_source
    ADD CONSTRAINT easy_thumbnails_source_storage_hash_name_481ce32d_uniq UNIQUE (storage_hash, name);


--
-- Name: easy_thumbnails_thumbnail easy_thumbnails_thumbnai_storage_hash_name_source_fb375270_uniq; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thumbnai_storage_hash_name_source_fb375270_uniq UNIQUE (storage_hash, name, source_id);


--
-- Name: easy_thumbnails_thumbnail easy_thumbnails_thumbnail_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thumbnail_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_thumbnaildimensions easy_thumbnails_thumbnaildimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thumbnaildimensions_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_thumbnaildimensions easy_thumbnails_thumbnaildimensions_thumbnail_id_key; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thumbnaildimensions_thumbnail_id_key UNIQUE (thumbnail_id);


--
-- Name: products_brand products_brand_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_brand
    ADD CONSTRAINT products_brand_pkey PRIMARY KEY (id);


--
-- Name: products_brand products_brand_slug_key; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_brand
    ADD CONSTRAINT products_brand_slug_key UNIQUE (slug);


--
-- Name: products_category products_category_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_category
    ADD CONSTRAINT products_category_pkey PRIMARY KEY (id);


--
-- Name: products_category products_category_slug_key; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_category
    ADD CONSTRAINT products_category_slug_key UNIQUE (slug);


--
-- Name: products_facility products_facility_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_facility
    ADD CONSTRAINT products_facility_pkey PRIMARY KEY (id);


--
-- Name: products_facility products_facility_slug_key; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_facility
    ADD CONSTRAINT products_facility_slug_key UNIQUE (slug);


--
-- Name: products_industry products_industry_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_industry
    ADD CONSTRAINT products_industry_pkey PRIMARY KEY (id);


--
-- Name: products_industry products_industry_slug_key; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_industry
    ADD CONSTRAINT products_industry_slug_key UNIQUE (slug);


--
-- Name: products_photo products_photo_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_photo
    ADD CONSTRAINT products_photo_pkey PRIMARY KEY (id);


--
-- Name: products_product_category products_product_category_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_category
    ADD CONSTRAINT products_product_category_pkey PRIMARY KEY (id);


--
-- Name: products_product_category products_product_category_product_id_category_id_99b99489_uniq; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_category
    ADD CONSTRAINT products_product_category_product_id_category_id_99b99489_uniq UNIQUE (product_id, category_id);


--
-- Name: products_product_facility products_product_facility_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_facility
    ADD CONSTRAINT products_product_facility_pkey PRIMARY KEY (id);


--
-- Name: products_product_facility products_product_facility_product_id_facility_id_2cc3da46_uniq; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_facility
    ADD CONSTRAINT products_product_facility_product_id_facility_id_2cc3da46_uniq UNIQUE (product_id, facility_id);


--
-- Name: products_product_industry products_product_industry_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_industry
    ADD CONSTRAINT products_product_industry_pkey PRIMARY KEY (id);


--
-- Name: products_product_industry products_product_industry_product_id_industry_id_37c4402e_uniq; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_industry
    ADD CONSTRAINT products_product_industry_product_id_industry_id_37c4402e_uniq UNIQUE (product_id, industry_id);


--
-- Name: products_product products_product_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product
    ADD CONSTRAINT products_product_pkey PRIMARY KEY (id);


--
-- Name: products_product_related products_product_related_from_product_id_to_produ_430e04db_uniq; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_related
    ADD CONSTRAINT products_product_related_from_product_id_to_produ_430e04db_uniq UNIQUE (from_product_id, to_product_id);


--
-- Name: products_product_related products_product_related_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_related
    ADD CONSTRAINT products_product_related_pkey PRIMARY KEY (id);


--
-- Name: products_product products_product_slug_key; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product
    ADD CONSTRAINT products_product_slug_key UNIQUE (slug);


--
-- Name: products_product_tag products_product_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_tag
    ADD CONSTRAINT products_product_tag_pkey PRIMARY KEY (id);


--
-- Name: products_product_tag products_product_tag_product_id_tag_id_a36bff8d_uniq; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_tag
    ADD CONSTRAINT products_product_tag_product_id_tag_id_a36bff8d_uniq UNIQUE (product_id, tag_id);


--
-- Name: products_series products_series_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_series
    ADD CONSTRAINT products_series_pkey PRIMARY KEY (id);


--
-- Name: products_series products_series_slug_key; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_series
    ADD CONSTRAINT products_series_slug_key UNIQUE (slug);


--
-- Name: products_tag products_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_tag
    ADD CONSTRAINT products_tag_pkey PRIMARY KEY (id);


--
-- Name: products_tag products_tag_slug_key; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_tag
    ADD CONSTRAINT products_tag_slug_key UNIQUE (slug);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_provider_uid_fc810c6e_uniq; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_provider_uid_fc810c6e_uniq UNIQUE (provider, uid);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq UNIQUE (socialapp_id, site_id);


--
-- Name: socialaccount_socialapp socialaccount_socialapp_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.socialaccount_socialapp
    ADD CONSTRAINT socialaccount_socialapp_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp_sites_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq UNIQUE (app_id, account_id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_user_id_group_id_b88eab82_uniq; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_group_id_b88eab82_uniq UNIQUE (user_id, group_id);


--
-- Name: users_user users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_permission_id_43338c45_uniq; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_permission_id_43338c45_uniq UNIQUE (user_id, permission_id);


--
-- Name: users_user users_user_username_key; Type: CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_username_key UNIQUE (username);


--
-- Name: account_emailaddress_email_03be32b2_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX account_emailaddress_email_03be32b2_like ON public.account_emailaddress USING btree (email varchar_pattern_ops);


--
-- Name: account_emailaddress_user_id_2c513194; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX account_emailaddress_user_id_2c513194 ON public.account_emailaddress USING btree (user_id);


--
-- Name: account_emailconfirmation_email_address_id_5b7f8c58; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX account_emailconfirmation_email_address_id_5b7f8c58 ON public.account_emailconfirmation USING btree (email_address_id);


--
-- Name: account_emailconfirmation_key_f43612bd_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX account_emailconfirmation_key_f43612bd_like ON public.account_emailconfirmation USING btree (key varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON public.authtoken_token USING btree (key varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_celery_beat_periodictask_clocked_id_47a69f82; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX django_celery_beat_periodictask_clocked_id_47a69f82 ON public.django_celery_beat_periodictask USING btree (clocked_id);


--
-- Name: django_celery_beat_periodictask_crontab_id_d3cba168; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX django_celery_beat_periodictask_crontab_id_d3cba168 ON public.django_celery_beat_periodictask USING btree (crontab_id);


--
-- Name: django_celery_beat_periodictask_interval_id_a8ca27da; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX django_celery_beat_periodictask_interval_id_a8ca27da ON public.django_celery_beat_periodictask USING btree (interval_id);


--
-- Name: django_celery_beat_periodictask_name_265a36b7_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX django_celery_beat_periodictask_name_265a36b7_like ON public.django_celery_beat_periodictask USING btree (name varchar_pattern_ops);


--
-- Name: django_celery_beat_periodictask_solar_id_a87ce72c; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX django_celery_beat_periodictask_solar_id_a87ce72c ON public.django_celery_beat_periodictask USING btree (solar_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: easy_thumbnails_source_name_5fe0edc6; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX easy_thumbnails_source_name_5fe0edc6 ON public.easy_thumbnails_source USING btree (name);


--
-- Name: easy_thumbnails_source_name_5fe0edc6_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX easy_thumbnails_source_name_5fe0edc6_like ON public.easy_thumbnails_source USING btree (name varchar_pattern_ops);


--
-- Name: easy_thumbnails_source_storage_hash_946cbcc9; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX easy_thumbnails_source_storage_hash_946cbcc9 ON public.easy_thumbnails_source USING btree (storage_hash);


--
-- Name: easy_thumbnails_source_storage_hash_946cbcc9_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX easy_thumbnails_source_storage_hash_946cbcc9_like ON public.easy_thumbnails_source USING btree (storage_hash varchar_pattern_ops);


--
-- Name: easy_thumbnails_thumbnail_name_b5882c31; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX easy_thumbnails_thumbnail_name_b5882c31 ON public.easy_thumbnails_thumbnail USING btree (name);


--
-- Name: easy_thumbnails_thumbnail_name_b5882c31_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX easy_thumbnails_thumbnail_name_b5882c31_like ON public.easy_thumbnails_thumbnail USING btree (name varchar_pattern_ops);


--
-- Name: easy_thumbnails_thumbnail_source_id_5b57bc77; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX easy_thumbnails_thumbnail_source_id_5b57bc77 ON public.easy_thumbnails_thumbnail USING btree (source_id);


--
-- Name: easy_thumbnails_thumbnail_storage_hash_f1435f49; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX easy_thumbnails_thumbnail_storage_hash_f1435f49 ON public.easy_thumbnails_thumbnail USING btree (storage_hash);


--
-- Name: easy_thumbnails_thumbnail_storage_hash_f1435f49_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX easy_thumbnails_thumbnail_storage_hash_f1435f49_like ON public.easy_thumbnails_thumbnail USING btree (storage_hash varchar_pattern_ops);


--
-- Name: products_brand_slug_925fd11b_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_brand_slug_925fd11b_like ON public.products_brand USING btree (slug varchar_pattern_ops);


--
-- Name: products_brand_the_order_f5a53cec; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_brand_the_order_f5a53cec ON public.products_brand USING btree (the_order);


--
-- Name: products_category_parent_id_3388f6c9; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_category_parent_id_3388f6c9 ON public.products_category USING btree (parent_id);


--
-- Name: products_category_slug_c558efae_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_category_slug_c558efae_like ON public.products_category USING btree (slug varchar_pattern_ops);


--
-- Name: products_category_the_order_b2316960; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_category_the_order_b2316960 ON public.products_category USING btree (the_order);


--
-- Name: products_category_title_3e22be6c; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_category_title_3e22be6c ON public.products_category USING btree (title);


--
-- Name: products_category_title_3e22be6c_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_category_title_3e22be6c_like ON public.products_category USING btree (title varchar_pattern_ops);


--
-- Name: products_category_title_en_d4a40b94; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_category_title_en_d4a40b94 ON public.products_category USING btree (title_en);


--
-- Name: products_category_title_en_d4a40b94_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_category_title_en_d4a40b94_like ON public.products_category USING btree (title_en varchar_pattern_ops);


--
-- Name: products_category_tree_id_7d9b3ae8; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_category_tree_id_7d9b3ae8 ON public.products_category USING btree (tree_id);


--
-- Name: products_facility_slug_5bf55013_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_facility_slug_5bf55013_like ON public.products_facility USING btree (slug varchar_pattern_ops);


--
-- Name: products_facility_the_order_17cd736f; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_facility_the_order_17cd736f ON public.products_facility USING btree (the_order);


--
-- Name: products_industry_slug_2cee7556_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_industry_slug_2cee7556_like ON public.products_industry USING btree (slug varchar_pattern_ops);


--
-- Name: products_industry_the_order_2101993c; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_industry_the_order_2101993c ON public.products_industry USING btree (the_order);


--
-- Name: products_photo_product_id_05315375; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_photo_product_id_05315375 ON public.products_photo USING btree (product_id);


--
-- Name: products_product_brand_id_3e2e8fd1; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_product_brand_id_3e2e8fd1 ON public.products_product USING btree (brand_id);


--
-- Name: products_product_category_category_id_6bd7b606; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_product_category_category_id_6bd7b606 ON public.products_product_category USING btree (category_id);


--
-- Name: products_product_category_product_id_08fb2842; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_product_category_product_id_08fb2842 ON public.products_product_category USING btree (product_id);


--
-- Name: products_product_facility_facility_id_62ecee91; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_product_facility_facility_id_62ecee91 ON public.products_product_facility USING btree (facility_id);


--
-- Name: products_product_facility_product_id_7fd56ac6; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_product_facility_product_id_7fd56ac6 ON public.products_product_facility USING btree (product_id);


--
-- Name: products_product_industry_industry_id_be8f727d; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_product_industry_industry_id_be8f727d ON public.products_product_industry USING btree (industry_id);


--
-- Name: products_product_industry_product_id_ad2bf82b; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_product_industry_product_id_ad2bf82b ON public.products_product_industry USING btree (product_id);


--
-- Name: products_product_related_from_product_id_b903e820; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_product_related_from_product_id_b903e820 ON public.products_product_related USING btree (from_product_id);


--
-- Name: products_product_related_to_product_id_306018a2; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_product_related_to_product_id_306018a2 ON public.products_product_related USING btree (to_product_id);


--
-- Name: products_product_series_id_7d8970b3; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_product_series_id_7d8970b3 ON public.products_product USING btree (series_id);


--
-- Name: products_product_slug_70d3148d_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_product_slug_70d3148d_like ON public.products_product USING btree (slug varchar_pattern_ops);


--
-- Name: products_product_tag_product_id_df3b2f29; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_product_tag_product_id_df3b2f29 ON public.products_product_tag USING btree (product_id);


--
-- Name: products_product_tag_tag_id_d99e66b5; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_product_tag_tag_id_d99e66b5 ON public.products_product_tag USING btree (tag_id);


--
-- Name: products_product_the_order_4c095b91; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_product_the_order_4c095b91 ON public.products_product USING btree (the_order);


--
-- Name: products_series_series_id_19b01f60; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_series_series_id_19b01f60 ON public.products_series USING btree (brand_id);


--
-- Name: products_series_slug_eb8209d5_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_series_slug_eb8209d5_like ON public.products_series USING btree (slug varchar_pattern_ops);


--
-- Name: products_series_the_order_a7c2ecc7; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_series_the_order_a7c2ecc7 ON public.products_series USING btree (the_order);


--
-- Name: products_tag_slug_5def095b_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_tag_slug_5def095b_like ON public.products_tag USING btree (slug varchar_pattern_ops);


--
-- Name: products_tag_the_order_029fc34c; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX products_tag_the_order_029fc34c ON public.products_tag USING btree (the_order);


--
-- Name: socialaccount_socialaccount_user_id_8146e70c; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX socialaccount_socialaccount_user_id_8146e70c ON public.socialaccount_socialaccount USING btree (user_id);


--
-- Name: socialaccount_socialapp_sites_site_id_2579dee5; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX socialaccount_socialapp_sites_site_id_2579dee5 ON public.socialaccount_socialapp_sites USING btree (site_id);


--
-- Name: socialaccount_socialapp_sites_socialapp_id_97fb6e7d; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX socialaccount_socialapp_sites_socialapp_id_97fb6e7d ON public.socialaccount_socialapp_sites USING btree (socialapp_id);


--
-- Name: socialaccount_socialtoken_account_id_951f210e; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX socialaccount_socialtoken_account_id_951f210e ON public.socialaccount_socialtoken USING btree (account_id);


--
-- Name: socialaccount_socialtoken_app_id_636a42d7; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX socialaccount_socialtoken_app_id_636a42d7 ON public.socialaccount_socialtoken USING btree (app_id);


--
-- Name: users_user_groups_group_id_9afc8d0e; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX users_user_groups_group_id_9afc8d0e ON public.users_user_groups USING btree (group_id);


--
-- Name: users_user_groups_user_id_5f6f5a90; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX users_user_groups_user_id_5f6f5a90 ON public.users_user_groups USING btree (user_id);


--
-- Name: users_user_user_permissions_permission_id_0b93982e; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX users_user_user_permissions_permission_id_0b93982e ON public.users_user_user_permissions USING btree (permission_id);


--
-- Name: users_user_user_permissions_user_id_20aca447; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX users_user_user_permissions_user_id_20aca447 ON public.users_user_user_permissions USING btree (user_id);


--
-- Name: users_user_username_06e46fe6_like; Type: INDEX; Schema: public; Owner: pro-nsw-admin
--

CREATE INDEX users_user_username_06e46fe6_like ON public.users_user USING btree (username varchar_pattern_ops);


--
-- Name: account_emailaddress account_emailaddress_user_id_2c513194_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_user_id_2c513194_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_emailconfirmation account_emailconfirm_email_address_id_5b7f8c58_fk_account_e; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirm_email_address_id_5b7f8c58_fk_account_e FOREIGN KEY (email_address_id) REFERENCES public.account_emailaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authtoken_token authtoken_token_user_id_35299eff_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_clocked_id_47a69f82_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_clocked_id_47a69f82_fk_django_ce FOREIGN KEY (clocked_id) REFERENCES public.django_celery_beat_clockedschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_crontab_id_d3cba168_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_crontab_id_d3cba168_fk_django_ce FOREIGN KEY (crontab_id) REFERENCES public.django_celery_beat_crontabschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_interval_id_a8ca27da_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_interval_id_a8ca27da_fk_django_ce FOREIGN KEY (interval_id) REFERENCES public.django_celery_beat_intervalschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_solar_id_a87ce72c_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_solar_id_a87ce72c_fk_django_ce FOREIGN KEY (solar_id) REFERENCES public.django_celery_beat_solarschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: easy_thumbnails_thumbnail easy_thumbnails_thum_source_id_5b57bc77_fk_easy_thum; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thum_source_id_5b57bc77_fk_easy_thum FOREIGN KEY (source_id) REFERENCES public.easy_thumbnails_source(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: easy_thumbnails_thumbnaildimensions easy_thumbnails_thum_thumbnail_id_c3a0c549_fk_easy_thum; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thum_thumbnail_id_c3a0c549_fk_easy_thum FOREIGN KEY (thumbnail_id) REFERENCES public.easy_thumbnails_thumbnail(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_category products_category_parent_id_3388f6c9_fk_products_category_id; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_category
    ADD CONSTRAINT products_category_parent_id_3388f6c9_fk_products_category_id FOREIGN KEY (parent_id) REFERENCES public.products_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_photo products_photo_product_id_05315375_fk_products_product_id; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_photo
    ADD CONSTRAINT products_photo_product_id_05315375_fk_products_product_id FOREIGN KEY (product_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product products_product_brand_id_3e2e8fd1_fk_products_brand_id; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product
    ADD CONSTRAINT products_product_brand_id_3e2e8fd1_fk_products_brand_id FOREIGN KEY (brand_id) REFERENCES public.products_brand(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_category products_product_cat_category_id_6bd7b606_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_category
    ADD CONSTRAINT products_product_cat_category_id_6bd7b606_fk_products_ FOREIGN KEY (category_id) REFERENCES public.products_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_category products_product_cat_product_id_08fb2842_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_category
    ADD CONSTRAINT products_product_cat_product_id_08fb2842_fk_products_ FOREIGN KEY (product_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_facility products_product_fac_facility_id_62ecee91_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_facility
    ADD CONSTRAINT products_product_fac_facility_id_62ecee91_fk_products_ FOREIGN KEY (facility_id) REFERENCES public.products_facility(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_facility products_product_fac_product_id_7fd56ac6_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_facility
    ADD CONSTRAINT products_product_fac_product_id_7fd56ac6_fk_products_ FOREIGN KEY (product_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_industry products_product_ind_industry_id_be8f727d_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_industry
    ADD CONSTRAINT products_product_ind_industry_id_be8f727d_fk_products_ FOREIGN KEY (industry_id) REFERENCES public.products_industry(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_industry products_product_ind_product_id_ad2bf82b_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_industry
    ADD CONSTRAINT products_product_ind_product_id_ad2bf82b_fk_products_ FOREIGN KEY (product_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_related products_product_rel_from_product_id_b903e820_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_related
    ADD CONSTRAINT products_product_rel_from_product_id_b903e820_fk_products_ FOREIGN KEY (from_product_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_related products_product_rel_to_product_id_306018a2_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_related
    ADD CONSTRAINT products_product_rel_to_product_id_306018a2_fk_products_ FOREIGN KEY (to_product_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product products_product_series_id_7d8970b3_fk_products_series_id; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product
    ADD CONSTRAINT products_product_series_id_7d8970b3_fk_products_series_id FOREIGN KEY (series_id) REFERENCES public.products_series(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_tag products_product_tag_product_id_df3b2f29_fk_products_product_id; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_tag
    ADD CONSTRAINT products_product_tag_product_id_df3b2f29_fk_products_product_id FOREIGN KEY (product_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_tag products_product_tag_tag_id_d99e66b5_fk_products_tag_id; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_product_tag
    ADD CONSTRAINT products_product_tag_tag_id_d99e66b5_fk_products_tag_id FOREIGN KEY (tag_id) REFERENCES public.products_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_series products_series_brand_id_a12f2856_fk_products_brand_id; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.products_series
    ADD CONSTRAINT products_series_brand_id_a12f2856_fk_products_brand_id FOREIGN KEY (brand_id) REFERENCES public.products_brand(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_account_id_951f210e_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_account_id_951f210e_fk_socialacc FOREIGN KEY (account_id) REFERENCES public.socialaccount_socialaccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_app_id_636a42d7_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_app_id_636a42d7_fk_socialacc FOREIGN KEY (app_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_site_id_2579dee5_fk_django_si; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_site_id_2579dee5_fk_django_si FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc FOREIGN KEY (socialapp_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_group_id_9afc8d0e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_group_id_9afc8d0e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_user_id_5f6f5a90_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_5f6f5a90_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_perm_permission_id_0b93982e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_perm_permission_id_0b93982e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_20aca447_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: pro-nsw-admin
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_20aca447_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

