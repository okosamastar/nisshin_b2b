--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1 (Debian 14.1-1.pgdg110+1)
-- Dumped by pg_dump version 14.1 (Debian 14.1-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_emailaddress; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.account_emailaddress (
    id integer NOT NULL,
    email character varying(254) NOT NULL,
    verified boolean NOT NULL,
    "primary" boolean NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.account_emailaddress OWNER TO debug;

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.account_emailaddress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailaddress_id_seq OWNER TO debug;

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.account_emailaddress_id_seq OWNED BY public.account_emailaddress.id;


--
-- Name: account_emailconfirmation; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.account_emailconfirmation (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    sent timestamp with time zone,
    key character varying(64) NOT NULL,
    email_address_id integer NOT NULL
);


ALTER TABLE public.account_emailconfirmation OWNER TO debug;

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.account_emailconfirmation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailconfirmation_id_seq OWNER TO debug;

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.account_emailconfirmation_id_seq OWNED BY public.account_emailconfirmation.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO debug;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO debug;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO debug;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO debug;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO debug;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO debug;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.authtoken_token OWNER TO debug;

--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id bigint NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO debug;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO debug;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_celery_beat_clockedschedule; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_celery_beat_clockedschedule (
    id integer NOT NULL,
    clocked_time timestamp with time zone NOT NULL
);


ALTER TABLE public.django_celery_beat_clockedschedule OWNER TO debug;

--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_celery_beat_clockedschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_clockedschedule_id_seq OWNER TO debug;

--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_celery_beat_clockedschedule_id_seq OWNED BY public.django_celery_beat_clockedschedule.id;


--
-- Name: django_celery_beat_crontabschedule; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_celery_beat_crontabschedule (
    id integer NOT NULL,
    minute character varying(240) NOT NULL,
    hour character varying(96) NOT NULL,
    day_of_week character varying(64) NOT NULL,
    day_of_month character varying(124) NOT NULL,
    month_of_year character varying(64) NOT NULL,
    timezone character varying(63) NOT NULL
);


ALTER TABLE public.django_celery_beat_crontabschedule OWNER TO debug;

--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_celery_beat_crontabschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_crontabschedule_id_seq OWNER TO debug;

--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_celery_beat_crontabschedule_id_seq OWNED BY public.django_celery_beat_crontabschedule.id;


--
-- Name: django_celery_beat_intervalschedule; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_celery_beat_intervalschedule (
    id integer NOT NULL,
    every integer NOT NULL,
    period character varying(24) NOT NULL
);


ALTER TABLE public.django_celery_beat_intervalschedule OWNER TO debug;

--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_celery_beat_intervalschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_intervalschedule_id_seq OWNER TO debug;

--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_celery_beat_intervalschedule_id_seq OWNED BY public.django_celery_beat_intervalschedule.id;


--
-- Name: django_celery_beat_periodictask; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_celery_beat_periodictask (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    task character varying(200) NOT NULL,
    args text NOT NULL,
    kwargs text NOT NULL,
    queue character varying(200),
    exchange character varying(200),
    routing_key character varying(200),
    expires timestamp with time zone,
    enabled boolean NOT NULL,
    last_run_at timestamp with time zone,
    total_run_count integer NOT NULL,
    date_changed timestamp with time zone NOT NULL,
    description text NOT NULL,
    crontab_id integer,
    interval_id integer,
    solar_id integer,
    one_off boolean NOT NULL,
    start_time timestamp with time zone,
    priority integer,
    headers text NOT NULL,
    clocked_id integer,
    expire_seconds integer,
    CONSTRAINT django_celery_beat_periodictask_expire_seconds_check CHECK ((expire_seconds >= 0)),
    CONSTRAINT django_celery_beat_periodictask_priority_check CHECK ((priority >= 0)),
    CONSTRAINT django_celery_beat_periodictask_total_run_count_check CHECK ((total_run_count >= 0))
);


ALTER TABLE public.django_celery_beat_periodictask OWNER TO debug;

--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_celery_beat_periodictask_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_periodictask_id_seq OWNER TO debug;

--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_celery_beat_periodictask_id_seq OWNED BY public.django_celery_beat_periodictask.id;


--
-- Name: django_celery_beat_periodictasks; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_celery_beat_periodictasks (
    ident smallint NOT NULL,
    last_update timestamp with time zone NOT NULL
);


ALTER TABLE public.django_celery_beat_periodictasks OWNER TO debug;

--
-- Name: django_celery_beat_solarschedule; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_celery_beat_solarschedule (
    id integer NOT NULL,
    event character varying(24) NOT NULL,
    latitude numeric(9,6) NOT NULL,
    longitude numeric(9,6) NOT NULL
);


ALTER TABLE public.django_celery_beat_solarschedule OWNER TO debug;

--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_celery_beat_solarschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_celery_beat_solarschedule_id_seq OWNER TO debug;

--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_celery_beat_solarschedule_id_seq OWNED BY public.django_celery_beat_solarschedule.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO debug;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO debug;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO debug;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO debug;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO debug;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO debug;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO debug;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: easy_thumbnails_source; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.easy_thumbnails_source (
    id integer NOT NULL,
    storage_hash character varying(40) NOT NULL,
    name character varying(255) NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE public.easy_thumbnails_source OWNER TO debug;

--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.easy_thumbnails_source_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.easy_thumbnails_source_id_seq OWNER TO debug;

--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.easy_thumbnails_source_id_seq OWNED BY public.easy_thumbnails_source.id;


--
-- Name: easy_thumbnails_thumbnail; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.easy_thumbnails_thumbnail (
    id integer NOT NULL,
    storage_hash character varying(40) NOT NULL,
    name character varying(255) NOT NULL,
    modified timestamp with time zone NOT NULL,
    source_id integer NOT NULL
);


ALTER TABLE public.easy_thumbnails_thumbnail OWNER TO debug;

--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.easy_thumbnails_thumbnail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.easy_thumbnails_thumbnail_id_seq OWNER TO debug;

--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.easy_thumbnails_thumbnail_id_seq OWNED BY public.easy_thumbnails_thumbnail.id;


--
-- Name: easy_thumbnails_thumbnaildimensions; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.easy_thumbnails_thumbnaildimensions (
    id integer NOT NULL,
    thumbnail_id integer NOT NULL,
    width integer,
    height integer,
    CONSTRAINT easy_thumbnails_thumbnaildimensions_height_check CHECK ((height >= 0)),
    CONSTRAINT easy_thumbnails_thumbnaildimensions_width_check CHECK ((width >= 0))
);


ALTER TABLE public.easy_thumbnails_thumbnaildimensions OWNER TO debug;

--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.easy_thumbnails_thumbnaildimensions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.easy_thumbnails_thumbnaildimensions_id_seq OWNER TO debug;

--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.easy_thumbnails_thumbnaildimensions_id_seq OWNED BY public.easy_thumbnails_thumbnaildimensions.id;


--
-- Name: products_brand; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.products_brand (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    product_id bigint NOT NULL,
    series_id bigint NOT NULL
);


ALTER TABLE public.products_brand OWNER TO debug;

--
-- Name: products_brand_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.products_brand_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_brand_id_seq OWNER TO debug;

--
-- Name: products_brand_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.products_brand_id_seq OWNED BY public.products_brand.id;


--
-- Name: products_category; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.products_category (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    hero character varying(100) NOT NULL,
    photo character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    lft integer NOT NULL,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    level integer NOT NULL,
    parent_id bigint,
    CONSTRAINT products_category_level_check CHECK ((level >= 0)),
    CONSTRAINT products_category_lft_check CHECK ((lft >= 0)),
    CONSTRAINT products_category_rght_check CHECK ((rght >= 0)),
    CONSTRAINT products_category_tree_id_check CHECK ((tree_id >= 0))
);


ALTER TABLE public.products_category OWNER TO debug;

--
-- Name: products_category_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.products_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_category_id_seq OWNER TO debug;

--
-- Name: products_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.products_category_id_seq OWNED BY public.products_category.id;


--
-- Name: products_facility; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.products_facility (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(100) NOT NULL
);


ALTER TABLE public.products_facility OWNER TO debug;

--
-- Name: products_facility_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.products_facility_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_facility_id_seq OWNER TO debug;

--
-- Name: products_facility_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.products_facility_id_seq OWNED BY public.products_facility.id;


--
-- Name: products_handling; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.products_handling (
    id bigint NOT NULL,
    water character varying(255) NOT NULL,
    "time" character varying(255) NOT NULL,
    temperature character varying(255) NOT NULL,
    recipe character varying(255) NOT NULL,
    product_id bigint NOT NULL
);


ALTER TABLE public.products_handling OWNER TO debug;

--
-- Name: products_handling_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.products_handling_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_handling_id_seq OWNER TO debug;

--
-- Name: products_handling_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.products_handling_id_seq OWNED BY public.products_handling.id;


--
-- Name: products_industry; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.products_industry (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    hero character varying(100) NOT NULL,
    photo character varying(100) NOT NULL,
    slug character varying(100) NOT NULL
);


ALTER TABLE public.products_industry OWNER TO debug;

--
-- Name: products_industry_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.products_industry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_industry_id_seq OWNER TO debug;

--
-- Name: products_industry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.products_industry_id_seq OWNED BY public.products_industry.id;


--
-- Name: products_photo; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.products_photo (
    id bigint NOT NULL,
    photo character varying(100) NOT NULL,
    label character varying(100) NOT NULL,
    product_id bigint NOT NULL
);


ALTER TABLE public.products_photo OWNER TO debug;

--
-- Name: products_photo_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.products_photo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_photo_id_seq OWNER TO debug;

--
-- Name: products_photo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.products_photo_id_seq OWNED BY public.products_photo.id;


--
-- Name: products_product; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.products_product (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    subtitle character varying(255),
    slug character varying(50) NOT NULL,
    price numeric(5,2),
    description text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    hero character varying(100) NOT NULL,
    preservation character varying(100) NOT NULL,
    is_new boolean NOT NULL,
    is_published boolean NOT NULL,
    shipping_date timestamp with time zone
);


ALTER TABLE public.products_product OWNER TO debug;

--
-- Name: products_product_category; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.products_product_category (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    category_id bigint NOT NULL
);


ALTER TABLE public.products_product_category OWNER TO debug;

--
-- Name: products_product_category_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.products_product_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_product_category_id_seq OWNER TO debug;

--
-- Name: products_product_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.products_product_category_id_seq OWNED BY public.products_product_category.id;


--
-- Name: products_product_facility; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.products_product_facility (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    facility_id bigint NOT NULL
);


ALTER TABLE public.products_product_facility OWNER TO debug;

--
-- Name: products_product_facility_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.products_product_facility_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_product_facility_id_seq OWNER TO debug;

--
-- Name: products_product_facility_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.products_product_facility_id_seq OWNED BY public.products_product_facility.id;


--
-- Name: products_product_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.products_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_product_id_seq OWNER TO debug;

--
-- Name: products_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.products_product_id_seq OWNED BY public.products_product.id;


--
-- Name: products_product_industry; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.products_product_industry (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    industry_id bigint NOT NULL
);


ALTER TABLE public.products_product_industry OWNER TO debug;

--
-- Name: products_product_industry_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.products_product_industry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_product_industry_id_seq OWNER TO debug;

--
-- Name: products_product_industry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.products_product_industry_id_seq OWNED BY public.products_product_industry.id;


--
-- Name: products_product_tag; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.products_product_tag (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    tag_id bigint NOT NULL
);


ALTER TABLE public.products_product_tag OWNER TO debug;

--
-- Name: products_product_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.products_product_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_product_tag_id_seq OWNER TO debug;

--
-- Name: products_product_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.products_product_tag_id_seq OWNED BY public.products_product_tag.id;


--
-- Name: products_series; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.products_series (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    product_id bigint NOT NULL
);


ALTER TABLE public.products_series OWNER TO debug;

--
-- Name: products_series_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.products_series_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_series_id_seq OWNER TO debug;

--
-- Name: products_series_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.products_series_id_seq OWNED BY public.products_series.id;


--
-- Name: products_tag; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.products_tag (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(100) NOT NULL
);


ALTER TABLE public.products_tag OWNER TO debug;

--
-- Name: products_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.products_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_tag_id_seq OWNER TO debug;

--
-- Name: products_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.products_tag_id_seq OWNED BY public.products_tag.id;


--
-- Name: socialaccount_socialaccount; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.socialaccount_socialaccount (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    uid character varying(191) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    extra_data text NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.socialaccount_socialaccount OWNER TO debug;

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.socialaccount_socialaccount_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialaccount_id_seq OWNER TO debug;

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.socialaccount_socialaccount_id_seq OWNED BY public.socialaccount_socialaccount.id;


--
-- Name: socialaccount_socialapp; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.socialaccount_socialapp (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    name character varying(40) NOT NULL,
    client_id character varying(191) NOT NULL,
    secret character varying(191) NOT NULL,
    key character varying(191) NOT NULL
);


ALTER TABLE public.socialaccount_socialapp OWNER TO debug;

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.socialaccount_socialapp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_id_seq OWNER TO debug;

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.socialaccount_socialapp_id_seq OWNED BY public.socialaccount_socialapp.id;


--
-- Name: socialaccount_socialapp_sites; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.socialaccount_socialapp_sites (
    id bigint NOT NULL,
    socialapp_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialapp_sites OWNER TO debug;

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.socialaccount_socialapp_sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_sites_id_seq OWNER TO debug;

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.socialaccount_socialapp_sites_id_seq OWNED BY public.socialaccount_socialapp_sites.id;


--
-- Name: socialaccount_socialtoken; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.socialaccount_socialtoken (
    id integer NOT NULL,
    token text NOT NULL,
    token_secret text NOT NULL,
    expires_at timestamp with time zone,
    account_id integer NOT NULL,
    app_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialtoken OWNER TO debug;

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.socialaccount_socialtoken_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialtoken_id_seq OWNER TO debug;

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.socialaccount_socialtoken_id_seq OWNED BY public.socialaccount_socialtoken.id;


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_user (
    id bigint NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.users_user OWNER TO debug;

--
-- Name: users_user_groups; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_user_groups (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.users_user_groups OWNER TO debug;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_groups_id_seq OWNER TO debug;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_user_groups_id_seq OWNED BY public.users_user_groups.id;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO debug;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users_user.id;


--
-- Name: users_user_user_permissions; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_user_user_permissions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.users_user_user_permissions OWNER TO debug;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_user_permissions_id_seq OWNER TO debug;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_user_user_permissions_id_seq OWNED BY public.users_user_user_permissions.id;


--
-- Name: account_emailaddress id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailaddress ALTER COLUMN id SET DEFAULT nextval('public.account_emailaddress_id_seq'::regclass);


--
-- Name: account_emailconfirmation id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailconfirmation ALTER COLUMN id SET DEFAULT nextval('public.account_emailconfirmation_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_celery_beat_clockedschedule id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_clockedschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_clockedschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_crontabschedule id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_crontabschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_crontabschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_intervalschedule id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_intervalschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_intervalschedule_id_seq'::regclass);


--
-- Name: django_celery_beat_periodictask id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_periodictask ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_periodictask_id_seq'::regclass);


--
-- Name: django_celery_beat_solarschedule id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule ALTER COLUMN id SET DEFAULT nextval('public.django_celery_beat_solarschedule_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: easy_thumbnails_source id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.easy_thumbnails_source ALTER COLUMN id SET DEFAULT nextval('public.easy_thumbnails_source_id_seq'::regclass);


--
-- Name: easy_thumbnails_thumbnail id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnail ALTER COLUMN id SET DEFAULT nextval('public.easy_thumbnails_thumbnail_id_seq'::regclass);


--
-- Name: easy_thumbnails_thumbnaildimensions id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions ALTER COLUMN id SET DEFAULT nextval('public.easy_thumbnails_thumbnaildimensions_id_seq'::regclass);


--
-- Name: products_brand id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_brand ALTER COLUMN id SET DEFAULT nextval('public.products_brand_id_seq'::regclass);


--
-- Name: products_category id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_category ALTER COLUMN id SET DEFAULT nextval('public.products_category_id_seq'::regclass);


--
-- Name: products_facility id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_facility ALTER COLUMN id SET DEFAULT nextval('public.products_facility_id_seq'::regclass);


--
-- Name: products_handling id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_handling ALTER COLUMN id SET DEFAULT nextval('public.products_handling_id_seq'::regclass);


--
-- Name: products_industry id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_industry ALTER COLUMN id SET DEFAULT nextval('public.products_industry_id_seq'::regclass);


--
-- Name: products_photo id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_photo ALTER COLUMN id SET DEFAULT nextval('public.products_photo_id_seq'::regclass);


--
-- Name: products_product id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product ALTER COLUMN id SET DEFAULT nextval('public.products_product_id_seq'::regclass);


--
-- Name: products_product_category id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_category ALTER COLUMN id SET DEFAULT nextval('public.products_product_category_id_seq'::regclass);


--
-- Name: products_product_facility id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_facility ALTER COLUMN id SET DEFAULT nextval('public.products_product_facility_id_seq'::regclass);


--
-- Name: products_product_industry id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_industry ALTER COLUMN id SET DEFAULT nextval('public.products_product_industry_id_seq'::regclass);


--
-- Name: products_product_tag id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_tag ALTER COLUMN id SET DEFAULT nextval('public.products_product_tag_id_seq'::regclass);


--
-- Name: products_series id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_series ALTER COLUMN id SET DEFAULT nextval('public.products_series_id_seq'::regclass);


--
-- Name: products_tag id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_tag ALTER COLUMN id SET DEFAULT nextval('public.products_tag_id_seq'::regclass);


--
-- Name: socialaccount_socialaccount id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialaccount ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialaccount_id_seq'::regclass);


--
-- Name: socialaccount_socialapp id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_id_seq'::regclass);


--
-- Name: socialaccount_socialapp_sites id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_sites_id_seq'::regclass);


--
-- Name: socialaccount_socialtoken id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialtoken_id_seq'::regclass);


--
-- Name: users_user id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user ALTER COLUMN id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: users_user_groups id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups ALTER COLUMN id SET DEFAULT nextval('public.users_user_groups_id_seq'::regclass);


--
-- Name: users_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.users_user_user_permissions_id_seq'::regclass);


--
-- Data for Name: account_emailaddress; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.account_emailaddress (id, email, verified, "primary", user_id) FROM stdin;
\.


--
-- Data for Name: account_emailconfirmation; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.account_emailconfirmation (id, created, sent, key, email_address_id) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can view permission	1	view_permission
5	Can add group	2	add_group
6	Can change group	2	change_group
7	Can delete group	2	delete_group
8	Can view group	2	view_group
9	Can add content type	3	add_contenttype
10	Can change content type	3	change_contenttype
11	Can delete content type	3	delete_contenttype
12	Can view content type	3	view_contenttype
13	Can add session	4	add_session
14	Can change session	4	change_session
15	Can delete session	4	delete_session
16	Can view session	4	view_session
17	Can add site	5	add_site
18	Can change site	5	change_site
19	Can delete site	5	delete_site
20	Can view site	5	view_site
21	Can add log entry	6	add_logentry
22	Can change log entry	6	change_logentry
23	Can delete log entry	6	delete_logentry
24	Can view log entry	6	view_logentry
25	Can add email address	7	add_emailaddress
26	Can change email address	7	change_emailaddress
27	Can delete email address	7	delete_emailaddress
28	Can view email address	7	view_emailaddress
29	Can add email confirmation	8	add_emailconfirmation
30	Can change email confirmation	8	change_emailconfirmation
31	Can delete email confirmation	8	delete_emailconfirmation
32	Can view email confirmation	8	view_emailconfirmation
33	Can add social account	9	add_socialaccount
34	Can change social account	9	change_socialaccount
35	Can delete social account	9	delete_socialaccount
36	Can view social account	9	view_socialaccount
37	Can add social application	10	add_socialapp
38	Can change social application	10	change_socialapp
39	Can delete social application	10	delete_socialapp
40	Can view social application	10	view_socialapp
41	Can add social application token	11	add_socialtoken
42	Can change social application token	11	change_socialtoken
43	Can delete social application token	11	delete_socialtoken
44	Can view social application token	11	view_socialtoken
45	Can add crontab	12	add_crontabschedule
46	Can change crontab	12	change_crontabschedule
47	Can delete crontab	12	delete_crontabschedule
48	Can view crontab	12	view_crontabschedule
49	Can add interval	13	add_intervalschedule
50	Can change interval	13	change_intervalschedule
51	Can delete interval	13	delete_intervalschedule
52	Can view interval	13	view_intervalschedule
53	Can add periodic task	14	add_periodictask
54	Can change periodic task	14	change_periodictask
55	Can delete periodic task	14	delete_periodictask
56	Can view periodic task	14	view_periodictask
57	Can add periodic tasks	15	add_periodictasks
58	Can change periodic tasks	15	change_periodictasks
59	Can delete periodic tasks	15	delete_periodictasks
60	Can view periodic tasks	15	view_periodictasks
61	Can add solar event	16	add_solarschedule
62	Can change solar event	16	change_solarschedule
63	Can delete solar event	16	delete_solarschedule
64	Can view solar event	16	view_solarschedule
65	Can add clocked	17	add_clockedschedule
66	Can change clocked	17	change_clockedschedule
67	Can delete clocked	17	delete_clockedschedule
68	Can view clocked	17	view_clockedschedule
69	Can add Token	18	add_token
70	Can change Token	18	change_token
71	Can delete Token	18	delete_token
72	Can view Token	18	view_token
73	Can add token	19	add_tokenproxy
74	Can change token	19	change_tokenproxy
75	Can delete token	19	delete_tokenproxy
76	Can view token	19	view_tokenproxy
77	Can add user	20	add_user
78	Can change user	20	change_user
79	Can delete user	20	delete_user
80	Can view user	20	view_user
81	Can add source	21	add_source
82	Can change source	21	change_source
83	Can delete source	21	delete_source
84	Can view source	21	view_source
85	Can add thumbnail	22	add_thumbnail
86	Can change thumbnail	22	change_thumbnail
87	Can delete thumbnail	22	delete_thumbnail
88	Can view thumbnail	22	view_thumbnail
89	Can add thumbnail dimensions	23	add_thumbnaildimensions
90	Can change thumbnail dimensions	23	change_thumbnaildimensions
91	Can delete thumbnail dimensions	23	delete_thumbnaildimensions
92	Can view thumbnail dimensions	23	view_thumbnaildimensions
93	Can add category	24	add_category
94	Can change category	24	change_category
95	Can delete category	24	delete_category
96	Can view category	24	view_category
97	Can add product	25	add_product
98	Can change product	25	change_product
99	Can delete product	25	delete_product
100	Can view product	25	view_product
101	Can add facility	26	add_facility
102	Can change facility	26	change_facility
103	Can delete facility	26	delete_facility
104	Can view facility	26	view_facility
105	Can add industry	27	add_industry
106	Can change industry	27	change_industry
107	Can delete industry	27	delete_industry
108	Can view industry	27	view_industry
109	Can add tag	28	add_tag
110	Can change tag	28	change_tag
111	Can delete tag	28	delete_tag
112	Can view tag	28	view_tag
113	Can add series	29	add_series
114	Can change series	29	change_series
115	Can delete series	29	delete_series
116	Can view series	29	view_series
117	Can add photo	30	add_photo
118	Can change photo	30	change_photo
119	Can delete photo	30	delete_photo
120	Can view photo	30	view_photo
121	Can add handling	31	add_handling
122	Can change handling	31	change_handling
123	Can delete handling	31	delete_handling
124	Can view handling	31	view_handling
125	Can add brand	32	add_brand
126	Can change brand	32	change_brand
127	Can delete brand	32	delete_brand
128	Can view brand	32	view_brand
\.


--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.authtoken_token (key, created, user_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2022-03-16 16:37:04.310578+00	1	フライ	1	[{"added": {}}]	26	1
2	2022-03-16 16:37:15.046821+00	2	ボイル	1	[{"added": {}}]	26	1
3	2022-03-16 16:37:21.100937+00	3	ベイク	1	[{"added": {}}]	26	1
4	2022-03-16 16:37:31.633568+00	4	スチーム	1	[{"added": {}}]	26	1
5	2022-03-16 16:37:40.068893+00	5	レンジ	1	[{"added": {}}]	26	1
6	2022-03-16 16:38:53.674929+00	1	Industry object (1)	1	[{"added": {}}]	27	1
7	2022-03-16 16:39:43.986265+00	2	Industry object (2)	1	[{"added": {}}]	27	1
8	2022-03-16 16:40:15.958955+00	3	Industry object (3)	1	[{"added": {}}]	27	1
9	2022-03-16 16:41:14.873745+00	4	Industry object (4)	1	[{"added": {}}]	27	1
10	2022-03-16 16:41:35.263661+00	5	Industry object (5)	1	[{"added": {}}]	27	1
11	2022-03-16 16:41:47.701909+00	5	Industry object (5)	2	[{"changed": {"fields": ["Slug"]}}]	27	1
12	2022-03-16 16:42:06.782095+00	6	Industry object (6)	1	[{"added": {}}]	27	1
13	2022-03-16 16:43:05.72383+00	7	Industry object (7)	1	[{"added": {}}]	27	1
14	2022-03-16 16:45:20.684163+00	1	Tag object (1)	1	[{"added": {}}]	28	1
15	2022-03-16 16:45:55.756923+00	2	Tag object (2)	1	[{"added": {}}]	28	1
16	2022-03-16 16:46:09.507448+00	3	Tag object (3)	1	[{"added": {}}]	28	1
17	2022-03-16 22:25:26.204892+00	1	天ぷら粉	1	[{"added": {}}]	24	1
18	2022-03-16 22:25:44.508767+00	2	から揚げ粉	1	[{"added": {}}]	24	1
19	2022-03-16 22:26:00.503909+00	3	バッター・打ち粉	1	[{"added": {}}]	24	1
20	2022-03-16 22:26:18.264468+00	4	和風メニュー(お好み焼・たこ焼他)	1	[{"added": {}}]	24	1
21	2022-03-16 22:26:29.605656+00	5	洋風メニュー(スイーツ他)	1	[{"added": {}}]	24	1
22	2022-03-16 22:26:47.194221+00	6	ロングパスタ	1	[{"added": {}}]	24	1
23	2022-03-16 22:27:00.34162+00	6	ロングパスタ	2	[{"changed": {"fields": ["Slug"]}}]	24	1
24	2022-03-16 22:27:17.723534+00	6	ロングパスタ	2	[{"changed": {"fields": ["Slug"]}}]	24	1
25	2022-03-16 22:27:35.405441+00	7	ショートパスタ	1	[{"added": {}}]	24	1
26	2022-03-16 22:28:21.988658+00	8	調理済みパスタ	1	[{"added": {}}]	24	1
27	2022-03-16 22:29:49.155407+00	9	パスタソース	1	[{"added": {}}]	24	1
28	2022-03-16 22:33:47.362556+00	10	かるサクシリーズ	1	[{"added": {}}]	24	1
29	2022-03-16 22:34:07.128636+00	11	揚げ上手シリーズ	1	[{"added": {}}]	24	1
30	2022-03-16 22:34:29.168371+00	12	調理行程削減	1	[{"added": {}}]	24	1
31	2022-03-16 22:34:46.677785+00	13	水溶き	1	[{"added": {}}]	24	1
32	2022-03-16 22:35:07.989083+00	14	漬け込みまぶしタイプ	1	[{"added": {}}]	24	1
33	2022-03-16 22:35:39.286071+00	15	水溶きまぶし	1	[{"added": {}}]	24	1
34	2022-03-16 22:35:51.885096+00	16	まぶしタイプ	1	[{"added": {}}]	24	1
35	2022-03-16 22:36:08.569938+00	17	味つき	1	[{"added": {}}]	24	1
36	2022-03-16 22:36:23.381128+00	18	味なし	1	[{"added": {}}]	24	1
37	2022-03-16 22:37:22.854336+00	3	バッター・打ち粉	2	[{"changed": {"fields": ["Slug"]}}]	24	1
38	2022-03-16 22:37:37.476089+00	19	打ち粉	1	[{"added": {}}]	24	1
39	2022-03-16 22:37:50.723427+00	20	バッター	1	[{"added": {}}]	24	1
40	2022-03-16 22:38:14.230305+00	21	畜肉用	1	[{"added": {}}]	24	1
41	2022-03-16 22:38:31.960561+00	22	魚介用	1	[{"added": {}}]	24	1
42	2022-03-16 22:38:48.889763+00	23	たこ焼	1	[{"added": {}}]	24	1
43	2022-03-16 22:39:41.618419+00	24	お好み焼	1	[{"added": {}}]	24	1
44	2022-03-16 22:39:56.015408+00	25	鯛焼き	1	[{"added": {}}]	24	1
45	2022-03-16 22:40:10.071507+00	26	大判焼き	1	[{"added": {}}]	24	1
46	2022-03-16 22:40:36.725241+00	27	冷麺	1	[{"added": {}}]	24	1
47	2022-03-16 22:40:53.015774+00	28	パンケーキ	1	[{"added": {}}]	24	1
48	2022-03-16 22:41:55.527437+00	29	クレープ	1	[{"added": {}}]	24	1
49	2022-03-16 22:42:15.162005+00	30	ホットケーキ	1	[{"added": {}}]	24	1
50	2022-03-16 22:42:32.055103+00	31	蒸しパン	1	[{"added": {}}]	24	1
51	2022-03-16 22:42:49.521892+00	32	ワッフル	1	[{"added": {}}]	24	1
52	2022-03-16 22:43:12.566808+00	33	ピザ	1	[{"added": {}}]	24	1
53	2022-03-16 22:44:11.560764+00	34	チュロス	1	[{"added": {}}]	24	1
54	2022-03-16 22:44:41.076913+00	35	ホワイトソース	1	[{"added": {}}]	24	1
55	2022-03-16 22:45:47.260737+00	36	～1.5㎜	1	[{"added": {}}]	24	1
56	2022-03-16 22:46:13.860504+00	37	1.6～1.7㎜	1	[{"added": {}}]	24	1
57	2022-03-16 22:46:34.748149+00	38	1.8㎜～	1	[{"added": {}}]	24	1
58	2022-03-16 22:46:51.460229+00	39	ハーフ	1	[{"added": {}}]	24	1
59	2022-03-16 22:47:09.010334+00	40	乾麺	1	[{"added": {}}]	24	1
60	2022-03-16 22:47:29.039531+00	41	生麺	1	[{"added": {}}]	24	1
61	2022-03-16 22:47:49.97693+00	42	ゆで時間短縮	1	[{"added": {}}]	24	1
62	2022-03-16 22:48:47.548311+00	43	ディチェコ	1	[{"added": {}}]	24	1
63	2022-03-16 22:50:14.63273+00	44	ストレートマカロニ	1	[{"added": {}}]	24	1
64	2022-03-16 22:51:35.398483+00	45	フィジリ	1	[{"added": {}}]	24	1
65	2022-03-16 22:52:57.649484+00	46	ペンネ	1	[{"added": {}}]	24	1
66	2022-03-16 22:53:11.265721+00	47	シェル	1	[{"added": {}}]	24	1
67	2022-03-16 22:53:36.112306+00	48	その他	1	[{"added": {}}]	24	1
68	2022-03-16 22:54:42.508174+00	49	ディチェコ	1	[{"added": {}}]	24	1
69	2022-03-16 22:55:23.120165+00	50	ワンディッシュ	1	[{"added": {}}]	24	1
70	2022-03-16 22:55:44.98027+00	51	付け合わせ	1	[{"added": {}}]	24	1
71	2022-03-16 22:56:16.838947+00	52	パウチ	1	[{"added": {}}]	24	1
72	2022-03-16 22:56:54.640728+00	53	缶	1	[{"added": {}}]	24	1
73	2022-03-16 22:57:14.665255+00	54	チューブ	1	[{"added": {}}]	24	1
74	2022-03-17 01:05:08.01731+00	4	その他	1	[{"added": {}}]	28	1
75	2022-03-17 01:05:16.966209+00	4	その他	3		28	1
76	2022-03-17 01:19:49.09893+00	22	天ぷら粉かるサク衣	1	[{"added": {}}]	25	1
77	2022-03-17 01:27:23.687+00	22	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Slug"]}}]	25	1
78	2022-03-17 01:27:43.754066+00	22	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Category", "Tag", "Industry", "Facility"]}}]	25	1
79	2022-03-17 02:10:26.186449+00	22	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Is new"]}}]	25	1
80	2022-03-19 09:59:20.995967+00	22	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Tag"]}}]	25	1
81	2022-03-19 10:20:54.608389+00	22	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Tag"]}}]	25	1
82	2022-03-19 10:21:08.498969+00	22	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Facility"]}}]	25	1
83	2022-03-19 10:28:19.594134+00	22	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Facility"]}}]	25	1
84	2022-03-19 13:45:25.907783+00	22	天ぷら粉かるサク衣	2	[{"changed": {"fields": ["Facility"]}}]	25	1
85	2022-03-19 13:54:14.874048+00	22	天ぷら粉かるサク衣	2	[]	25	1
86	2022-03-19 13:54:33.411458+00	22	天ぷら粉かるサク衣	2	[{"added": {"name": "photo", "object": "Photo object (1)"}}]	25	1
87	2022-03-19 13:54:55.148145+00	22	天ぷら粉かるサク衣	2	[{"changed": {"name": "photo", "object": "Photo object (1)", "fields": ["Label"]}}]	25	1
\.


--
-- Data for Name: django_celery_beat_clockedschedule; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_celery_beat_clockedschedule (id, clocked_time) FROM stdin;
\.


--
-- Data for Name: django_celery_beat_crontabschedule; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_celery_beat_crontabschedule (id, minute, hour, day_of_week, day_of_month, month_of_year, timezone) FROM stdin;
1	0	4	*	*	*	Asia/Tokyo
\.


--
-- Data for Name: django_celery_beat_intervalschedule; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_celery_beat_intervalschedule (id, every, period) FROM stdin;
\.


--
-- Data for Name: django_celery_beat_periodictask; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_celery_beat_periodictask (id, name, task, args, kwargs, queue, exchange, routing_key, expires, enabled, last_run_at, total_run_count, date_changed, description, crontab_id, interval_id, solar_id, one_off, start_time, priority, headers, clocked_id, expire_seconds) FROM stdin;
1	celery.backend_cleanup	celery.backend_cleanup	[]	{}	\N	\N	\N	\N	t	2022-03-19 09:47:30.619605+00	10	2022-03-19 13:52:31.751776+00		1	\N	\N	f	\N	\N	{}	\N	43200
\.


--
-- Data for Name: django_celery_beat_periodictasks; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_celery_beat_periodictasks (ident, last_update) FROM stdin;
1	2022-03-19 13:52:31.746855+00
\.


--
-- Data for Name: django_celery_beat_solarschedule; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_celery_beat_solarschedule (id, event, latitude, longitude) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	auth	permission
2	auth	group
3	contenttypes	contenttype
4	sessions	session
5	sites	site
6	admin	logentry
7	account	emailaddress
8	account	emailconfirmation
9	socialaccount	socialaccount
10	socialaccount	socialapp
11	socialaccount	socialtoken
12	django_celery_beat	crontabschedule
13	django_celery_beat	intervalschedule
14	django_celery_beat	periodictask
15	django_celery_beat	periodictasks
16	django_celery_beat	solarschedule
17	django_celery_beat	clockedschedule
18	authtoken	token
19	authtoken	tokenproxy
20	users	user
21	easy_thumbnails	source
22	easy_thumbnails	thumbnail
23	easy_thumbnails	thumbnaildimensions
24	products	category
25	products	product
26	products	facility
27	products	industry
28	products	tag
29	products	series
30	products	photo
31	products	handling
32	products	brand
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2022-03-07 09:37:10.540157+00
2	contenttypes	0002_remove_content_type_name	2022-03-07 09:37:10.569508+00
3	auth	0001_initial	2022-03-07 09:37:10.754892+00
4	auth	0002_alter_permission_name_max_length	2022-03-07 09:37:10.774801+00
5	auth	0003_alter_user_email_max_length	2022-03-07 09:37:10.827408+00
6	auth	0004_alter_user_username_opts	2022-03-07 09:37:10.847993+00
7	auth	0005_alter_user_last_login_null	2022-03-07 09:37:10.877223+00
8	auth	0006_require_contenttypes_0002	2022-03-07 09:37:10.883032+00
9	auth	0007_alter_validators_add_error_messages	2022-03-07 09:37:10.931278+00
10	auth	0008_alter_user_username_max_length	2022-03-07 09:37:10.966127+00
11	auth	0009_alter_user_last_name_max_length	2022-03-07 09:37:10.984432+00
12	auth	0010_alter_group_name_max_length	2022-03-07 09:37:11.020012+00
13	auth	0011_update_proxy_permissions	2022-03-07 09:37:11.036858+00
14	auth	0012_alter_user_first_name_max_length	2022-03-07 09:37:11.082625+00
15	users	0001_initial	2022-03-07 09:37:11.276583+00
16	account	0001_initial	2022-03-07 09:37:11.465481+00
17	account	0002_email_max_length	2022-03-07 09:37:11.50795+00
18	admin	0001_initial	2022-03-07 09:37:11.67428+00
19	admin	0002_logentry_remove_auto_add	2022-03-07 09:37:11.706846+00
20	admin	0003_logentry_add_action_flag_choices	2022-03-07 09:37:11.76309+00
21	authtoken	0001_initial	2022-03-07 09:37:11.868338+00
22	authtoken	0002_auto_20160226_1747	2022-03-07 09:37:11.971545+00
23	authtoken	0003_tokenproxy	2022-03-07 09:37:11.979212+00
24	django_celery_beat	0001_initial	2022-03-07 09:37:12.2096+00
25	django_celery_beat	0002_auto_20161118_0346	2022-03-07 09:37:12.269551+00
26	django_celery_beat	0003_auto_20161209_0049	2022-03-07 09:37:12.30653+00
27	django_celery_beat	0004_auto_20170221_0000	2022-03-07 09:37:12.326665+00
28	django_celery_beat	0005_add_solarschedule_events_choices	2022-03-07 09:37:12.345729+00
29	django_celery_beat	0006_auto_20180322_0932	2022-03-07 09:37:12.441548+00
30	django_celery_beat	0007_auto_20180521_0826	2022-03-07 09:37:12.499075+00
31	django_celery_beat	0008_auto_20180914_1922	2022-03-07 09:37:12.601433+00
32	django_celery_beat	0006_auto_20180210_1226	2022-03-07 09:37:12.661591+00
33	django_celery_beat	0006_periodictask_priority	2022-03-07 09:37:12.696736+00
34	django_celery_beat	0009_periodictask_headers	2022-03-07 09:37:12.715238+00
35	django_celery_beat	0010_auto_20190429_0326	2022-03-07 09:37:13.30029+00
36	django_celery_beat	0011_auto_20190508_0153	2022-03-07 09:37:13.348362+00
37	django_celery_beat	0012_periodictask_expire_seconds	2022-03-07 09:37:13.366356+00
38	django_celery_beat	0013_auto_20200609_0727	2022-03-07 09:37:13.411318+00
39	django_celery_beat	0014_remove_clockedschedule_enabled	2022-03-07 09:37:13.426466+00
40	django_celery_beat	0015_edit_solarschedule_events_choices	2022-03-07 09:37:13.468254+00
41	sessions	0001_initial	2022-03-07 09:37:13.513373+00
42	sites	0001_initial	2022-03-07 09:37:13.551652+00
43	sites	0002_alter_domain_unique	2022-03-07 09:37:13.580315+00
44	sites	0003_set_site_domain_and_name	2022-03-07 09:37:13.685046+00
45	sites	0004_alter_options_ordering_domain	2022-03-07 09:37:13.702404+00
46	socialaccount	0001_initial	2022-03-07 09:37:14.308559+00
47	socialaccount	0002_token_max_lengths	2022-03-07 09:37:14.514821+00
48	socialaccount	0003_extra_data_default_dict	2022-03-07 09:37:14.579944+00
49	easy_thumbnails	0001_initial	2022-03-08 22:35:29.973149+00
50	easy_thumbnails	0002_thumbnaildimensions	2022-03-08 22:35:29.989016+00
52	products	0002_alter_product_category	2022-03-12 09:08:18.837337+00
53	products	0001_initial	2022-03-16 16:08:05.100559+00
54	products	0002_auto_20220317_0809	2022-03-16 23:09:29.38488+00
55	products	0003_alter_product_shipping_date	2022-03-16 23:59:37.121868+00
56	products	0004_auto_20220317_1012	2022-03-17 01:12:27.575787+00
57	products	0005_auto_20220317_1014	2022-03-17 01:14:13.217748+00
58	products	0006_auto_20220317_1025	2022-03-17 01:25:49.365147+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
qp0lmt06j5zo3q7eezxdgbirau3ps7js	.eJxVjMsOgjAQRf-la9PQFunUpXu_gUznYVEDCYWV8d-FhIVu7znnvk2P61L6tcrcD2wuxpnT75aRnjLugB843idL07jMQ7a7Yg9a7W1ieV0P9--gYC1bHbI01CE0LXgOrXpJLC6S80pRUeHckebYkoAyhZjT5oJwkwKSRjCfLwRGOQY:1nSsfE:-muGv_OBhEaoreC2OK6M13zA5oJQEl9W8u5cKy46JTs	2022-03-26 03:43:32.893531+00
cuf8kz70qxcewkj1nch8q7fpddetn7o8	.eJxVjMsOgjAQRf-la9PQFunUpXu_gUznYVEDCYWV8d-FhIVu7znnvk2P61L6tcrcD2wuxpnT75aRnjLugB843idL07jMQ7a7Yg9a7W1ieV0P9--gYC1bHbI01CE0LXgOrXpJLC6S80pRUeHckebYkoAyhZjT5oJwkwKSRjCfLwRGOQY:1nSxXt:gOhvtlyC0E7BeekiB4aLhi7Zw42aqXGSJKRjG6HhCBc	2022-03-26 08:56:17.346942+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_site (id, domain, name) FROM stdin;
1	green-ghost.com	nisshin_b2b
\.


--
-- Data for Name: easy_thumbnails_source; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.easy_thumbnails_source (id, storage_hash, name, modified) FROM stdin;
1	f9bde26a1556cd667f742bd34ec7c55e	photos/271300_01.jpg	2022-03-19 13:54:33.190988+00
\.


--
-- Data for Name: easy_thumbnails_thumbnail; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.easy_thumbnails_thumbnail (id, storage_hash, name, modified, source_id) FROM stdin;
\.


--
-- Data for Name: easy_thumbnails_thumbnaildimensions; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.easy_thumbnails_thumbnaildimensions (id, thumbnail_id, width, height) FROM stdin;
\.


--
-- Data for Name: products_brand; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.products_brand (id, name, product_id, series_id) FROM stdin;
\.


--
-- Data for Name: products_category; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.products_category (id, name, description, hero, photo, slug, lft, rght, tree_id, level, parent_id) FROM stdin;
10	かるサクシリーズ				karusaku	2	3	1	1	1
42	ゆで時間短縮				yudejikan_tanshuku	14	15	6	1	6
11	揚げ上手シリーズ				agejozu	4	5	1	1	1
1	天ぷら粉				tenpurako	1	8	1	0	\N
12	調理行程削減				chouri_koutei	6	7	1	1	1
6	ロングパスタ				long_pasta	1	18	6	0	\N
13	水溶き				mizutaki	2	3	2	1	2
43	ディチェコ				dececco	16	17	6	1	6
14	漬け込みまぶしタイプ				tsukekomi	4	5	2	1	2
15	水溶きまぶし				mizutoki_mabushi	6	7	2	1	2
44	ストレートマカロニ				straight_macaroni	2	3	7	1	7
16	まぶしタイプ				mabushi	8	9	2	1	2
17	味つき				ajitsuki	10	11	2	1	2
2	から揚げ粉				karaageko	1	14	2	0	\N
18	味なし				ajinashii	12	13	2	1	2
45	フィジリ				fusilli	4	5	7	1	7
19	打ち粉				uchiko	2	3	3	1	3
20	バッター				batter	4	5	3	1	3
46	ペンネ				penne	6	7	7	1	7
21	畜肉用				chikuniku	6	7	3	1	3
3	バッター・打ち粉				batter_uchiko	1	10	3	0	\N
22	魚介用				gyokai	8	9	3	1	3
23	たこ焼				takoyaki	2	3	4	1	4
47	シェル				shell	8	9	7	1	7
24	お好み焼				okonomiyaki	4	5	4	1	4
25	鯛焼き				taiyaki	6	7	4	1	4
48	その他				other_shortpasta	10	11	7	1	7
26	大判焼き				obanyaki	8	9	4	1	4
4	和風メニュー(お好み焼・たこ焼他)				wafu	1	12	4	0	\N
27	冷麺				reimen	10	11	4	1	4
7	ショートパスタ				short_pasta	1	14	7	0	\N
28	パンケーキ				pancake	2	3	5	1	5
49	ディチェコ				dececco_shortpasta	12	13	7	1	7
29	クレープ				crepe	4	5	5	1	5
30	ホットケーキ				hotcake	6	7	5	1	5
50	ワンディッシュ				onedish	2	3	8	1	8
31	蒸しパン				mushipan	8	9	5	1	5
8	調理済みパスタ				cooked_pasta	1	6	8	0	\N
32	ワッフル				waffle	10	11	5	1	5
51	付け合わせ				tsukeawase	4	5	8	1	8
33	ピザ				pizza	12	13	5	1	5
34	チュロス				churro	14	15	5	1	5
5	洋風メニュー(スイーツ他)				yofu	1	18	5	0	\N
35	ホワイトソース				white_sauce	16	17	5	1	5
52	パウチ				pouch	2	3	9	1	9
36	～1.5㎜				1_5mm	2	3	6	1	6
37	1.6～1.7㎜				1_6-1_7mm	4	5	6	1	6
53	缶				can	4	5	9	1	9
38	1.8㎜～				1_8mm	6	7	6	1	6
9	パスタソース				pasta_sauce	1	8	9	0	\N
39	ハーフ				half	8	9	6	1	6
54	チューブ				tube	6	7	9	1	9
40	乾麺				kanmen	10	11	6	1	6
41	生麺				namamen	12	13	6	1	6
\.


--
-- Data for Name: products_facility; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.products_facility (id, name, slug) FROM stdin;
1	フライ	fry
2	ボイル	boil
3	ベイク	bake
4	スチーム	steam
5	レンジ	microwave
\.


--
-- Data for Name: products_handling; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.products_handling (id, water, "time", temperature, recipe, product_id) FROM stdin;
\.


--
-- Data for Name: products_industry; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.products_industry (id, name, description, hero, photo, slug) FROM stdin;
1	外食				restaurant
2	中食惣菜				ready-made
3	テイクアウト・デリバリー				delivery
4	介護施設・病院				hospital
5	給食				school
6	加工工場				factory
7	EC（リンク）				e-commerce
\.


--
-- Data for Name: products_photo; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.products_photo (id, photo, label, product_id) FROM stdin;
1	photos/271300_01.jpg	main	22
\.


--
-- Data for Name: products_product; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.products_product (id, title, subtitle, slug, price, description, created_at, hero, preservation, is_new, is_published, shipping_date) FROM stdin;
22	天ぷら粉かるサク衣	\N	ttp	\N	天ぷら粉かるサク衣	2022-03-17 01:19:37+00		room_temp	t	t	\N
\.


--
-- Data for Name: products_product_category; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.products_product_category (id, product_id, category_id) FROM stdin;
1	22	1
2	22	10
\.


--
-- Data for Name: products_product_facility; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.products_product_facility (id, product_id, facility_id) FROM stdin;
1	22	1
3	22	3
\.


--
-- Data for Name: products_product_industry; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.products_product_industry (id, product_id, industry_id) FROM stdin;
1	22	1
2	22	2
3	22	3
4	22	5
\.


--
-- Data for Name: products_product_tag; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.products_product_tag (id, product_id, tag_id) FROM stdin;
1	22	1
3	22	2
\.


--
-- Data for Name: products_series; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.products_series (id, name, product_id) FROM stdin;
\.


--
-- Data for Name: products_tag; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.products_tag (id, name, slug) FROM stdin;
1	簡単調理	easy
2	おいしさ長持ち	long-lasting
3	大容量	big-size
\.


--
-- Data for Name: socialaccount_socialaccount; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.socialaccount_socialaccount (id, provider, uid, last_login, date_joined, extra_data, user_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.socialaccount_socialapp (id, provider, name, client_id, secret, key) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp_sites; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.socialaccount_socialapp_sites (id, socialapp_id, site_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialtoken; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.socialaccount_socialtoken (id, token, token_secret, expires_at, account_id, app_id) FROM stdin;
\.


--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_user (id, password, last_login, is_superuser, username, email, is_staff, is_active, date_joined, name) FROM stdin;
1	argon2$argon2id$v=19$m=102400,t=2,p=8$amtRMzFtZ1BTVlZ3NkVWa09NRTVnRw$Ush08ZNq9fDUqVJhUSLNp710aTpAVZUS3wAcQwfEJDo	2022-03-12 08:56:17.206672+00	t	admin	kudo@green-ghost.com	t	t	2022-03-12 03:42:53.77263+00	
\.


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.account_emailaddress_id_seq', 1, false);


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.account_emailconfirmation_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 128, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 87, true);


--
-- Name: django_celery_beat_clockedschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_celery_beat_clockedschedule_id_seq', 1, false);


--
-- Name: django_celery_beat_crontabschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_celery_beat_crontabschedule_id_seq', 1, true);


--
-- Name: django_celery_beat_intervalschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_celery_beat_intervalschedule_id_seq', 1, false);


--
-- Name: django_celery_beat_periodictask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_celery_beat_periodictask_id_seq', 1, true);


--
-- Name: django_celery_beat_solarschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_celery_beat_solarschedule_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 32, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 58, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, false);


--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.easy_thumbnails_source_id_seq', 1, true);


--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.easy_thumbnails_thumbnail_id_seq', 1, false);


--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.easy_thumbnails_thumbnaildimensions_id_seq', 1, false);


--
-- Name: products_brand_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.products_brand_id_seq', 1, false);


--
-- Name: products_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.products_category_id_seq', 54, true);


--
-- Name: products_facility_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.products_facility_id_seq', 5, true);


--
-- Name: products_handling_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.products_handling_id_seq', 1, false);


--
-- Name: products_industry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.products_industry_id_seq', 7, true);


--
-- Name: products_photo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.products_photo_id_seq', 1, true);


--
-- Name: products_product_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.products_product_category_id_seq', 2, true);


--
-- Name: products_product_facility_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.products_product_facility_id_seq', 3, true);


--
-- Name: products_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.products_product_id_seq', 22, true);


--
-- Name: products_product_industry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.products_product_industry_id_seq', 4, true);


--
-- Name: products_product_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.products_product_tag_id_seq', 3, true);


--
-- Name: products_series_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.products_series_id_seq', 1, false);


--
-- Name: products_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.products_tag_id_seq', 4, true);


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.socialaccount_socialaccount_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_sites_id_seq', 1, false);


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.socialaccount_socialtoken_id_seq', 1, false);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_user_id_seq', 1, true);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 1, false);


--
-- Name: account_emailaddress account_emailaddress_email_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_email_key UNIQUE (email);


--
-- Name: account_emailaddress account_emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_pkey PRIMARY KEY (id);


--
-- Name: account_emailconfirmation account_emailconfirmation_key_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_key_key UNIQUE (key);


--
-- Name: account_emailconfirmation account_emailconfirmation_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: authtoken_token authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- Name: authtoken_token authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_clockedschedule django_celery_beat_clockedschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_clockedschedule
    ADD CONSTRAINT django_celery_beat_clockedschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_crontabschedule django_celery_beat_crontabschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_crontabschedule
    ADD CONSTRAINT django_celery_beat_crontabschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_intervalschedule django_celery_beat_intervalschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_intervalschedule
    ADD CONSTRAINT django_celery_beat_intervalschedule_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_periodictask django_celery_beat_periodictask_name_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_periodictask_name_key UNIQUE (name);


--
-- Name: django_celery_beat_periodictask django_celery_beat_periodictask_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_periodictask_pkey PRIMARY KEY (id);


--
-- Name: django_celery_beat_periodictasks django_celery_beat_periodictasks_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_periodictasks
    ADD CONSTRAINT django_celery_beat_periodictasks_pkey PRIMARY KEY (ident);


--
-- Name: django_celery_beat_solarschedule django_celery_beat_solar_event_latitude_longitude_ba64999a_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule
    ADD CONSTRAINT django_celery_beat_solar_event_latitude_longitude_ba64999a_uniq UNIQUE (event, latitude, longitude);


--
-- Name: django_celery_beat_solarschedule django_celery_beat_solarschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_solarschedule
    ADD CONSTRAINT django_celery_beat_solarschedule_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_source easy_thumbnails_source_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.easy_thumbnails_source
    ADD CONSTRAINT easy_thumbnails_source_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_source easy_thumbnails_source_storage_hash_name_481ce32d_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.easy_thumbnails_source
    ADD CONSTRAINT easy_thumbnails_source_storage_hash_name_481ce32d_uniq UNIQUE (storage_hash, name);


--
-- Name: easy_thumbnails_thumbnail easy_thumbnails_thumbnai_storage_hash_name_source_fb375270_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thumbnai_storage_hash_name_source_fb375270_uniq UNIQUE (storage_hash, name, source_id);


--
-- Name: easy_thumbnails_thumbnail easy_thumbnails_thumbnail_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thumbnail_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_thumbnaildimensions easy_thumbnails_thumbnaildimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thumbnaildimensions_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_thumbnaildimensions easy_thumbnails_thumbnaildimensions_thumbnail_id_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thumbnaildimensions_thumbnail_id_key UNIQUE (thumbnail_id);


--
-- Name: products_brand products_brand_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_brand
    ADD CONSTRAINT products_brand_pkey PRIMARY KEY (id);


--
-- Name: products_category products_category_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_category
    ADD CONSTRAINT products_category_pkey PRIMARY KEY (id);


--
-- Name: products_category products_category_slug_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_category
    ADD CONSTRAINT products_category_slug_key UNIQUE (slug);


--
-- Name: products_facility products_facility_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_facility
    ADD CONSTRAINT products_facility_pkey PRIMARY KEY (id);


--
-- Name: products_facility products_facility_slug_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_facility
    ADD CONSTRAINT products_facility_slug_key UNIQUE (slug);


--
-- Name: products_handling products_handling_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_handling
    ADD CONSTRAINT products_handling_pkey PRIMARY KEY (id);


--
-- Name: products_industry products_industry_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_industry
    ADD CONSTRAINT products_industry_pkey PRIMARY KEY (id);


--
-- Name: products_industry products_industry_slug_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_industry
    ADD CONSTRAINT products_industry_slug_key UNIQUE (slug);


--
-- Name: products_photo products_photo_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_photo
    ADD CONSTRAINT products_photo_pkey PRIMARY KEY (id);


--
-- Name: products_product_category products_product_category_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_category
    ADD CONSTRAINT products_product_category_pkey PRIMARY KEY (id);


--
-- Name: products_product_category products_product_category_product_id_category_id_99b99489_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_category
    ADD CONSTRAINT products_product_category_product_id_category_id_99b99489_uniq UNIQUE (product_id, category_id);


--
-- Name: products_product_facility products_product_facility_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_facility
    ADD CONSTRAINT products_product_facility_pkey PRIMARY KEY (id);


--
-- Name: products_product_facility products_product_facility_product_id_facility_id_2cc3da46_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_facility
    ADD CONSTRAINT products_product_facility_product_id_facility_id_2cc3da46_uniq UNIQUE (product_id, facility_id);


--
-- Name: products_product_industry products_product_industry_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_industry
    ADD CONSTRAINT products_product_industry_pkey PRIMARY KEY (id);


--
-- Name: products_product_industry products_product_industry_product_id_industry_id_37c4402e_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_industry
    ADD CONSTRAINT products_product_industry_product_id_industry_id_37c4402e_uniq UNIQUE (product_id, industry_id);


--
-- Name: products_product products_product_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product
    ADD CONSTRAINT products_product_pkey PRIMARY KEY (id);


--
-- Name: products_product products_product_slug_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product
    ADD CONSTRAINT products_product_slug_key UNIQUE (slug);


--
-- Name: products_product_tag products_product_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_tag
    ADD CONSTRAINT products_product_tag_pkey PRIMARY KEY (id);


--
-- Name: products_product_tag products_product_tag_product_id_tag_id_a36bff8d_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_tag
    ADD CONSTRAINT products_product_tag_product_id_tag_id_a36bff8d_uniq UNIQUE (product_id, tag_id);


--
-- Name: products_series products_series_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_series
    ADD CONSTRAINT products_series_pkey PRIMARY KEY (id);


--
-- Name: products_tag products_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_tag
    ADD CONSTRAINT products_tag_pkey PRIMARY KEY (id);


--
-- Name: products_tag products_tag_slug_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_tag
    ADD CONSTRAINT products_tag_slug_key UNIQUE (slug);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_provider_uid_fc810c6e_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_provider_uid_fc810c6e_uniq UNIQUE (provider, uid);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq UNIQUE (socialapp_id, site_id);


--
-- Name: socialaccount_socialapp socialaccount_socialapp_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp
    ADD CONSTRAINT socialaccount_socialapp_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp_sites_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq UNIQUE (app_id, account_id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_user_id_group_id_b88eab82_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_group_id_b88eab82_uniq UNIQUE (user_id, group_id);


--
-- Name: users_user users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_permission_id_43338c45_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_permission_id_43338c45_uniq UNIQUE (user_id, permission_id);


--
-- Name: users_user users_user_username_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_username_key UNIQUE (username);


--
-- Name: account_emailaddress_email_03be32b2_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX account_emailaddress_email_03be32b2_like ON public.account_emailaddress USING btree (email varchar_pattern_ops);


--
-- Name: account_emailaddress_user_id_2c513194; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX account_emailaddress_user_id_2c513194 ON public.account_emailaddress USING btree (user_id);


--
-- Name: account_emailconfirmation_email_address_id_5b7f8c58; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX account_emailconfirmation_email_address_id_5b7f8c58 ON public.account_emailconfirmation USING btree (email_address_id);


--
-- Name: account_emailconfirmation_key_f43612bd_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX account_emailconfirmation_key_f43612bd_like ON public.account_emailconfirmation USING btree (key varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON public.authtoken_token USING btree (key varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_celery_beat_periodictask_clocked_id_47a69f82; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_celery_beat_periodictask_clocked_id_47a69f82 ON public.django_celery_beat_periodictask USING btree (clocked_id);


--
-- Name: django_celery_beat_periodictask_crontab_id_d3cba168; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_celery_beat_periodictask_crontab_id_d3cba168 ON public.django_celery_beat_periodictask USING btree (crontab_id);


--
-- Name: django_celery_beat_periodictask_interval_id_a8ca27da; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_celery_beat_periodictask_interval_id_a8ca27da ON public.django_celery_beat_periodictask USING btree (interval_id);


--
-- Name: django_celery_beat_periodictask_name_265a36b7_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_celery_beat_periodictask_name_265a36b7_like ON public.django_celery_beat_periodictask USING btree (name varchar_pattern_ops);


--
-- Name: django_celery_beat_periodictask_solar_id_a87ce72c; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_celery_beat_periodictask_solar_id_a87ce72c ON public.django_celery_beat_periodictask USING btree (solar_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: easy_thumbnails_source_name_5fe0edc6; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX easy_thumbnails_source_name_5fe0edc6 ON public.easy_thumbnails_source USING btree (name);


--
-- Name: easy_thumbnails_source_name_5fe0edc6_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX easy_thumbnails_source_name_5fe0edc6_like ON public.easy_thumbnails_source USING btree (name varchar_pattern_ops);


--
-- Name: easy_thumbnails_source_storage_hash_946cbcc9; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX easy_thumbnails_source_storage_hash_946cbcc9 ON public.easy_thumbnails_source USING btree (storage_hash);


--
-- Name: easy_thumbnails_source_storage_hash_946cbcc9_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX easy_thumbnails_source_storage_hash_946cbcc9_like ON public.easy_thumbnails_source USING btree (storage_hash varchar_pattern_ops);


--
-- Name: easy_thumbnails_thumbnail_name_b5882c31; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX easy_thumbnails_thumbnail_name_b5882c31 ON public.easy_thumbnails_thumbnail USING btree (name);


--
-- Name: easy_thumbnails_thumbnail_name_b5882c31_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX easy_thumbnails_thumbnail_name_b5882c31_like ON public.easy_thumbnails_thumbnail USING btree (name varchar_pattern_ops);


--
-- Name: easy_thumbnails_thumbnail_source_id_5b57bc77; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX easy_thumbnails_thumbnail_source_id_5b57bc77 ON public.easy_thumbnails_thumbnail USING btree (source_id);


--
-- Name: easy_thumbnails_thumbnail_storage_hash_f1435f49; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX easy_thumbnails_thumbnail_storage_hash_f1435f49 ON public.easy_thumbnails_thumbnail USING btree (storage_hash);


--
-- Name: easy_thumbnails_thumbnail_storage_hash_f1435f49_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX easy_thumbnails_thumbnail_storage_hash_f1435f49_like ON public.easy_thumbnails_thumbnail USING btree (storage_hash varchar_pattern_ops);


--
-- Name: products_brand_product_id_de479f92; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_brand_product_id_de479f92 ON public.products_brand USING btree (product_id);


--
-- Name: products_brand_series_id_e0925c40; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_brand_series_id_e0925c40 ON public.products_brand USING btree (series_id);


--
-- Name: products_category_name_0ecfb368; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_category_name_0ecfb368 ON public.products_category USING btree (name);


--
-- Name: products_category_name_0ecfb368_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_category_name_0ecfb368_like ON public.products_category USING btree (name varchar_pattern_ops);


--
-- Name: products_category_parent_id_3388f6c9; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_category_parent_id_3388f6c9 ON public.products_category USING btree (parent_id);


--
-- Name: products_category_slug_c558efae_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_category_slug_c558efae_like ON public.products_category USING btree (slug varchar_pattern_ops);


--
-- Name: products_category_tree_id_7d9b3ae8; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_category_tree_id_7d9b3ae8 ON public.products_category USING btree (tree_id);


--
-- Name: products_facility_slug_5bf55013_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_facility_slug_5bf55013_like ON public.products_facility USING btree (slug varchar_pattern_ops);


--
-- Name: products_handling_product_id_622d4fe1; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_handling_product_id_622d4fe1 ON public.products_handling USING btree (product_id);


--
-- Name: products_industry_slug_2cee7556_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_industry_slug_2cee7556_like ON public.products_industry USING btree (slug varchar_pattern_ops);


--
-- Name: products_photo_product_id_05315375; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_photo_product_id_05315375 ON public.products_photo USING btree (product_id);


--
-- Name: products_product_category_category_id_6bd7b606; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_product_category_category_id_6bd7b606 ON public.products_product_category USING btree (category_id);


--
-- Name: products_product_category_product_id_08fb2842; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_product_category_product_id_08fb2842 ON public.products_product_category USING btree (product_id);


--
-- Name: products_product_facility_facility_id_62ecee91; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_product_facility_facility_id_62ecee91 ON public.products_product_facility USING btree (facility_id);


--
-- Name: products_product_facility_product_id_7fd56ac6; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_product_facility_product_id_7fd56ac6 ON public.products_product_facility USING btree (product_id);


--
-- Name: products_product_industry_industry_id_be8f727d; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_product_industry_industry_id_be8f727d ON public.products_product_industry USING btree (industry_id);


--
-- Name: products_product_industry_product_id_ad2bf82b; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_product_industry_product_id_ad2bf82b ON public.products_product_industry USING btree (product_id);


--
-- Name: products_product_slug_70d3148d_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_product_slug_70d3148d_like ON public.products_product USING btree (slug varchar_pattern_ops);


--
-- Name: products_product_tag_product_id_df3b2f29; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_product_tag_product_id_df3b2f29 ON public.products_product_tag USING btree (product_id);


--
-- Name: products_product_tag_tag_id_d99e66b5; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_product_tag_tag_id_d99e66b5 ON public.products_product_tag USING btree (tag_id);


--
-- Name: products_series_product_id_96c66d91; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_series_product_id_96c66d91 ON public.products_series USING btree (product_id);


--
-- Name: products_tag_slug_5def095b_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX products_tag_slug_5def095b_like ON public.products_tag USING btree (slug varchar_pattern_ops);


--
-- Name: socialaccount_socialaccount_user_id_8146e70c; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialaccount_user_id_8146e70c ON public.socialaccount_socialaccount USING btree (user_id);


--
-- Name: socialaccount_socialapp_sites_site_id_2579dee5; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialapp_sites_site_id_2579dee5 ON public.socialaccount_socialapp_sites USING btree (site_id);


--
-- Name: socialaccount_socialapp_sites_socialapp_id_97fb6e7d; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialapp_sites_socialapp_id_97fb6e7d ON public.socialaccount_socialapp_sites USING btree (socialapp_id);


--
-- Name: socialaccount_socialtoken_account_id_951f210e; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialtoken_account_id_951f210e ON public.socialaccount_socialtoken USING btree (account_id);


--
-- Name: socialaccount_socialtoken_app_id_636a42d7; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialtoken_app_id_636a42d7 ON public.socialaccount_socialtoken USING btree (app_id);


--
-- Name: users_user_groups_group_id_9afc8d0e; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_groups_group_id_9afc8d0e ON public.users_user_groups USING btree (group_id);


--
-- Name: users_user_groups_user_id_5f6f5a90; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_groups_user_id_5f6f5a90 ON public.users_user_groups USING btree (user_id);


--
-- Name: users_user_user_permissions_permission_id_0b93982e; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_user_permissions_permission_id_0b93982e ON public.users_user_user_permissions USING btree (permission_id);


--
-- Name: users_user_user_permissions_user_id_20aca447; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_user_permissions_user_id_20aca447 ON public.users_user_user_permissions USING btree (user_id);


--
-- Name: users_user_username_06e46fe6_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_username_06e46fe6_like ON public.users_user USING btree (username varchar_pattern_ops);


--
-- Name: account_emailaddress account_emailaddress_user_id_2c513194_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_user_id_2c513194_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_emailconfirmation account_emailconfirm_email_address_id_5b7f8c58_fk_account_e; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirm_email_address_id_5b7f8c58_fk_account_e FOREIGN KEY (email_address_id) REFERENCES public.account_emailaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authtoken_token authtoken_token_user_id_35299eff_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_clocked_id_47a69f82_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_clocked_id_47a69f82_fk_django_ce FOREIGN KEY (clocked_id) REFERENCES public.django_celery_beat_clockedschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_crontab_id_d3cba168_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_crontab_id_d3cba168_fk_django_ce FOREIGN KEY (crontab_id) REFERENCES public.django_celery_beat_crontabschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_interval_id_a8ca27da_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_interval_id_a8ca27da_fk_django_ce FOREIGN KEY (interval_id) REFERENCES public.django_celery_beat_intervalschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_celery_beat_periodictask django_celery_beat_p_solar_id_a87ce72c_fk_django_ce; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_celery_beat_periodictask
    ADD CONSTRAINT django_celery_beat_p_solar_id_a87ce72c_fk_django_ce FOREIGN KEY (solar_id) REFERENCES public.django_celery_beat_solarschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: easy_thumbnails_thumbnail easy_thumbnails_thum_source_id_5b57bc77_fk_easy_thum; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thum_source_id_5b57bc77_fk_easy_thum FOREIGN KEY (source_id) REFERENCES public.easy_thumbnails_source(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: easy_thumbnails_thumbnaildimensions easy_thumbnails_thum_thumbnail_id_c3a0c549_fk_easy_thum; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thum_thumbnail_id_c3a0c549_fk_easy_thum FOREIGN KEY (thumbnail_id) REFERENCES public.easy_thumbnails_thumbnail(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_brand products_brand_product_id_de479f92_fk_products_product_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_brand
    ADD CONSTRAINT products_brand_product_id_de479f92_fk_products_product_id FOREIGN KEY (product_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_brand products_brand_series_id_e0925c40_fk_products_series_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_brand
    ADD CONSTRAINT products_brand_series_id_e0925c40_fk_products_series_id FOREIGN KEY (series_id) REFERENCES public.products_series(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_category products_category_parent_id_3388f6c9_fk_products_category_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_category
    ADD CONSTRAINT products_category_parent_id_3388f6c9_fk_products_category_id FOREIGN KEY (parent_id) REFERENCES public.products_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_handling products_handling_product_id_622d4fe1_fk_products_product_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_handling
    ADD CONSTRAINT products_handling_product_id_622d4fe1_fk_products_product_id FOREIGN KEY (product_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_photo products_photo_product_id_05315375_fk_products_product_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_photo
    ADD CONSTRAINT products_photo_product_id_05315375_fk_products_product_id FOREIGN KEY (product_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_category products_product_cat_category_id_6bd7b606_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_category
    ADD CONSTRAINT products_product_cat_category_id_6bd7b606_fk_products_ FOREIGN KEY (category_id) REFERENCES public.products_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_category products_product_cat_product_id_08fb2842_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_category
    ADD CONSTRAINT products_product_cat_product_id_08fb2842_fk_products_ FOREIGN KEY (product_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_facility products_product_fac_facility_id_62ecee91_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_facility
    ADD CONSTRAINT products_product_fac_facility_id_62ecee91_fk_products_ FOREIGN KEY (facility_id) REFERENCES public.products_facility(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_facility products_product_fac_product_id_7fd56ac6_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_facility
    ADD CONSTRAINT products_product_fac_product_id_7fd56ac6_fk_products_ FOREIGN KEY (product_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_industry products_product_ind_industry_id_be8f727d_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_industry
    ADD CONSTRAINT products_product_ind_industry_id_be8f727d_fk_products_ FOREIGN KEY (industry_id) REFERENCES public.products_industry(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_industry products_product_ind_product_id_ad2bf82b_fk_products_; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_industry
    ADD CONSTRAINT products_product_ind_product_id_ad2bf82b_fk_products_ FOREIGN KEY (product_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_tag products_product_tag_product_id_df3b2f29_fk_products_product_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_tag
    ADD CONSTRAINT products_product_tag_product_id_df3b2f29_fk_products_product_id FOREIGN KEY (product_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_product_tag products_product_tag_tag_id_d99e66b5_fk_products_tag_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_product_tag
    ADD CONSTRAINT products_product_tag_tag_id_d99e66b5_fk_products_tag_id FOREIGN KEY (tag_id) REFERENCES public.products_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: products_series products_series_product_id_96c66d91_fk_products_product_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.products_series
    ADD CONSTRAINT products_series_product_id_96c66d91_fk_products_product_id FOREIGN KEY (product_id) REFERENCES public.products_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_account_id_951f210e_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_account_id_951f210e_fk_socialacc FOREIGN KEY (account_id) REFERENCES public.socialaccount_socialaccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_app_id_636a42d7_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_app_id_636a42d7_fk_socialacc FOREIGN KEY (app_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_site_id_2579dee5_fk_django_si; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_site_id_2579dee5_fk_django_si FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc FOREIGN KEY (socialapp_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_group_id_9afc8d0e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_group_id_9afc8d0e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_user_id_5f6f5a90_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_5f6f5a90_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_perm_permission_id_0b93982e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_perm_permission_id_0b93982e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_20aca447_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_20aca447_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

